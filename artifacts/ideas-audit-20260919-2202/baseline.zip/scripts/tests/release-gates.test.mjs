import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdtemp, mkdir, readFile, readdir, rm, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { test } from "node:test";
import Ajv from "ajv";
import { verifyVersions } from "../verify_versions.mjs";
import { validatePinnedUses } from "../verify_workflow_pins.mjs";
import { loadWorkflows, validateWorkflowGates } from "../verify_workflow_gates.mjs";
import { inspectIcoSizes, validateIconConfiguration } from "../verify_icons.mjs";
import { validateBrandingEntries } from "../verify_branding.mjs";
import { validateQualification } from "../verify_qualification.mjs";
import { validateResearchAnchor } from "../verify_research_anchor.mjs";
import { verifyCandidateInventory, verifyPublishedInventory } from "../verify_candidate_inventory.mjs";

async function versionFixture(overrides = {}) {
  const root = await mkdtemp(join(tmpdir(), "localmotive-version-gate-"));
  await mkdir(join(root, "src-tauri"), { recursive: true });
  await mkdir(join(root, "src"), { recursive: true });
  const version = overrides.version ?? "0.4.1";
  await writeFile(join(root, "package.json"), JSON.stringify({ version }));
  await writeFile(join(root, "package-lock.json"), JSON.stringify({ version, packages: { "": { version: overrides.lockRoot ?? version } } }));
  await writeFile(join(root, "src-tauri", "tauri.conf.json"), JSON.stringify({ version: overrides.tauri ?? version }));
  await writeFile(join(root, "src-tauri", "Cargo.toml"), `[package]\nname = "localmotive"\nversion = "${overrides.cargo ?? version}"\n`);
  await writeFile(join(root, "src-tauri", "Cargo.lock"), `[[package]]\nname = "localmotive"\nversion = "${overrides.cargoLock ?? version}"\n`);
  const aboutSource = overrides.aboutFallback === null
    ? "setAbout(null);\n"
    : `setAbout({ name: "Localmotive", version: "${overrides.aboutFallback ?? version}" });\n`;
  await writeFile(join(root, "src", "App.tsx"), aboutSource);
  return root;
}

/// Concatenated frontend source: every screen module FIRST, then App.tsx.
/// The S-27.I2 extraction moves JSX into src/screens/*.tsx; guards that read
/// App.tsx alone silently stop matching. Splits find real component bodies
/// before any test-text mention because the screens come first.
/// Line endings are normalized to LF first: a CRLF checkout (for example the
/// default GitHub-hosted windows-latest image) must not change what the
/// LF-anchored guard regexes match (GH-01.V1 follow-up: pr-check failed on
/// the hosted runner while passing on LF checkouts).
async function frontendSources() {
  const screens = [
    "AboutScreen.tsx",
    "BenchmarkScreen.tsx",
    "CatalogScreen.tsx",
    "DashboardScreen.tsx",
    "InventoryScreen.tsx",
    "ProfileEmptyScreen.tsx",
    "ProfileScreen.tsx",
    "RuntimeScreen.tsx",
    "TuneScreen.tsx",
  ];
  const parts = [];
  for (const name of screens) {
    try {
      parts.push((await readFile(join(process.cwd(), "src", "screens", name), "utf8")).replace(/\r\n/g, "\n"));
    } catch {
      // A screen module that does not exist yet contributes nothing.
    }
  }
  parts.push((await readFile(join(process.cwd(), "src", "App.tsx"), "utf8")).replace(/\r\n/g, "\n"));
  return parts.join("\n");
}

test("version gate checks every release version field", async () => {
  const root = await versionFixture();
  const result = await verifyVersions(root, "0.4.1");
  assert.equal(result.ok, true);
  assert.equal(result.fields.length, 6);
});

test("version gate rejects a mismatched Cargo.lock package entry", async () => {
  const root = await versionFixture({ cargoLock: "0.4.0" });
  const result = await verifyVersions(root, "0.4.1");
  assert.equal(result.ok, false);
  assert.match(result.failures.join("\n"), /Cargo\.lock/);
});

test("version gate accepts no fabricated browser About version", async () => {
  const root = await versionFixture({ aboutFallback: null });
  const result = await verifyVersions(root, "0.4.1");
  assert.equal(result.ok, true);
  assert.equal(result.fields.length, 6);
});

test("workflow pin gate rejects mutable action references", () => {
  const result = validatePinnedUses([
    { file: "ci.yml", job: "test", step: 0, uses: "actions/checkout@v5.1.0" },
  ], []);
  assert.equal(result.ok, false);
  assert.match(result.failures.join("\n"), /full 40-character commit SHA/);
});

test("workflow pin gate rejects an annotated tag object as the executable pin", () => {
  const tagObjectSha = "49a0bdc70d2e1b713ca9e2869b211fcce03d3c1c";
  const result = validatePinnedUses([
    { file: "ci.yml", job: "test", step: 0, uses: `swatinem/rust-cache@${tagObjectSha}` },
  ], [{
    action: "swatinem/rust-cache",
    reviewedRef: "v2",
    sha: tagObjectSha,
    tagObjectSha,
    sourceUrl: `https://github.com/swatinem/rust-cache/tree/${tagObjectSha}`,
  }]);
  assert.equal(result.ok, false);
  assert.match(result.failures.join("\n"), /annotated tag object/);
});

test("workflow pin gate accepts the peeled commit and records its tag object", () => {
  const commitSha = "6323deb102c322ba6fcbdcafc7e3dddab59af2b6";
  const tagObjectSha = "49a0bdc70d2e1b713ca9e2869b211fcce03d3c1c";
  const result = validatePinnedUses([
    { file: "ci.yml", job: "test", step: 0, uses: `swatinem/rust-cache@${commitSha}` },
  ], [{
    action: "swatinem/rust-cache",
    reviewedRef: "v2",
    sha: commitSha,
    tagObjectSha,
    sourceUrl: `https://github.com/swatinem/rust-cache/commit/${commitSha}`,
  }]);
  assert.equal(result.ok, true, result.failures.join("\n"));
});

test("workflow gate rejects package jobs without every material dependency", () => {
  const workflows = {
    "ci.yml": {
      jobs: {
        test: { steps: [{ run: "npm test" }] },
        package: { needs: [], steps: [{ run: "npm run tauri build" }] },
      },
    },
  };
  const policy = {
    workflows: {
      "ci.yml": {
        gates: { test: ["npm test"] },
        packageJobs: { package: ["test"] },
        publicationJobs: {},
      },
    },
  };
  const result = validateWorkflowGates(workflows, policy);
  assert.equal(result.ok, false);
  assert.match(result.failures.join("\n"), /does not depend on material gate test/);
});

test("workflow gate rejects package jobs that omit packaged verification", () => {
  const workflows = {
    "release.yml": {
      jobs: {
        package: { steps: [{ run: "npm run tauri build" }] },
      },
    },
  };
  const policy = {
    workflows: {
      "release.yml": {
        gates: {},
        packageJobs: {},
        publicationJobs: {},
        requiredCommands: {
          package: ["node scripts/verify_041.mjs 10041 $portable"],
        },
      },
    },
  };
  const result = validateWorkflowGates(workflows, policy);
  assert.equal(result.ok, false);
  assert.match(result.failures.join("\n"), /must execute.*verify_041/);
});

test("catalog v2 schema, builder, and signed publish wiring stay consistent", async () => {
  const catalog = JSON.parse(await readFile(join(process.cwd(), "catalog", "catalog.json"), "utf8"));
  const providers = JSON.parse(await readFile(join(process.cwd(), "catalog", "providers.json"), "utf8"));
  const backend = await readFile(join(process.cwd(), "src-tauri", "src", "catalog.rs"), "utf8");
  const builder = await readFile(join(process.cwd(), "scripts", "build_catalog.mjs"), "utf8");
  const validator = await readFile(join(process.cwd(), "scripts", "validate_catalog.mjs"), "utf8");
  const workflow = await readFile(join(process.cwd(), ".github", "workflows", "catalog.yml"), "utf8");
  const gates = JSON.parse(await readFile(join(process.cwd(), ".github", "workflow-gates.json"), "utf8"));
  // The checked-in catalog is schema 2 after the signed v2 publish lands.
  // This test pins the full contract so no half-migrated publish can ship.
  // Seen live: a v2 preview with slash filenames and 61 cross-publisher
  // collisions failed the client filename guard, so the builder now excludes
  // subdirectories and dedupes by filename before signing.
  assert.equal(catalog.schemaVersion, 2);
  assert.match(backend, /pub const SUPPORTED_SCHEMA: u32 = 2;/);
  assert.match(backend, /MIN_SUPPORTED_SCHEMA/);
  assert.match(validator, /schemaVersion must be 2/);
  assert.match(validator, /providers\.allowlist/);
  assert.match(builder, /schemaVersion: 2/);
  assert.match(builder, /providers\.json/);
  assert.match(builder, /seenFilenames/);
  // The builder reads the allowlist from repo config, not a hardcoded list in
  // the app binary. Adding an author is a catalog publish, not an app release.
  assert.ok(Array.isArray(providers.allowlist) && providers.allowlist.length > 0);
  assert.doesNotMatch(backend, /providers\.json/);
  assert.match(backend, /DEFAULT_CATALOG_URL/);
  // The signed publish path keeps the private key in the sign job only. The
  // build job rebuilds from the allowlist without secrets; the sign job signs
  // the exact candidate and verifies the detached signature.
  assert.match(workflow, /CATALOG_SIGNING_KEY_PEM/);
  assert.match(workflow, /sign_catalog_candidate/);
  assert.match(workflow, /validate_catalog\.mjs catalog\/catalog\.json --no-signature/);
  assert.match(workflow, /validate_catalog\.mjs catalog\/catalog\.json\n/);
  assert.ok(gates.workflows["catalog.yml"].gates.build);
  assert.ok(gates.workflows["catalog.yml"].gates.sign);
});

test("release evidence uses one resolved immutable revision", async () => {
  const workflow = await readFile(join(process.cwd(), ".github", "workflows", "release.yml"), "utf8");
  // The producer records the resolver's SHA only after proving its checkout
  // matches it (audit GH-02 I1); workflow-generated context SHAs are never
  // accepted as the evidence identity.
  assert.match(workflow, /test "\$\(git rev-parse HEAD\)" = "\$RESOLVED_SHA"/);
  const job = (await loadWorkflows(process.cwd()))["release.yml"].jobs.verify;
  assert.equal(job.env.LOCALMOTIVE_SOURCE_REVISION, "${{ needs.resolve.outputs.sha }}");
  assert.doesNotMatch(workflow, /LOCALMOTIVE_SOURCE_REVISION:\s*\$\{\{ github\.sha \}\}/);
  const promote = await readFile(join(process.cwd(), ".github", "workflows", "release-promote.yml"), "utf8");
  assert.match(promote, /ref: \$\{\{ inputs\.tag \}\}/);
  assert.match(promote, /--expect-source "\$RESOLVED_SHA"/);
  assert.doesNotMatch(promote, /github\.sha\s*\}\}/, "no workflow context SHA is accepted as an identity");
});

test("release promotion reads published assets back", async () => {
  // R16 release behavior: publication moved out of the tag-push workflow.
  // The read-back lives in release-promote.yml, and the verify workflow must
  // not contain any publication or read-back path at all.
  const promote = await readFile(join(process.cwd(), ".github", "workflows", "release-promote.yml"), "utf8");
  assert.match(promote, /gh release view/);
  assert.match(promote, /gh release download/);
  assert.match(promote, /sha256sum -c/);
  const verify = await readFile(join(process.cwd(), ".github", "workflows", "release.yml"), "utf8");
  assert.doesNotMatch(verify, /gh release view/);
  assert.doesNotMatch(verify, /gh release create/);
});

test("a controlled nonzero native command remains nonzero", async () => {
  const { spawnSync } = await import("node:child_process");
  const child = spawnSync(process.execPath, ["-e", "process.exit(23)"], { stdio: "ignore" });
  assert.equal(child.status, 23);
});

test("icon gate requires every Windows icon surface and ICO layer", () => {
  const ico = Buffer.alloc(6 + (6 * 16));
  ico.writeUInt16LE(0, 0);
  ico.writeUInt16LE(1, 2);
  ico.writeUInt16LE(6, 4);
  [16, 24, 32, 48, 64, 256].forEach((size, index) => {
    ico[6 + (index * 16)] = size === 256 ? 0 : size;
    ico[6 + (index * 16) + 1] = size === 256 ? 0 : size;
  });
  assert.deepEqual(inspectIcoSizes(ico), [16, 24, 32, 48, 64, 256]);

  const result = validateIconConfiguration({
    config: {
      bundle: {
        publisher: "Localmotive contributors",
        icon: ["icons/icon.ico"],
        windows: {
          nsis: {
            installerIcon: "icons/icon.ico",
            uninstallerIcon: "icons/icon.ico",
          },
        },
      },
    },
    svg: '<rect fill="#1d2122"/><rect stroke="#d5d1c5"/><rect fill="#9edc72"/><path d="M0 0h1v1Z"/><path d="M1 0h1v1Z"/>',
    icoSizes: inspectIcoSizes(ico),
    expectedPublisher: "Localmotive contributors",
  });
  assert.equal(result.ok, true, result.failures.join("\n"));
});

test("Windows installers use the bootstrapper WebView2 mode until offline bundling is fixed", async () => {
  const config = JSON.parse(await readFile(join(process.cwd(), "src-tauri", "tauri.conf.json"), "utf8"));
  assert.equal(config.bundle?.windows?.webviewInstallMode?.type, "downloadBootstrapper");
});

test("README matches the shipped product and the unsigned Latest policy", async () => {
  const readme = await readFile(join(process.cwd(), "README.md"), "utf8");
  // Stale 0.3.0 download section hid the real ship state. Seen live: the
  // Download section still named 0.3.0 files while Latest served 0.4.1.
  assert.doesNotMatch(readme, /Release 0\.3\.0 provides/);
  assert.doesNotMatch(readme, /Localmotive_0\.3\.0_x64/);
  assert.doesNotMatch(readme, /SHA256SUMS-0\.3\.0/);
  assert.doesNotMatch(readme, /The bundled 0\.3\.0 catalog/);
  assert.doesNotMatch(readme, /\(unsigned prerelease\)/);
  assert.doesNotMatch(readme, /testing-only or pre-release/);
  // Current product: unsigned full release on Latest, SmartScreen honesty,
  // checksum proof, catalog v2 story, and network needs.
  assert.match(readme, /Latest/);
  assert.match(readme, /\(unsigned\)/);
  assert.match(readme, /SmartScreen/);
  assert.match(readme, /SHA256SUMS/);
  assert.match(readme, /schema 2|schemaVersion 2/i);
  assert.match(readme, /providers\.json/);
  assert.match(readme, /Hardware fit/i);
  assert.match(readme, /raw\.githubusercontent\.com/);
});

test("launch profiles reject oversize input at the Rust boundary", async () => {
  const core = await readFile(join(process.cwd(), "src-tauri", "src", "core.rs"), "utf8");
  // Profile strings flow from the UI into build_args. UI limits are hints
  // only; the Rust boundary owns truth. Seen live: no length check existed on
  // any profile string, so a hostile frontend could submit megabyte paths.
  assert.match(core, /MAX_PROFILE_TEXT_LEN/);
  assert.match(core, /MAX_TENSOR_SPLIT_ENTRIES/);
  assert.match(core, /validate_profile_input_bounds/);
});

test("catalog commands reject oversize input at the Rust boundary", async () => {
  const backend = await readFile(join(process.cwd(), "src-tauri", "src", "catalog.rs"), "utf8");
  // The catalog command family lives in catalog_service.rs after the S-27 I1
  // extraction; the boundary checks moved with it.
  const lib = await readFile(join(process.cwd(), "src-tauri", "src", "catalog_service.rs"), "utf8");
  // A compromised webview can send any JSON. UI limits are hints only; the
  // Rust boundary owns truth. Seen live: filter_catalog took Vec + query with
  // no length checks, so a hostile frontend could submit megabytes of text.
  assert.match(backend, /MAX_QUERY_TEXT_LEN/);
  assert.match(backend, /MAX_FILTER_VALUE_LEN/);
  assert.match(backend, /MAX_FILTER_MODELS/);
  assert.match(backend, /validate_catalog_query/);
  assert.match(backend, /validate_facet_models/);
  assert.match(backend, /validate_budget_inputs/);
  assert.match(lib, /validate_catalog_query\(&query, models\.len\(\)\)/);
  assert.match(lib, /validate_facet_models\(models\.len\(\)\)/);
  assert.match(lib, /validate_budget_inputs\(dedicated_bytes\.len\(\), shared_bytes\.len\(\)\)/);
});

test("catalog refresh honors cooldown, lock, and last-success display", async () => {
  const backend = await readFile(join(process.cwd(), "src-tauri", "src", "catalog.rs"), "utf8");
  // The fetch command moved to catalog_service.rs (S-27 I1); catalog.rs still
  // owns the cooldown/guard machinery it delegates to.
  const lib = await readFile(join(process.cwd(), "src-tauri", "src", "catalog_service.rs"), "utf8");
  const model = await readFile(join(process.cwd(), "src", "model.ts"), "utf8");
  const app = await frontendSources();
  // Seen live: fetch_catalog had no cooldown, so every Refresh click hit the
  // network, and two clicks started two fetches. The backend now owns a 1560
  // min cooldown, an in-flight guard, and a last-success stamp; the UI shows
  // last success plus the remaining wait.
  assert.match(backend, /CATALOG_REFRESH_COOLDOWN_MINUTES/);
  assert.match(backend, /refresh_cooldown_remaining_minutes/);
  assert.match(backend, /CatalogRefreshGuard/);
  assert.match(backend, /read_refresh_stamp/);
  assert.match(lib, /CatalogRefreshGuard::try_acquire/);
  assert.match(lib, /refresh_cooldown_remaining_minutes/);
  assert.match(lib, /CATALOG_REFRESH_COOLDOWN_MINUTES/);
  assert.match(model, /lastSuccessSecs/);
  assert.match(model, /cooldownRemainingMinutes/);
  assert.match(app, /LAST SUCCESS/);
  assert.match(app, /COOLDOWN/);
});

test("model catalog exposes rich filters with hardware auto-fit defaults", async () => {
  const app = await frontendSources();
  const model = await readFile(join(process.cwd(), "src", "model.ts"), "utf8");
  const backend = await readFile(join(process.cwd(), "src-tauri", "src", "lib.rs"), "utf8");
  // Rich adjustable filters come from the signed v2 artifact via backend
  // facets. The UI must not hardcode the author list: adding an author is a
  // catalog publish, not an app release.
  assert.match(app, /catalog_rich_facets/);
  assert.match(app, /Any author/);
  assert.match(app, /Any licence/);
  assert.match(app, /Any pipeline/);
  assert.match(app, /Any architecture/);
  assert.doesNotMatch(app, /lmstudio-community.*huihui-ai.*DavidAU/s);
  // Hardware auto-fit is on by default, explains its budget source, and can
  // be disabled or widened. Rust owns the rule; the UI only sends inputs.
  assert.match(app, /catalogFitEnabled/);
  assert.match(app, /Hardware fit/);
  assert.match(app, /Fit budget/);
  assert.match(app, /fit_per_mille/);
  assert.match(app, /budget_bytes/);
  assert.match(model, /hardwareFitBudget/);
  assert.match(model, /modelHiddenByFitRule/);
  assert.match(model, /DEFAULT_FIT_PER_MILLE/);
  assert.match(backend, /catalog_rich_facets/);
  assert.match(backend, /catalog_fit_budget/);
});

test("runtime catalog exposes an accessible refresh action in every terminal state", async () => {
  const source = await frontendSources();
  assert.match(source, /aria-label="Refresh approved runtime catalog"/);
  assert.match(source, /className="runtime-role runtime-scope"/);
  assert.match(source, /entry\.blockingJobs\.map/);
  assert.match(source, /DIRECT RUNTIME · L2/);
  assert.doesNotMatch(source, /sampleAsset/);
  assert.match(source, /Browser preview cannot retrieve the approved runtime catalog/);
});

test("production frontend never fabricates model or runtime inspection results", async () => {
  const source = await frontendSources();
  assert.doesNotMatch(source, /previewModels/);
  assert.doesNotMatch(source, /Example-8B-Instruct-Q4_K_M/);
  assert.doesNotMatch(source, /build: "10679"/);
  assert.doesNotMatch(source, /capabilities represented from the inspected local runtime/);
  assert.doesNotMatch(source, /setCommand\(`\\"\$\{profile\.runtime\}/);
  assert.match(source, /setHardware\(\{\s*architecture: "unknown"/);
  assert.match(source, /invoke<AboutInfo>\("about_info"\)\.then\(setAbout\)\.catch\(\(\) => setAbout\(null\)\)/);
});

test("frontend renders backend-owned managed runtime trust", async () => {
  const source = await frontendSources();
  assert.doesNotMatch(source, /runtimePath\.startsWith\(runtimeRoot\)/);
  assert.match(source, /runtimeIdentity\?\.managedVerified/);
});

test("runtime inspection commits one latest atomic result", async () => {
  const source = await frontendSources();
  assert.match(source, /const runtimeInspectSeq = useRef\(0\)/);
  assert.match(source, /Promise\.all\(\[/);
  assert.match(source, /keepLatestRequest\(sequence, runtimeInspectSeq\.current\)/);
});

test("runtime setup refresh preserves the selected adapter recommendation", async () => {
  const app = await frontendSources();
  // The runtime command family moved to runtime_service.rs (S-27 I1/I2).
  const backend = await readFile(join(process.cwd(), "src-tauri", "src", "runtime_service.rs"), "utf8");
  assert.match(app, /load_runtime_setup",\s*\{\s*adapterId: selectedRuntimeAdapterId \|\| null/);
  assert.match(backend, /async fn load_runtime_setup\([\s\S]*adapter_id: Option<String>/);
});

test("runtime catalog text actions meet the 44 pixel target minimum", async () => {
  const css = await readFile(join(process.cwd(), "src", "App.css"), "utf8");
  const rule = css.match(/\.runtime-source\s*\{([^}]*)\}/)?.[1] ?? "";
  assert.match(rule, /min-height:\s*44px/);
  assert.match(rule, /padding:/);
});

test("a rejected catalog invocation removes the spinner", async () => {
  const app = await frontendSources();
  const errorAt = app.indexOf('runtime-catalog-message error');
  assert.ok(errorAt > 0, "the catalog error block is missing");
  const errorBlock = app.slice(errorAt, errorAt + 2000);
  assert.doesNotMatch(errorBlock, /className="spin"/);
  assert.doesNotMatch(errorBlock, /className="runtime-loading"/);
  // The error branch is exclusive with the loading branch: the state
  // machine returns exactly one kind, so error can never co-render loading.
  const model = await readFile(join(process.cwd(), "src", "model.ts"), "utf8");
  assert.match(model, /if \(input\.loading\) return \{ kind: "loading" \};/);
  assert.match(model, /if \(input\.error\) return \{ kind: "error", error: input\.error \};/);
});

test("error state never renders a spinner", async () => {
  const app = await frontendSources();
  const errorAt = app.indexOf('runtime-catalog-message error');
  assert.ok(errorAt > 0, "the catalog error block is missing");
  const errorBlock = app.slice(errorAt, errorAt + 2000);
  assert.doesNotMatch(errorBlock, /className="spin"/);
  assert.doesNotMatch(errorBlock, /className="runtime-loading"/);
});

test("loading state has an accessible status label", async () => {
  const app = await frontendSources();
  assert.match(app, /className="runtime-loading" role="status" aria-label="Loading approved runtime catalog"/);
});

test("blocked CUDA shows job server-cuda and its evidence URL", async () => {
  const app = await frontendSources();
  assert.match(app, /entry\.blockingJobs\.map/);
  assert.match(app, /View \{jobName\} evidence/);
});

test("L2 rows render DIRECT RUNTIME · L2", async () => {
  const app = await frontendSources();
  assert.match(app, /DIRECT RUNTIME · L2/);
  assert.match(app, /L2 EVIDENCE CEILING/);
});

test("no row renders SUPPORTED without the required evidence", async () => {
  const app = await frontendSources();
  const model = await readFile(join(process.cwd(), "src", "model.ts"), "utf8");
  assert.doesNotMatch(app, /SUPPORTED/);
  assert.doesNotMatch(model, /SUPPORTED/);
});

test("public 0.4.1 documentation states the L2 evidence ceiling", async () => {
  const changelog = await readFile(join(process.cwd(), "CHANGELOG.md"), "utf8");
  const contract = await readFile(join(process.cwd(), "docs", "RUNTIME_MANAGER.md"), "utf8");
  assert.match(changelog, /L2 EVIDENCE CEILING/);
  assert.match(contract, /L2 ceiling/);
});

test("public links resolve without a gitignored local path", async () => {
  const app = await frontendSources();
  assert.doesNotMatch(app, /research\//);
  assert.doesNotMatch(app, /LOCALAPPDATA/);
  assert.doesNotMatch(app, /AppData/);
  assert.match(app, /https:\/\/github\.com\/ggml-org\/llama\.cpp\/releases/);
});

test("MSI manufacturer equals the approved publisher value", async () => {
  const { execFileSync } = await import("node:child_process");
  const config = JSON.parse(await readFile(join(process.cwd(), "src-tauri", "tauri.conf.json"), "utf8"));
  const cargo = await readFile(join(process.cwd(), "src-tauri", "Cargo.toml"), "utf8");
  const publisher = config.bundle?.publisher;
  assert.equal(publisher, "Localmotive contributors");
  assert.match(cargo, /authors = \["Localmotive contributors"\]/);
  // MSI Manufacturer falls back to bundle.publisher when no explicit
  // windows.wix fragment overrides it; fail loudly if a fragment appears
  // without carrying the approved value.
  let wixFragment = "";
  try {
    wixFragment = execFileSync("git", ["grep", "-l", "Manufacturer", "--", "src-tauri"], { encoding: "utf8" }).trim();
  } catch {
    wixFragment = "";
  }
  assert.equal(wixFragment, "", `unexpected Manufacturer override: ${wixFragment}`);
});

test("honestly unsigned full release verifies checksums and inventory instead of Authenticode", async () => {
  const verify = await readFile(join(process.cwd(), ".github", "workflows", "release.yml"), "utf8");
  const promote = await readFile(join(process.cwd(), ".github", "workflows", "release-promote.yml"), "utf8");
  for (const workflow of [verify, promote]) {
    assert.doesNotMatch(workflow, /signtool/);
    assert.doesNotMatch(workflow, /Get-AuthenticodeSignature/);
    assert.doesNotMatch(workflow, /TimeStamperCertificate/);
    assert.doesNotMatch(workflow, /passed the Authenticode verification gate/);
  }
  assert.match(verify, /verify_candidate_inventory/);
  assert.match(promote, /verify_candidate_inventory/);
  assert.match(promote, /sha256sum -c/);
  assert.match(promote, /unsigned/);
  assert.match(promote, /SmartScreen/);
  // The ship tip stays visible as Latest, so the publish path must not mark
  // the release as a GitHub Pre-release. Seen live: v0.4.1 shipped with
  // prerelease:true and releases/latest still pointed at v0.4.0.
  assert.match(promote, /prerelease:\s*false/);
  assert.doesNotMatch(promote, /\(unsigned prerelease\)/);
});

test("honestly unsigned full release reads back Latest with the unsigned asset set", async () => {
  const promote = await readFile(join(process.cwd(), ".github", "workflows", "release-promote.yml"), "utf8");
  assert.match(promote, /prerelease:\s*false/);
  assert.match(promote, /\.isPrerelease/);
  assert.match(promote, /honestly unsigned/);
  assert.match(promote, /\(unsigned\)/);
});

test("correct the three L2 claims in the new 0.4.1 changelog section", async () => {
  const changelog = await readFile(join(process.cwd(), "CHANGELOG.md"), "utf8");
  assert.match(changelog, /The three 0\.4\.0 rows marked `Supported` had L2 direct-runtime evidence only/);
  assert.match(changelog, /Those rows did not establish Localmotive product support/);
  assert.match(changelog, /See `release-evidence\/0\.4\.1\/v0\.4\.0-corrective-note\.md` for the proposed public correction/);
});

test("the 0.4.0 corrective note stays review-gated, not silently published", async () => {
  const note = await readFile(join(process.cwd(), "release-evidence", "0.4.1", "v0.4.0-corrective-note.md"), "utf8");
  assert.match(note, /This draft does not modify the published release/);
  assert.match(note, /Review this correction before editing the public 0\.4\.0 release/);
});

test("small icon layers remain readable at native resolution", async () => {
  const { readFile: readBinary } = await import("node:fs/promises");
  const ico = await readBinary(join(process.cwd(), "src-tauri", "icons", "icon.ico"));
  const sizes = await inspectIcoSizes(ico);
  assert.ok(sizes.includes(16), "the 16px layer is missing");
  assert.ok(sizes.includes(32), "the 32px layer is missing");
  // PNG-compressed ICO layers decode to full RGBA pixels: a 16px layer must
  // decode to 16*16*4 bytes, otherwise the small layer is a stub.
  const { inflateSync } = await import("node:zlib");
  const count = ico.readUInt16LE(4);
  for (let index = 0; index < count; index += 1) {
    const offset = 6 + (index * 16);
    const width = ico[offset] || 256;
    if (width > 32) continue;
    const bytes = ico.readUInt32LE(offset + 8);
    const dataOffset = ico.readUInt32LE(offset + 12);
    const chunk = ico.subarray(dataOffset, dataOffset + bytes);
    assert.equal(chunk[0], 0x89, `the ${width}px layer is not a PNG layer`);
    assert.equal(chunk[1], 0x50, `the ${width}px layer is not a PNG layer`);
    const ihdrLength = chunk.readUInt32BE(8);
    const ihdrType = chunk.subarray(12, 16).toString("ascii");
    assert.equal(ihdrType, "IHDR");
    const pngWidth = chunk.readUInt32BE(16);
    const pngHeight = chunk.readUInt32BE(20);
    assert.equal(pngWidth, width, `the ${width}px layer has wrong PNG width`);
    assert.equal(pngHeight, width, `the ${width}px layer has wrong PNG height`);
    assert.ok(ihdrLength >= 13, `the ${width}px layer has a truncated IHDR`);
    void inflateSync;
  }
});

test("the packaged NSIS installer and uninstaller use the LM icon", async () => {
  const config = JSON.parse(await readFile(join(process.cwd(), "src-tauri", "tauri.conf.json"), "utf8"));
  assert.equal(config.bundle?.windows?.nsis?.installerIcon, "icons/icon.ico");
  assert.equal(config.bundle?.windows?.nsis?.uninstallerIcon, "icons/icon.ico");
});

test("frontend renders backend catalog facts without owning support classification", async () => {
  const app = await frontendSources();
  const model = await readFile(join(process.cwd(), "src", "model.ts"), "utf8");
  assert.doesNotMatch(app, /supportStatusForOption/);
  assert.doesNotMatch(model, /supportStatusForOption/);
  assert.doesNotMatch(model, /runtimeRevision:\s*"b10816"/);
  assert.match(app, /runtimeCatalogState\.catalog\.tag/);
});

test("hardware panel does not present heuristic hardware advice as the catalog recommendation", async () => {
  const app = await frontendSources();
  assert.doesNotMatch(app, /hardware\?\.recommendation/);
  assert.match(app, /runtimeCatalog\?\.recommendationReason/);
});

test("runtime setup ignores stale responses and owns a separate loading state", async () => {
  const app = await frontendSources();
  assert.match(app, /\[runtimeCatalogLoading, setRuntimeCatalogLoading\]/);
  assert.match(app, /async function loadRuntimeSetup\(\)[\s\S]*?const sequence = \+\+runtimeCatalogSeq\.current/);
  assert.match(app, /if \(!keepLatestRequest\(sequence, runtimeCatalogSeq\.current\)\) return;/);
  assert.match(app, /disabled=\{(?:props\.)?runtimeCatalogLoading\}/);
});

test("runtime setup invalidates pending responses during unmount", async () => {
  const app = await frontendSources();
  assert.match(
    app,
    /loadRuntimeSetup\(\);[\s\S]*?return \(\) => \{\s*runtimeCatalogSeq\.current \+= 1;/,
  );
});

test("runtime install cancellation is available before progress and ignores stale events", async () => {
  const app = await frontendSources();
  assert.match(app, /const installingRef = useRef\(""\)/);
  assert.match(app, /event\.payload\.installKey === installingRef\.current/);
  assert.match(app, /\{(?:props\.)?installing && \(/);
  assert.doesNotMatch(app, /\{installing && runtimeInstallProgress && \(/);
});

test("managed health progress is correlated to the active install key", async () => {
  const app = await frontendSources();
  const model = await readFile(join(process.cwd(), "src", "model.ts"), "utf8");
  const backend = await readFile(join(process.cwd(), "src-tauri", "src", "runtime_service.rs"), "utf8");
  assert.match(model, /export type HealthModelProgress = \{\s*installKey: string;/);
  assert.match(app, /event\.payload\.installKey === healthRunningRef\.current/);
  assert.match(backend, /HealthModelProgress \{\s*install_key:/);
});

test("runtime and health cancellation expose a pending UI state", async () => {
  const app = await frontendSources();
  assert.match(app, /\[runtimeInstallCancelling, setRuntimeInstallCancelling\]/);
  assert.match(app, /\[healthCancelling, setHealthCancelling\]/);
  assert.match(app, /runtimeInstallCancelling \? "Stopping…"/);
  assert.match(app, /healthCancelling \? "Stopping…"/);
});

test("adapter catalog IPC preserves structured retry metadata", async () => {
  const backend = await readFile(join(process.cwd(), "src-tauri", "src", "runtime_service.rs"), "utf8");
  assert.match(
    backend,
    /async fn fetch_runtime_catalog\([\s\S]*?\) -> Result<runtime::RuntimeCatalog, runtime::RuntimeCatalogError>/,
  );
});

test("branding gate rejects legacy names outside documented history and migration code", () => {
  const legacy = ["GGUF", "Pilot"].join(" ");
  const result = validateBrandingEntries([
    { path: "src/App.tsx", content: `<h1>${legacy}</h1>` },
    { path: "CHANGELOG.md", content: `Renamed ${legacy}.` },
    { path: "src-tauri/src/runtime.rs", content: `runtime_data_dir("${legacy}")` },
  ]);
  assert.equal(result.ok, false);
  assert.deepEqual(result.failures, ["src/App.tsx:legacy-product-name"]);
});

test("qualification gate permits disclosed gaps but never promotes them to support", () => {
  const approvals = {
    decisions: [{
      id: "missing-p0-hardware-evidence",
      status: "RISK_ACCEPTED_WITH_DISCLOSURE",
    }],
  };
  const matrix = {
    rows: [
      { id: "hardware-a", status: "UNKNOWN", supportClaim: false, releaseNotesDisclosed: true, attestation: null },
      { id: "hardware-b", status: "DIRECT_L2", supportClaim: true, releaseNotesDisclosed: true, attestation: null },
    ],
  };
  const result = validateQualification({
    matrix,
    approvals,
    compatibilityRecords: [],
    attestations: new Map(),
    expectedIds: ["hardware-a", "hardware-b"],
  });
  assert.equal(result.ok, false);
  assert.deepEqual(result.failures, ["hardware-b:support-requires-L4_PASS"]);
});

test("qualification gate preserves each frozen P0 hardware and backend scope", () => {
  const result = validateQualification({
    matrix: {
      rows: [{
        id: "hardware-a",
        hardwareClass: "Different GPU",
        os: "Windows 11 x64",
        architecture: "x64",
        backend: "cpu",
        status: "UNKNOWN",
        supportClaim: false,
        releaseNotesDisclosed: true,
        attestation: null,
      }],
    },
    approvals: { decisions: [{ id: "missing-p0-hardware-evidence", status: "RISK_ACCEPTED_WITH_DISCLOSURE" }] },
    compatibilityRecords: [],
    attestations: new Map(),
    expectedIds: ["hardware-a"],
    expectedRows: new Map([["hardware-a", {
      hardwareClass: "Frozen GPU",
      os: "Windows 11 x64",
      architecture: "x64",
      backend: "cuda",
    }]]),
  });
  assert.equal(result.ok, false);
  assert.deepEqual(result.failures, ["hardware-a:frozen-scope-mismatch"]);
});

test("qualification gate rejects a failed attestation on an L4 row", () => {
  const row = {
    id: "hardware-a",
    hardwareClass: "Frozen GPU",
    os: "Windows 11 x64",
    architecture: "x64",
    backend: "cuda",
    status: "L4_PASS",
    supportClaim: true,
    releaseNotesDisclosed: false,
    attestation: "failed-attestation",
  };
  const result = validateQualification({
    matrix: { rows: [row] },
    approvals: { decisions: [] },
    compatibilityRecords: [],
    attestations: new Map([["failed-attestation", {
      id: "failed-attestation",
      p0Id: "hardware-a",
      result: "FAIL",
      evidenceLevel: "L4_PRODUCT",
      qualificationKey: {},
      expiryIdentity: "unchanged",
    }]]),
    expectedIds: ["hardware-a"],
    expectedRows: new Map([["hardware-a", {
      hardwareClass: "Frozen GPU",
      os: "Windows 11 x64",
      architecture: "x64",
      backend: "cuda",
    }]]),
  });
  assert.equal(result.ok, false);
  assert.ok(result.failures.includes("hardware-a:L4-attestation-not-pass"));
});

test("hardware waiver does not waive clean-account lifecycle evidence", () => {
  const result = validateQualification({
    matrix: { rows: [{
      id: "win-x64-clean-account",
      hardwareClass: "Clean Windows x64 account without developer toolkits",
      os: "Windows 11 x64",
      architecture: "x64",
      backend: "all shipped",
      status: "UNKNOWN",
      supportClaim: false,
      releaseNotesDisclosed: true,
      attestation: null,
    }] },
    approvals: { decisions: [{ id: "missing-p0-hardware-evidence", status: "RISK_ACCEPTED_WITH_DISCLOSURE" }] },
    compatibilityRecords: [],
    attestations: new Map(),
    expectedIds: ["win-x64-clean-account"],
    expectedRows: new Map([["win-x64-clean-account", {
      hardwareClass: "Clean Windows x64 account without developer toolkits",
      os: "Windows 11 x64",
      architecture: "x64",
      backend: "all shipped",
    }]]),
  });
  assert.equal(result.ok, false);
  assert.ok(result.failures.includes("win-x64-clean-account:lifecycle-not-waived"));
});

test("research anchor gate rejects changed tracked manifest bytes", () => {
  const anchor = {
    schemaVersion: 1,
    manifestPath: "research/0.4.1/research-freeze.json",
    trackedManifestPath: "release-evidence/0.4.1/research-freeze-manifest.json",
    manifestSha256: "0".repeat(64),
    baseCommit: "a".repeat(40),
    scope: ["research/0.4", "research/0.4.1"],
    excluded: [],
    tree: { algorithm: "sha256-canonical-file-manifest-v1", sha256: "0".repeat(64), files: 0, bytes: 0 },
    productScopeSha256: "0".repeat(64),
  };
  const result = validateResearchAnchor({
    anchor,
    manifestBytes: Buffer.from("{}\n"),
    approvals: { decisions: [{ id: "phase-0a-rebaseline", status: "APPROVED_WITH_CONDITIONS" }] },
  });
  assert.equal(result.ok, false);
  assert.ok(result.failures.includes("anchor:manifest-sha256"));
  const ledgerResult = validateResearchAnchor({
    anchor,
    manifestBytes: Buffer.from("{}\n"),
    approvals: { decisions: [] },
    verification: { freeze: { manifestSha256: "f".repeat(64) } },
  });
  assert.ok(ledgerResult.failures.includes("verification:manifest-sha256"));
});

test("research anchor gate rejects a missing verification ledger", () => {
  const result = validateResearchAnchor({
    anchor: {},
    manifestBytes: Buffer.from("{}\n"),
    approvals: { decisions: [] },
    verification: null,
  });
  assert.ok(result.failures.includes("verification:ledger"));
});

test("research anchor gate rejects fabricated verification counts and commands", () => {
  const result = validateResearchAnchor({
    anchor: {},
    manifestBytes: Buffer.from("{}\n"),
    approvals: { decisions: [] },
    verification: {
      schemaVersion: 1,
      release: "0.4.1",
      commands: ["false"],
      unitTests: { status: "PASS", passed: 1, failed: 0, skipped: 0 },
      researchVerifier: { status: "PASS", corePassed: 1, passed: 1, failed: 0, unknown: 0 },
      freeze: {},
      cleanCheckoutCoverage: {},
      independentReview: { status: "PENDING" },
    },
  });
  assert.ok(result.failures.includes("verification:commands"));
  assert.ok(result.failures.includes("verification:unit-tests"));
  assert.ok(result.failures.includes("verification:research-verifier"));
});

test("research anchor gate rejects an unbound independent-review pass", () => {
  const result = validateResearchAnchor({
    anchor: {},
    manifestBytes: Buffer.from("{}\n"),
    approvals: { decisions: [] },
    verification: {
      independentReview: {
        status: "PASS",
      },
    },
  });
  assert.ok(result.failures.includes("verification:independent-review-report"));
});

test("research anchor gate rejects an untracked independent-review report", () => {
  const report = Buffer.from("Delegation: deleg_1234abcd\nVerdict: PASS\n", "utf8");
  const result = validateResearchAnchor({
    anchor: {},
    manifestBytes: Buffer.from("{}\n"),
    approvals: { decisions: [] },
    verification: {
      independentReview: {
        status: "PASS",
        verdict: "PASS",
        delegationId: "deleg_1234abcd",
        reportPath: "release-evidence/0.4.1/phase0a-independent-review.txt",
        reportSha256: createHash("sha256").update(report).digest("hex"),
      },
    },
    independentReviewBytes: report,
    trackedPaths: new Set(),
  });
  assert.ok(result.failures.includes("verification:independent-review-not-tracked"));
});

test("research anchor gate rejects an independent review for another research tree", () => {
  const report = Buffer.from([
    "Delegation: deleg_1234abcd",
    "Verdict: PASS",
    `Manifest SHA-256: ${"0".repeat(64)}`,
    `Tree SHA-256: ${"0".repeat(64)}`,
    "",
  ].join("\n"), "utf8");
  const result = validateResearchAnchor({
    anchor: {
      manifestSha256: "a".repeat(64),
      tree: { sha256: "b".repeat(64) },
    },
    manifestBytes: Buffer.from("{}\n"),
    approvals: { decisions: [] },
    verification: {
      independentReview: {
        status: "PASS",
        verdict: "PASS",
        delegationId: "deleg_1234abcd",
        reportPath: "release-evidence/0.4.1/phase0a-independent-review.txt",
        reportSha256: createHash("sha256").update(report).digest("hex"),
        manifestSha256: "0".repeat(64),
        treeSha256: "0".repeat(64),
      },
    },
    independentReviewBytes: report,
    trackedPaths: new Set(["release-evidence/0.4.1/phase0a-independent-review.txt"]),
  });
  assert.ok(result.failures.includes("verification:independent-review-tree"));
});

test("packaged verifier checks the reduced benchmark surface", async () => {
  const source = await readFile(join(process.cwd(), "scripts", "verify_041.mjs"), "utf8");
  assert.match(source, /"ui\.benchmark-scope"/);
});

test("packaged verifier contains no private React-state injection (QD-03)", async () => {
  const source = await readFile(join(process.cwd(), "scripts", "verify_041.mjs"), "utf8");
  // The fiber walk and dispatch extraction are gone: presentation states
  // live in the jsdom component tests (src/App.catalog.test.tsx), and the
  // verifier speaks only through the real IPC boundary and the DOM.
  assert.doesNotMatch(source, /__reactFiber\$/);
  assert.doesNotMatch(source, /memoizedState/);
  assert.doesNotMatch(source, /queue\.dispatch/);
  assert.doesNotMatch(source, /__LM_VERIFY_SET_CATALOG/);
  assert.doesNotMatch(source, /__LM_VERIFY_ORIGINAL_INVOKE/);
  assert.doesNotMatch(source, /Page\.addScriptToEvaluateOnNewDocument/);
  // Genuine replacements stay: the real catalog fetch check and the
  // relational card-invariant check.
  assert.match(source, /ipc\.runtime-catalog-fetch/);
  assert.match(source, /ui\.runtime-cards/);
});

test("packaged cancellation check observes progress, records completion or a bounded diagnostic (QD-03)", async () => {
  const source = await readFile(join(process.cwd(), "scripts", "verify_041.mjs"), "utf8");
  assert.match(source, /health-model-progress/);
  assert.match(source, /plugin:event\|listen/);
  const cancellation = source.split("health.cancellation")[1].split("health.restart")[0];
  assert.doesNotMatch(cancellation, /setTimeout\(resolvePromise, 250\)/);
  // The semantic trigger waits for an observed progress phase; fast progress
  // records completion instead of failing; a bounded wait is a diagnostic
  // failure (audit QD-03 V3), and one shared classifier owns the acceptance
  // rules for every observed outcome.
  assert.match(cancellation, /phaseSeen\.then/);
  assert.match(cancellation, /"completed-before-cancel"/);
  assert.match(cancellation, /"bounded-timeout"/);
  assert.match(cancellation, /classifyHealthCancellation\(outcome\)/);
  const classifier = await readFile(
    join(process.cwd(), "scripts", "lib", "health_cancel.mjs"),
    "utf8",
  );
  assert.match(classifier, /completed-before-cancel/);
  assert.match(classifier, /Bounded diagnostic/);
  // The fast/slow fixture legs are wired into the test suite.
  const pkg = JSON.parse(await readFile(join(process.cwd(), "package.json"), "utf8"));
  assert.ok(
    pkg.scripts.test.includes("scripts/tests/health_cancel.test.mjs"),
    "npm test must run the health-cancel fixture legs",
  );
  // The blocked-backend card check binds to the live upstream release; when
  // every required job is green it must report the skip rather than fail on a
  // healthy upstream (the card rendering stays unit-covered).
  assert.match(source, /no blocked backend in the live upstream release/);
});

test("release package job runs the catalog/SQLite packaged matrix (GH-05)", async () => {
  // The orchestration lives in scripts/verify_packaged_impl.ps1 (invoked
  // through the thin wrapper scripts/verify_packaged_matrix.ps1; runs
  // 34819219725/34815989537: inline cleanup's stray $LASTEXITCODE failed
  // green runs); the workflow only passes identities. Assert on the union:
  // the workflow must invoke the wrapper with the run identities, the
  // wrapper must delegate to the impl, and the impl must run every matrix
  // phase.
  const release = await readFile(join(process.cwd(), ".github", "workflows", "release.yml"), "utf8");
  const pkg = release.split("\n  verify:")[1];
  assert.ok(pkg.includes("scripts/verify_packaged_matrix.ps1"), "package job must invoke the committed orchestration script");
  for (const needle of ["-Portable", "-Version", "-ResolvedSha", "-CdpPort"]) {
    assert.ok(pkg.includes(needle), `package job is missing ${needle}`);
  }
  const wrapper = await readFile(join(process.cwd(), "scripts", "verify_packaged_matrix.ps1"), "utf8");
  assert.ok(wrapper.includes("verify_packaged_impl.ps1"), "wrapper must dot-source the impl");
  assert.ok(wrapper.includes("Invoke-PackagedMatrix"), "wrapper must invoke the matrix");
  const script = await readFile(join(process.cwd(), "scripts", "verify_packaged_impl.ps1"), "utf8");
  for (const needle of [
    // The fixture phase now runs through Start-OwnedFixture (owned-handle
    // spawn, exit from the handle); the remaining phases keep their literal
    // verifier invocations so the contract stays greppable.
    "Start-OwnedFixture",
    "verify_060_catalog.mjs\", \"first-fill",
    "verify_060_catalog.mjs\", \"prep",
    "verify_060_catalog.mjs\", \"restart",
    "verify_060_catalog.mjs\", \"merge",
    "LOCALMOTIVE_CATALOG_URL",
    "LOCALMOTIVE_CATALOG_PUBKEY",
    // Tauri known-folder cache paths ignore a redirected LOCALAPPDATA: the
    // verifier must name the catalog cache root inside the isolated profile.
    "LOCALMOTIVE_CATALOG_ROOT",
    "packaged-verification-catalog-$Version.json",
  ]) {
    assert.ok(script.includes(needle), `orchestration impl is missing ${needle}`);
  }
  // Two launches share the isolated profile so the restart phase runs on the
  // same application data the first-fill phase wrote.
  assert.equal((script.match(/doStartCandidate \$CdpPort/g) ?? []).length, 2);
});

test("rich catalog facets keep the backend camelCase contract (GH-05)", async () => {
  const app = await frontendSources();
  const model = await readFile(join(process.cwd(), "src", "model.ts"), "utf8");
  const catalog = await readFile(join(process.cwd(), "src-tauri", "src", "catalog.rs"), "utf8");
  // The Rust struct serializes with rename_all = "camelCase"; a snake_case
  // read left the pipeline state undefined and crashed the catalog render.
  assert.match(catalog, /#\[serde\(rename_all = "camelCase"\)\]\npub struct CatalogFacets/);
  assert.match(app, /rich\.pipelineTags/);
  assert.doesNotMatch(app, /rich\.pipeline_tags/);
  assert.match(model, /pipelineTags: string\[\];/);
  const component = await readFile(join(process.cwd(), "src", "App.catalog.test.tsx"), "utf8");
  assert.match(component, /pipelineTags: \["text-generation"\]/);
});

test("verifier-only catalog overrides stay gated to the isolated verifier profile (GH-05)", async () => {
  const catalog = await readFile(join(process.cwd(), "src-tauri", "src", "catalog.rs"), "utf8");
  assert.match(catalog, /LOCALMOTIVE_VERIFY_ISOLATED_ROOT/);
  assert.match(catalog, /starts_with\("http:\/\/127\.0\.0\.1:"\)/);
  assert.match(catalog, /fn parse_verify_source/);
  const verify = await readFile(join(process.cwd(), "scripts", "verify_060_catalog.mjs"), "utf8");
  assert.match(verify, /LOCALMOTIVE_VERIFY_ISOLATED_ROOT/);
  assert.match(verify, /ed25519|generateKeyPairSync\("ed25519"\)/);
  assert.match(verify, /corrupted-signature/);
  assert.match(verify, /catalog-mirror\.sqlite/);
});

test("component test environment owns the catalog presentation scenarios (QD-02, QD-03)", async () => {
  const source = await readFile(join(process.cwd(), "src", "App.catalog.test.tsx"), "utf8");
  assert.match(source, /@vitest-environment jsdom/);
  assert.match(source, /vi\.mock\("@tauri-apps\/api\/core"/);
  assert.match(source, /No curated model matches these filters/);
  assert.match(source, /COOLDOWN/);
  assert.match(source, /runtime-catalog-message/);
  assert.match(source, /rate-limited|retry after 60 seconds/);
});

test("packaged verifier requires successful health, cancellation, and restart", async () => {
  const source = await readFile(join(process.cwd(), "scripts", "verify_041.mjs"), "utf8");
  assert.match(source, /ipc\.runtime-recommendation/);
  assert.match(source, /ipc\.reject-unknown-adapter/);
  assert.match(source, /ui\.blocked-backend/);
  assert.match(source, /health\.seven-stage-pass/);
  assert.match(source, /health\.cancellation/);
  assert.match(source, /health\.restart/);
});

test("packaged verification schema rejects false-green overall status", async () => {
  const schema = JSON.parse(await readFile(join(process.cwd(), "release-evidence", "packaged-verification.schema.json"), "utf8"));
  const validate = new Ajv({ strict: true }).compile(schema);
  const result = {
    schema_version: "1.0.0",
    verifier: "scripts/verify_041.mjs",
    source_revision: "a".repeat(40),
    source_dirty: true,
    artifact: { name: "candidate.exe", size_bytes: 1, sha256: "0".repeat(64) },
    host_class: { platform: "win32", release: "10.0", architecture: "x64", cpu_model: "CPU", logical_cpus: 1, memory_bytes: 1, adapters: [] },
    started_at: "2026-09-06T00:00:00Z",
    finished_at: "2026-09-06T00:00:01Z",
    checks: [{ id: "candidate.clean-source", criterion: "clean", status: "FAIL", evidence: {}, reason: "dirty" }],
    overall_status: "PASS",
  };
  assert.equal(validate(result), false);
});

test("packaged verification schema rejects false-red overall status", async () => {
  const schema = JSON.parse(await readFile(join(process.cwd(), "release-evidence", "packaged-verification.schema.json"), "utf8"));
  const validate = new Ajv({ strict: true }).compile(schema);
  const result = {
    schema_version: "1.0.0",
    verifier: "scripts/verify_041.mjs",
    source_revision: "a".repeat(40),
    source_dirty: false,
    artifact: { name: "candidate.exe", size_bytes: 1, sha256: "0".repeat(64) },
    host_class: { platform: "win32", release: "10.0", architecture: "x64", cpu_model: "CPU", logical_cpus: 1, memory_bytes: 1, adapters: [] },
    started_at: "2026-09-06T00:00:00Z",
    finished_at: "2026-09-06T00:00:01Z",
    checks: [{ id: "candidate.clean-source", criterion: "clean", status: "PASS", evidence: {}, reason: "" }],
    overall_status: "FAIL",
  };
  assert.equal(validate(result), false);
});

test("candidate inventory rejects a checksum that does not bind the staged bytes", async () => {
  const root = await mkdtemp(join(tmpdir(), "localmotive-inventory-gate-"));
  const names = [
    "Localmotive_0.4.1_x64-setup.exe",
    "Localmotive_0.4.1_x64-portable.exe",
    "Localmotive_0.4.1_x64.msi",
  ];
  for (const name of names) await writeFile(join(root, name), name);
  await writeFile(
    join(root, "SHA256SUMS-0.4.1.txt"),
    names.map((name) => `${"0".repeat(64)}  ${name}`).join("\n") + "\n",
  );
  await assert.rejects(
    verifyCandidateInventory({
      artifactDirectory: root,
      releaseVersion: "0.4.1",
      outputPath: join(root, "inventory.json"),
      sourceRevision: "a".repeat(40),
    }),
    /does not match SHA256SUMS/,
  );
});

test("R10: TLS transport validation parses real structures and matches the pair", async () => {
  const client = await readFile(join(process.cwd(), "src-tauri", "src", "local_client.rs"), "utf8");
  assert.doesNotMatch(client, /does not look like PEM data/, "no marker-only validation remains");
  assert.match(client, /webpki::EndEntityCert::try_from/, "the certificate parses as real X.509");
  assert.match(client, /subject_public_key_info_from_certificate/, "the certificate SPKI is extracted structurally");
  assert.match(client, /subject_public_key_info_from_private_key/, "the key SPKI is derived structurally");
  assert.match(client, /do not belong together/, "a mismatched pair fails");
  assert.match(client, /rustls_pemfile::certs|rustls_pemfile::private_key/, "PEM decoding is strict");
  assert.match(client, /r10_transport_validation_parses_real_x509_and_matches_the_pair/);
});

test("R15: the loopback client never hops, and its bounds are structural", async () => {
  const client = await readFile(join(process.cwd(), "src-tauri", "src", "local_client.rs"), "utf8");
  assert.match(client, /redirect\(reqwest::redirect::Policy::none\(\)\)/, "redirects are never followed");
  assert.match(client, /no_proxy\(\)/, "environment proxies are ignored");
  assert.match(client, /BoundedVec::new\(MAX_LOCAL_REQUEST_BYTES\)/, "bodies serialize through the bounded writer");
  assert.doesNotMatch(client, /serde_json::to_vec\(value\)/, "no unbounded pre-check serialization");
  assert.match(client, /file\.take\(limit \+ 1\)/, "file reads are bounded by the handle");
  for (const name of [
    "r15_a_redirect_is_not_followed_and_the_client_fails_the_call",
    "r15_the_request_body_serializes_through_a_bounded_writer",
    "r15_bounded_file_reads_are_enforced_by_the_read_not_a_metadata_precheck",
  ]) {
    assert.match(client, new RegExp(name));
  }
});

test("R07: preservation fixtures carry real released-version data, not markers", async () => {
  const { readFile } = await import("node:fs/promises");
  const { join } = await import("node:path");
  const root = join(process.cwd(), "scripts", "sandbox");
  const generator = await readFile(join(root, "build_preservation_fixture.py"), "utf8");
  // Provenance: the generator cites the released sources it mirrors.
  assert.match(generator, /git show v0\.5\.0:src-tauri\/src\/catalog_db\.rs/);
  assert.match(generator, /git show v0\.4\.1:src-tauri\/src\/catalog\.rs/);
  // The committed mirror fixture really carries the v0.5.0 schema and the
  // user-override sentinels (decoded content, not a file-name check).
  const b64 = (await readFile(join(root, "canary-mirror.sqlite.b64"), "utf8")).trim();
  const mirror = Buffer.from(b64, "base64");
  assert.ok(mirror.length > 4096, "the fixture is a real SQLite database");
  for (const needle of [
    "USER-OVERRIDE-SENTINEL-0.6-preservation",
    "NODE-ROW-SENTINEL-0.6-preservation",
    "catalog_model",
    "catalog_file",
    "fixture/user-override",
  ]) {
    assert.ok(mirror.includes(needle), `mirror fixture contains ${needle}`);
  }
  // The v0.4.1 cache record fixture is a real CacheRecord with a schema-1 body.
  const cache = JSON.parse(await readFile(join(root, "canary-catalog-cache.json"), "utf8"));
  assert.ok("body" in cache && "etag" in cache, "cache fixture is a CacheRecord");
  assert.equal(JSON.parse(cache.body).schemaVersion, 1, "the cache body is the v0.4.1 schema");
  // The verifier asserts recovery, not a marker row.
  const verifier = await readFile(join(root, "verify_preservation.py"), "utf8");
  assert.match(verifier, /user_sourced/, "the verifier checks ownership flags");
  assert.match(
    verifier,
    /models field is not an array/,
    "a models:string cache body fails the released v0.4.1 array contract",
  );
  assert.match(verifier, /USER-OVERRIDE-SENTINEL-0\.6-preservation/);
  assert.doesNotMatch(verifier, /canary_marker/, "the marker-only check is gone");
  // The harness plants per flavor and the workflow runs the baseline matrix.
  const host = await readFile(join(root, "host-run-lifecycle.ps1"), "utf8");
  const sandbox = await readFile(join(root, "run-lifecycle-in-sandbox.ps1"), "utf8");
  assert.match(host, /PreservationFlavor/);
  assert.match(sandbox, /canary-catalog-cache\.json/);
  const release = await readFile(join(process.cwd(), ".github", "workflows", "release.yml"), "utf8");
  for (const leg of [
    "sandbox-clean-account-lifecycle-upgrade-v0.4.0",
    "sandbox-clean-account-lifecycle-upgrade-v0.5.0",
    "sandbox-clean-account-lifecycle-preservation-v0.4.1",
    "sandbox-clean-account-lifecycle-preservation-v0.5.0",
  ]) {
    assert.match(release, new RegExp(leg), `release matrix includes ${leg}`);
  }
  assert.match(release, /PreservationFlavor \$leg\.Flavor/);
});

test("R11: the packaged cancellation driver measures owned identities end to end", async () => {
  const driver = await readFile(join(process.cwd(), "scripts", "g05_mt06_cycles.mjs"), "utf8");
  // Owned process identities: parent-scoped to the app PID, never name counts
  // that silently report zero on enumeration failure.
  assert.match(driver, /ParentProcessId -eq \$\{APP_PID\}/);
  assert.doesNotMatch(driver, /tasklist/, "no process-name counting remains");
  assert.match(driver, /enumeration failure THROWS/);
  assert.doesNotMatch(driver, /catch \{\s*return 0;\s*\}/s, "enumeration errors are not counted as zero");
  // The cancel is coordinated with server-side acceptance.
  assert.match(driver, /llamacpp:requests_processing/);
  assert.match(driver, /cancel only AFTER the server reports the request in flight/);
  // The persisted terminal record is asserted, not just the caller state.
  assert.match(driver, /terminalOutcome === "cancelled"/);
  // Bounded cleanup latency.
  assert.match(driver, /RUN_SETTLE_BOUND_MS/);
  assert.match(driver, /DRAIN_BOUND_MS/);
  // F9-01: the restart proof is exercised on one surface per scenario, the
  // coverage sample is taken immediately before the invocation, the verdicts
  // come from the pure rules (with their own controls), and a retry can never
  // substitute its record for the original assertion.
  assert.match(driver, /runBoundaryScenario\("ui"\)/);
  assert.match(driver, /runBoundaryScenario\("api"\)/);
  assert.match(driver, /from "\.\/lib\/mt06_verdicts\.mjs"/);
  assert.match(driver, /processingBeforeInvocation = await metricsField\("llamacpp:requests_processing"\)/);
  assert.match(driver, /processingAfterInvocation = await metricsField\("llamacpp:requests_processing"\)/);
  assert.match(driver, /processingAfterInvocation: attempt\.processingAfterInvocation/);
  assert.match(
    driver,
    /overlap = attempt\.processingAfterInvocation === "2"/,
    "the overlap window opens with the immediate after-sample, not after settling",
  );
  assert.doesNotMatch(driver, /finalAttempt/, "the combined UI+API attempt is gone");
  assert.doesNotMatch(
    driver,
    /record = recordRetry/,
    "a retry must never overwrite the original run's record",
  );
  assert.match(driver, /one-record-identity/);
  assert.match(driver, /active-request-coverage/);
  assert.match(driver, /replacement-ran-after-cleanup/);
  const verdicts = await readFile(join(process.cwd(), "scripts", "lib", "mt06_verdicts.mjs"), "utf8");
  assert.match(verdicts, /NOT-EXERCISED/);
  assert.match(verdicts, /processingAfterInvocation/);
  assert.match(verdicts, /coverage === "overlap"/);
  // Correction pass: only a valid count above "1" is overlap; "0" is a
  // drained interval and null/missing/error is an unavailable observation.
  // Both are not-exercised, and missing evidence never earns active credit.
  assert.match(verdicts, /afterNumeric > 1/);
  assert.match(verdicts, /drained within the observation interval/);
  assert.match(verdicts, /observation after the invocation is unavailable/);
  assert.match(verdicts, /coverageDetail/);
  assert.match(verdicts, /evaluateProhibited/);
  assert.match(verdicts, /evaluateIdentity/);
  // A source/digest-bound result file is written.
  assert.match(driver, /localmotive\.mt06-cancellation\.v1/);
  assert.match(driver, /MT06_EVIDENCE_PATH/);
  assert.match(driver, /sourceRevision: sourceRevisionArg/);
});

test("R13: publication rechecks the tag and trusts exact bytes, with failure diagnostics", async () => {
  const promote = await readFile(join(process.cwd(), ".github", "workflows", "release-promote.yml"), "utf8");
  const publish = promote.split("\n  publish:")[1];
  // The remote tag is re-resolved immediately before publication.
  assert.match(publish, /Re-resolve the remote tag immediately before publication/);
  assert.match(publish, /refs\/tags\/\$\{TAG\}\^\{\}/);
  assert.match(publish, /refusing to publish drifted source/);
  // The public inventory and the packaged-verification record are byte-checked
  // and re-verified against the producer set, never trusted because nonempty.
  assert.match(publish, /cmp "qualified\/artifacts\/candidate-inventory-\$\{VERSION\}\.json" "public-readback\/candidate-inventory-\$\{VERSION\}\.json"/);
  assert.match(publish, /cmp "qualified\/artifacts\/packaged-verification-\$\{VERSION\}\.json" "public-readback\/packaged-verification-\$\{VERSION\}\.json"/);
  assert.match(publish, /verify_candidate_inventory\.mjs --verify "public-readback\/candidate-inventory/);
  // A failed read-back still leaves diagnostics.
  assert.match(publish, /publish-diagnostics/);
  // Success retains the qualified bundle; failure and cancellation retain diagnostics.
  const steps = (await loadWorkflows(process.cwd()))["release.yml"].jobs.verify.steps;
  const diagnostics = steps.find((step) => step.name === "Retain diagnostics after failure or cancellation");
  assert.equal(diagnostics.if, "failure() || cancelled()");
  assert.match(diagnostics.with.path, /attestations\/\*/);
  assert.equal(diagnostics.with["retention-days"], 90);
  // The review text no longer conflates workflow artifacts with release assets.
  const review = await readFile(join(process.cwd(), "docs", "RELEASE-REVIEW-0.6.md"), "utf8");
  assert.doesNotMatch(review, /Expected assets: the MSI, NSIS setup, portable exe, `SHA256SUMS`, the SBOM/);
  assert.match(review, /WORKFLOW ARTIFACTS retained for 90 days/);
});

test("R09: installed version identity is exact and payload expectations are stated", async () => {
  const sandbox = await readFile(join(process.cwd(), "scripts", "sandbox", "run-lifecycle-in-sandbox.ps1"), "utf8");
  assert.doesNotMatch(sandbox, /StartsWith\(\$expected\)/, "no near-miss version identity");
  assert.match(sandbox, /expected executable version \$expected exactly/);
  assert.match(sandbox, /installedPayloadNote = /);
  assert.match(sandbox, /nsisPayloadDigest = /);
  assert.match(sandbox, /msiPayloadDigest = /);
});

test("R12: the published-inventory consumer fails closed on schema, set, and identity drift", async () => {
  const root = await mkdtemp(join(tmpdir(), "localmotive-consumer-gate-"));
  const names = [
    "Localmotive_0.4.1_x64-setup.exe",
    "Localmotive_0.4.1_x64-portable.exe",
    "Localmotive_0.4.1_x64.msi",
  ];
  for (const name of names) await writeFile(join(root, name), name);
  const { createHash } = await import("node:crypto");
  const digest = (text) => createHash("sha256").update(text).digest("hex");
  await writeFile(
    join(root, "SHA256SUMS-0.4.1.txt"),
    `${names.map((name) => `${digest(name)}  ${name}`).join("\n")}\n`,
  );
  const good = {
    schemaVersion: 1,
    release: "0.4.1",
    sourceRevision: "a".repeat(40),
    checksumFile: "SHA256SUMS-0.4.1.txt",
    artifacts: names.map((name) => ({ name, sizeBytes: name.length, sha256: digest(name) })),
  };
  const writeInventory = async (mutate) => {
    const record = JSON.parse(JSON.stringify(good));
    mutate(record);
    const path = join(root, `inventory-${Math.random().toString(16).slice(2)}.json`);
    await writeFile(path, JSON.stringify(record, null, 2));
    return path;
  };
  const verify = (path, extra = {}) =>
    verifyPublishedInventory({
      artifactDirectory: root,
      inventoryPath: path,
      expectedSourceRevision: "a".repeat(40),
      expectedRelease: "0.4.1",
      ...extra,
    });

  // The untouched record verifies (sanity: the fixture itself is valid).
  await verify(await writeInventory(() => {}));
  await assert.rejects(verify(await writeInventory((r) => { r.schemaVersion = 2; })), /schema 2 is not supported/);
  await assert.rejects(verify(await writeInventory((r) => { r.release = "0.4.2"; })), /expected 0.4.1/);
  await assert.rejects(
    verify(await writeInventory((r) => { r.artifacts.push({ ...r.artifacts[0] }); })),
    /duplicate artifact/,
  );
  await assert.rejects(
    verify(await writeInventory((r) => { r.artifacts[1].name = "Localmotive_0.4.1_x64-extra.exe"; })),
    /exact release asset set/,
  );
  await assert.rejects(
    verify(await writeInventory((r) => { r.artifacts.splice(2, 1); })),
    /exact release asset set/,
  );
  await assert.rejects(
    verify(await writeInventory((r) => { r.artifacts = []; })),
    /lists no artifacts/,
  );
  await assert.rejects(
    verify(await writeInventory(() => {}), { expectedRelease: "9.9.9" }),
    /expected 9.9.9/,
  );
});

test("signed build configuration requires certificate-store identity and timestamp verification", async () => {
  const config = JSON.parse(await readFile(
    join(process.cwd(), "src-tauri", "tauri.signing.conf.json"),
    "utf8",
  ));
  const script = await readFile(join(process.cwd(), "scripts", "sign-windows.ps1"), "utf8");
  assert.match(config.bundle.windows.signCommand, /sign-windows\.ps1/);
  assert.match(script, /LOCALMOTIVE_SIGNING_THUMBPRINT/);
  assert.match(script, /LOCALMOTIVE_TIMESTAMP_URL/);
  assert.match(script, /verify \/pa \/all \/v/);
  assert.match(script, /TimeStamperCertificate/);
  assert.doesNotMatch(script, /Export-PfxCertificate|ConvertTo-SecureString/);
});

test("hardware qualify workflow pins every remote action and owns the host proof", async () => {
  const workflow = await readFile(join(process.cwd(), ".github", "workflows", "hardware-qualify.yml"), "utf8");
  assert.doesNotMatch(workflow, /uses:\s*actions\/checkout@v/);
  assert.doesNotMatch(workflow, /uses:\s*actions\/upload-artifact@v/);
  assert.match(workflow, /actions\/checkout@fbc6f3992d24b796d5a048ff273f7fcc4a7b6c09/);
  assert.match(workflow, /actions\/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a/);
  // The clean-account lifecycle moved to release.yml (audit GH-03); this
  // workflow owns the host attestation job only.
  assert.doesNotMatch(workflow, /clean-account-lifecycle/);
  const release = await readFile(join(process.cwd(), ".github", "workflows", "release.yml"), "utf8");
  assert.match(release, /host-run-lifecycle\.ps1/);
  const generator = await readFile(
    join(process.cwd(), "scripts", "qualification", "build_host_attestation.mjs"),
    "utf8",
  );
  assert.match(generator, /supportClaimPolicy/);
});

test("hardware qualify attestation block parses under pwsh (U06-03)", async () => {
  // Run 34819219650: a trailing quote after the NO_MATCH throw made the
  // whole step a PowerShell parser error. The emitted block must parse.
  const { execFile } = await import("node:child_process");
  const workflow = await readFile(join(process.cwd(), ".github", "workflows", "hardware-qualify.yml"), "utf8");
  const at = workflow.indexOf("Derive and write the host attestation");
  assert.ok(at >= 0, "attestation step is missing");
  const runAt = workflow.indexOf("run: |", at);
  const nextStep = workflow.indexOf("\n      - name:", runAt);
  const block = workflow.slice(runAt + "run: |".length, nextStep);
  // No line may end with a stray quote after the closing brace (the exact
  // E07 defect shape).
  for (const line of block.split("\n")) {
    assert.doesNotMatch(line, /\}"+\s*$/, `stray trailing quote: ${line.trim()}`);
  }
  // Parse the block with the real PowerShell parser (pwsh is the workflow's
  // declared shell for this step).
  await new Promise((resolve, reject) => {
    const child = execFile(
      "pwsh",
      ["-NoProfile", "-Command", "$e=$null;[System.Management.Automation.Language.Parser]::ParseInput([Console]::In.ReadToEnd(),[ref]$null,[ref]$e)|Out-Null;if($e.Count-gt0){$e[0].Message;exit 1}"],
      (error, stdout) => (error ? reject(new Error(`pwsh parse failed: ${stdout}`)) : resolve()),
    );
    child.stdin.write(block);
    child.stdin.end();
  });
  assert.match(workflow, /build_host_attestation\.mjs/);
});

test("hardware qualify workflow cannot claim L4 support from host match alone", async () => {
  const workflow = await readFile(join(process.cwd(), ".github", "workflows", "hardware-qualify.yml"), "utf8");
  const generator = await readFile(
    join(process.cwd(), "scripts", "qualification", "build_host_attestation.mjs"),
    "utf8",
  );
  // Statuses are DERIVED from detected hardware (audit GH-10): no static
  // HOST_MATCH rows exist in the workflow, and the generator's policy string
  // keeps host presence separate from packaged L4 qualification.
  assert.doesNotMatch(workflow, /status = "HOST_MATCH"/);
  assert.match(workflow, /build_host_attestation\.mjs/);
  assert.match(generator, /schema: "localmotive\.attestation\.v0"/);
  assert.match(generator, /supportClaimPolicy:/);
  assert.doesNotMatch(generator, /L4_PASS"/);
  assert.match(generator, /Packaged L4 checks still required\./);
});

test("workflow gate policy covers the hardware qualify night path", async () => {
  const policy = JSON.parse(await readFile(join(process.cwd(), ".github", "workflow-gates.json"), "utf8"));
  assert.ok(policy.workflows["hardware-qualify.yml"]);
  // The lifecycle gate moved to release.yml with the job (audit GH-03).
  assert.deepEqual(Object.keys(policy.workflows["hardware-qualify.yml"].gates).sort(), ["hardware-qualify"]);
  assert.deepEqual(policy.workflows["hardware-qualify.yml"].packageJobs, {});
  assert.ok(policy.workflows["release.yml"].gates.verify);
  assert.equal(
    policy.workflows["release.yml"].requiredCommands.verify.filter((command) => command.includes("host-run-lifecycle.ps1")).length,
    1,
  );
});

test("release ship gates default to the self-hosted runner, never windows-latest", async () => {
  const verify = await readFile(join(process.cwd(), ".github", "workflows", "release.yml"), "utf8");
  assert.doesNotMatch(verify, /runs-on:\s*windows-latest/);
  for (const job of ["resolve", "rust-audit", "verify"]) {
    const pattern = new RegExp(`^  ${job}:[\\s\\S]*?runs-on:\\s*(.+)$`, "m");
    const found = verify.match(pattern);
    assert.ok(found, `${job} runs-on is missing`);
    assert.match(found[1], /self-hosted/);
    assert.match(found[1], /localmotive-hw/);
  }
  const promote = await readFile(join(process.cwd(), ".github", "workflows", "release-promote.yml"), "utf8");
  assert.doesNotMatch(promote, /runs-on:\s*windows-latest/);
  for (const job of ["gate", "publish"]) {
    const pattern = new RegExp(`^  ${job}:[\\s\\S]*?runs-on:\\s*(.+)$`, "m");
    const found = promote.match(pattern);
    assert.ok(found, `${job} runs-on is missing`);
    assert.match(found[1], /self-hosted/);
    assert.match(found[1], /localmotive-hw/);
  }
});

test("release checkout pins line endings so the packaged clean-source probe is honest", async () => {
  for (const file of ["release.yml", "release-promote.yml"]) {
    const workflow = await readFile(join(process.cwd(), ".github", "workflows", file), "utf8");
    assert.doesNotMatch(workflow, /git-config:/);
    assert.match(workflow, /git config --global core\.autocrlf false/);
  }
});

test("no working-tree source file is a line-ending-only rewrite of its committed bytes", async () => {
  // Seen live (R16 freeze-9): a tool rewrote two Rust sources with CRLF while
  // the index tracks LF, so `git diff` reported 4300 changed lines of pure
  // line-ending churn and a byte-sensitive consumer would read the wrong
  // file. This guard fails whenever git reports a modified source or harness
  // file whose content equals its committed blob after CRLF -> LF
  // normalization: a real change always differs beyond line endings.
  const { execFileSync } = await import("node:child_process");
  const status = execFileSync("git", ["status", "--porcelain", "-z"], { encoding: "utf8", cwd: process.cwd() });
  const modified = status
    .split("\0")
    .filter(Boolean)
    // Deleted scripts have no working-tree bytes to compare.
    .filter((entry) => !entry.slice(0, 2).includes("D"))
    .map((entry) => entry.slice(3))
    .filter((path) => /(^|\/)(src|scripts|src-tauri\/src|src-tauri\/tests|\.github)\/.*\.(rs|mjs|ps1|ts|tsx|json|yml|yaml)$/.test(path));
  // A clean tree has nothing to inspect and must pass: this guard fails only
  // when a modified file's content is line-ending churn.
  const CRLF = String.fromCharCode(13) + String.fromCharCode(10);
  const LF = String.fromCharCode(10);
  const offenders = [];
  for (const file of modified) {
    let committed = null;
    try {
      committed = execFileSync("git", ["show", `HEAD:${file}`], { cwd: process.cwd(), maxBuffer: 32 * 1024 * 1024 });
    } catch {
      continue; // a brand-new file has no committed bytes to compare
    }
    const committedBytes = Buffer.from(committed);
    const normalized = Buffer.from(committedBytes.toString("latin1").split(CRLF).join(LF), "latin1");
    const worktree = await readFile(join(process.cwd(), file));
    const worktreeLf = Buffer.from(worktree.toString("latin1").split(CRLF).join(LF), "latin1");
    if (normalized.length === worktreeLf.length && normalized.equals(worktreeLf) && !worktree.equals(committedBytes)) {
      offenders.push(file);
    }
  }
  assert.deepEqual(offenders, [], `line-ending-only rewrites present in: ${offenders.join(", ")}`);
});

test("packaged clean-source probe ignores the verifier-owned artifacts directory", async () => {
  const source = await readFile(join(process.cwd(), "scripts", "verify_041.mjs"), "utf8");
  assert.match(source, /artifacts/);
});

test("packaged clean-source probe ignores the workflow-owned SBOM output", async () => {
  // Seen live (Release verify run 34803387581): the package job writes
  // sbom.cdx.json into the checkout root before verify_041 runs, so the
  // untracked SBOM tripped candidate.clean-source and failed the run even
  // though the source was clean. The probe must exclude it alongside
  // artifacts/.
  const source = await readFile(join(process.cwd(), "scripts", "verify_041.mjs"), "utf8");
  assert.match(source, /sbom\.cdx\.json/);
});

test("packaged rejection detail preserves the backend error message", async () => {
  const source = await readFile(join(process.cwd(), "scripts", "verify_041.mjs"), "utf8");
  assert.match(source, /errorText/);
  assert.match(source, /hardware snapshot/);
  // CDP returnByValue stringifies thrown objects: the verifier must
  // serialize the raw IPC error inside the page, or kind is lost.
  assert.match(source, /JSON\.stringify\(error\)/);
  assert.match(source, /invalidResponse/);
});

test("release verify step exposes the resolved revision to every verifier phase", async () => {
  // Seen live (Release verify run 34807541476): the merge phase of
  // verify_060_catalog.mjs records source_revision from
  // LOCALMOTIVE_SOURCE_REVISION, but the "Verify the packaged executable"
  // step only set it mid-script after the restart phase, so the merged
  // record carried UNKNOWN and the step failed after all phases passed.
  // Every phase inherits the resolved SHA before it starts.
  const job = (await loadWorkflows(process.cwd()))["release.yml"].jobs.verify;
  assert.ok(job.steps.some((step) => step.name === "Verify the packaged executable"));
  for (const step of job.steps) {
    assert.equal(step.env?.LOCALMOTIVE_SOURCE_REVISION ?? job.env.LOCALMOTIVE_SOURCE_REVISION,
      "${{ needs.resolve.outputs.sha }}", `${step.name ?? step.uses} must retain the resolved revision`);
  }
});

test("release verify step waits for the candidate WebView before driving checks", async () => {
  // The launch helper lives in scripts/verify_packaged_impl.ps1 (invoked
  // through the wrapper); the workflow only invokes the wrapper. Assert the
  // helper waits (not sleeps) and both launches go through it.
  const script = await readFile(join(process.cwd(), "scripts", "verify_packaged_impl.ps1"), "utf8");
  assert.match(script, /function Start-Candidate/);
  assert.match(script, /Start-Process \$Portable/);
  // A fixed sleep races WebView startup: the launch helper must poll the
  // CDP endpoint until the page appears instead of assuming readiness, and
  // every verifier run must go through the helper (two launches for the
  // catalog restart matrix).
  assert.match(script, /json\/list/);
  assert.equal((script.match(/doStartCandidate \$CdpPort/g) ?? []).length, 2);
});

test("release workflow serializes runs so two packages never share one runner", async () => {
  const release = await readFile(join(process.cwd(), ".github", "workflows", "release.yml"), "utf8");
  // Tag-push and dispatch each ran package on the same single runner; the
  // second CDP session attached to the first WebView.
  assert.match(release, /concurrency:\s*\n\s*group:\s*localmotive-release/);
  assert.match(release, /cancel-in-progress:\s*true/);
  // A promotion is never cancelled by a later tag push: it owns its own group
  // and refuses cancellation.
  const promote = await readFile(join(process.cwd(), ".github", "workflows", "release-promote.yml"), "utf8");
  assert.match(promote, /concurrency:\s*\n\s*group:\s*localmotive-release-promote/);
  assert.match(promote, /cancel-in-progress:\s*false/);
});

test("release verify step isolates the candidate behind a per-run CDP port with owned-handle cleanup", async () => {
  const release = await readFile(join(process.cwd(), ".github", "workflows", "release.yml"), "utf8");
  const script = await readFile(join(process.cwd(), "scripts", "verify_packaged_impl.ps1"), "utf8");
  // Fixed port 10041 plus parent-only Stop-Process leaves an orphan
  // WebView2 holding CDP; the next run attaches to the stale page.
  // RED: the step hard-codes one port with no pre/post cleanup. The port is
  // unique per run (GITHUB_RUN_ID), every path is attempt-scoped
  // ($AttemptId), and only OWNED handles are ever stopped -- no port scans,
  // no process-name scans, no taskkill-by-pid (runs 34819219725: a final
  // taskkill of the already-dead fixture pid failed green runs).
  assert.match(release, /GITHUB_RUN_ID/);
  assert.match(script, /\$AttemptId/);
  assert.match(script, /Stop-OwnedProcess/);
  assert.doesNotMatch(script, /taskkill/);
  assert.match(script, /webSocketDebuggerUrl/);
});

test("release verify orchestration never lets cleanup set the step outcome", async () => {
  // Runs 34819219725/34815989537: every verifier passed, then a final
  // taskkill of an already-dead fixture pid left a stray $LASTEXITCODE and
  // the step failed with no error text. The orchestration script must check
  // each native exit code immediately, preserve the verifier failure when
  // cleanup also struggles, and derive the final exit only from recorded
  // outcomes -- never from a stray $LASTEXITCODE.
  const script = await readFile(join(process.cwd(), "scripts", "verify_packaged_matrix.ps1"), "utf8");
  const impl = await readFile(join(process.cwd(), "scripts", "verify_packaged_impl.ps1"), "utf8");
  assert.match(impl, /\$LASTEXITCODE/);
  assert.match(impl, /already-stopped/);
  assert.match(impl, /still-alive/);
  assert.match(impl, /RESULT: PASS/);
  assert.match(impl, /RESULT: FAIL/);
  assert.match(impl, /finally/);
  // U06-01: the wrapper holds no logic of its own -- the impl owns the
  // orchestration, and the wrapper maps its return code to `exit`.
  assert.match(script, /verify_packaged_impl\.ps1/);
  assert.match(script, /Invoke-PackagedMatrix/);
  assert.match(script, /exit \$code/);
  assert.doesNotMatch(script, /taskkill/);
  const release = await readFile(join(process.cwd(), ".github", "workflows", "release.yml"), "utf8");
  assert.match(release, /verify_packaged_matrix\.ps1/);
  assert.match(release, /if \(\$LASTEXITCODE -ne 0\) \{ throw "Packaged verification orchestration failed/);
});

test("packaged-orchestration cleanup matrix runs in CI under pwsh (U06-01)", async () => {
  // The matrix drives the REAL Invoke-PackagedMatrix path; if CI stops
  // running it, a cleanup regression reaches the release workflow unseen.
  const ci = await readFile(join(process.cwd(), ".github", "workflows", "ci.yml"), "utf8");
  for (const job of ["  check:", "  pr-check:"]) {
    const at = ci.indexOf(job);
    assert.ok(at >= 0, `${job} job is missing`);
    const block = ci.slice(at, at + 12000);
    assert.match(block, /verify_cleanup_matrix\.ps1/, `${job} must run the cleanup matrix`);
    assert.match(block, /shell: pwsh/, `${job} matrix step must use pwsh`);
  }
  const policy = JSON.parse(await readFile(join(process.cwd(), ".github", "workflow-gates.json"), "utf8"));
  for (const job of ["check", "pr-check"]) {
    assert.ok(
      policy.workflows["ci.yml"].gates[job].includes("pwsh -NoProfile -File scripts/tests/verify_cleanup_matrix.ps1"),
      `workflow-gates.json must pin the matrix in ${job}`,
    );
  }
});

test("candidate still-alive fails the run and preserves the verifier error (U06-01)", async () => {
  // The reviewed revision only recorded "candidate still-alive" in the notes
  // while the final exit stayed 0. The impl must fail the run and keep an
  // earlier verifier error as the prefix.
  const impl = await readFile(join(process.cwd(), "scripts", "verify_packaged_impl.ps1"), "utf8");
  const stop = impl.slice(impl.indexOf("function Stop-Candidate"));
  assert.match(stop, /\$script:functionalFailed = \$true/);
  assert.match(stop, /candidate still-alive after cleanup deadline/);
});

test("fixture adoption refuses unverified identity (U06-01)", async () => {
  // The reviewed revision accepted ANY node process when the CIM lookup
  // threw. The impl must refuse: CIM failure, missing command line, and a
  // foreign command line all refuse adoption.
  const impl = await readFile(join(process.cwd(), "scripts", "verify_packaged_impl.ps1"), "utf8");
  assert.match(impl, /function Get-FixtureAdoption/);
  assert.match(impl, /identity is unverified \(CIM lookup failed/);
  assert.match(impl, /has no readable command line; refusing to adopt/);
  assert.match(impl, /does not belong to this attempt; refusing to adopt/);
});

test("release publish verification avoids hosted-only shell dependencies", async () => {
  for (const file of ["release.yml", "release-promote.yml"]) {
    const workflow = await readFile(join(process.cwd(), ".github", "workflows", file), "utf8");
    // Git-bash on the self-hosted runner has no jq: parse the inventory and
    // the run metadata with node so the gates cannot fail on missing tooling.
    assert.doesNotMatch(workflow, /jq -r/);
  }
});

test("a tag push verifies without publishing and publication needs explicit authorization", async () => {
  // R16 release behavior: the tag push runs every gate, assembles the
  // qualified bundle, and stops. Publication is a separate workflow that
  // refuses to run without the owner, the confirm phrase, a green verify run
  // for the same commit, and dry_run=false.
  const verify = await readFile(join(process.cwd(), ".github", "workflows", "release.yml"), "utf8");
  assert.doesNotMatch(verify, /softprops\/action-gh-release/);
  assert.doesNotMatch(verify, /gh release create/);
  assert.doesNotMatch(verify, /contents: write/);
  assert.match(verify, /localmotive-\$\{\{ needs\.resolve\.outputs\.version \}\}-qualified/);
  const promote = await readFile(join(process.cwd(), ".github", "workflows", "release-promote.yml"), "utf8");
  assert.match(promote, /github\.actor == github\.repository_owner/);
  assert.match(promote, /PUBLISH \$TAG/);
  assert.match(promote, /^\s*dry_run:/m);
  assert.match(promote, /default: true/, "a promotion defaults to a dry run");
  assert.match(promote, /if: inputs\.dry_run == false/, "publication requires dry_run=false");
  assert.match(promote, /run-id: \$\{\{ inputs\.verify_run_id \}\}/);
  assert.match(promote, /Release verify/, "the verify run identity is checked by name");
  assert.match(promote, /check-runs/);
  assert.match(promote, /pr-check/);
  assert.doesNotMatch(promote, /tauri build|npm run build/, "promotion never rebuilds the candidate");
});

test("branding history set covers the archived docs layout", async () => {
  const source = await readFile(join(process.cwd(), "scripts", "verify_branding.mjs"), "utf8");
  // Docs cleanup moves design/product/branding/llama-server notes under
  // docs/ and completed TODOs under docs/history/. The branding gate
  // must keep covering those paths after the move.
  // RED: HISTORICAL_FILES pins root paths that will no longer exist.
  assert.match(source, /docs\/history\/TODO-0\.4\.1\.md/);
  // The universal 0.6 tracker lives at the repository root; the gate must
  // cover it too, since it imports the RT-01 legacy-migration criterion text.
  assert.match(source, /"TODO-0\.6\.md"/);
});

test("local catalog SQLite mirror stores verified models with migrations and controlled recovery", async () => {
  const mirror = await readFile(join(process.cwd(), "src-tauri", "src", "catalog_db.rs"), "utf8");
  assert.match(mirror, /catalog_db_path/);
  assert.match(mirror, /CATALOG_DB_SCHEMA_VERSION/);
  // Audit DC-03: recovery quarantines the previous file and rebuilds from
  // verified bytes; the old silent rebuild symbol is gone for good.
  assert.match(mirror, /recover_catalog_db_from_verified/);
  assert.doesNotMatch(mirror, /rebuild_catalog_db_from_verified/);
  assert.match(mirror, /quarantine/);
  assert.match(mirror, /read_catalog_db_models/);
  assert.match(mirror, /mirror_verified_catalog/);
  assert.match(mirror, /migrate_catalog_db/);
});

test("catalog browse uses one merged collection and never the snapshot alone", async () => {
  const app = await frontendSources();
  // Audit DC-04: rows and facets are filtered from the merged local
  // collection, so user rows survive filtering and facets stay truthful.
  assert.match(app, /models: catalogAllRows/);
  assert.doesNotMatch(app, /models: catalogSnapshot\.catalog\.models/);
});

test("override saves reject mixed-origin collisions inside an immediate transaction", async () => {
  const mirror = await readFile(join(process.cwd(), "src-tauri", "src", "catalog_db.rs"), "utf8");
  // Audit DC-05/DC-06: ownership is reserved with actionable rejections, and
  // replacement runs in an IMMEDIATE transaction so reads inside it cannot
  // race a concurrent writer.
  assert.match(mirror, /belongs to a curated catalog entry and cannot be replaced/);
  assert.match(mirror, /belongs to the curated catalog and cannot be reused/);
  assert.match(mirror, /already belongs to the local override/);
  assert.match(mirror, /transaction_with_behavior\(rusqlite::TransactionBehavior::Immediate\)/);
});

test("FE-01 selection and runtime commit as coordinated transitions", async () => {
  const app = await frontendSources();
  // No silent fallback to another model, rescan preserves the committed
  // selection (or loads the replacement), failures clear together, and one
  // committed-runtime transition keeps profile.runtime in sync only after a
  // successful inspection (audit FE-01).
  assert.doesNotMatch(app, /\?\? models\[0\]/);
  assert.match(app, /selectionAfterRescan\(result, selectedId\)/);
  assert.match(app, /clearCommittedSelection\(\)/);
  assert.match(
    app,
    /function commitRuntime\(path: string, caps: RuntimeCapabilities, identity: RuntimeIdentity\)/,
  );
  assert.doesNotMatch(app, /if \(profile\) setProfile\(\{ \.\.\.profile, runtime: path \}\);/);
  assert.match(app, /commitRuntime\(path, caps, identity\);/);
});

test("FE-02 tuning adoption binds to the originating run", async () => {
  const app = await frontendSources();
  // The dispatch record captures provider/advisor/context; the report keeps
  // its origin; adoption writes the origin's profile key and only updates
  // the editable profile when the origin is the selected model (audit
  // FE-02).
  assert.match(app, /const run = \{\n      modelId: selected\.id,/);
  assert.match(app, /provider: run\.provider,/);
  assert.match(app, /setTuneReportOrigin\(run\);/);
  const adopt = app
    .split("function adoptTunedProfile()")[1]
    .split("function loadProfile(")[0];
  // Adoption persists through the guarded writer and reports a storage
  // failure without relabelling the adoption (audit FE-02 + FE-09 I3).
  assert.match(adopt, /persistRecord\(`profile:\$\{origin\.modelId\}`, JSON\.stringify\(adopted\)\)/);
  assert.match(adopt, /persistenceFailureNote\("The tuned profile"\)/);
  assert.match(adopt, /if \(selectedId === origin\.modelId\)/);
  assert.doesNotMatch(adopt, /selected\.id/);
});

test("FE-07 cancellation state is separate from the run lifecycle", async () => {
  const panel = await readFile(join(process.cwd(), "src", "V03EvidencePanel.tsx"), "utf8");
  // Cancellation progress is its own state and never routed through the
  // generic busy wrapper; the run keeps ownership until it settles
  // (audit FE-07).
  assert.match(panel, /const \[cancelPending, setCancelPending\] = useState\(false\)/);
  assert.doesNotMatch(panel, /runAction\("cancel"/);
  // Cancellation crosses the evidence adapter (S-27.I2); the adapter
  // forwards to the cancel_benchmark command it replaces here.
  assert.match(panel, /await adapter\.cancelBenchmark\(\)/);
  const adapterSource = await readFile(
    join(process.cwd(), "src", "evidence-adapter.ts"),
    "utf8",
  );
  assert.match(adapterSource, /invoke\("cancel_benchmark"\)/);
  assert.match(panel, /busy !== "benchmark" \|\| cancelPending/);
});

test("GH-01 pull requests run only on the isolated hosted runner", async () => {
  const ci = await readFile(join(process.cwd(), ".github", "workflows", "ci.yml"), "utf8");
  // A moveable PR trigger exists so required checks can execute per PR.
  assert.match(ci, /pull_request:\n    branches: \[main\]/);
  const pr = ci.split("  pr-check:")[1];
  assert.match(pr, /if: github\.event_name == 'pull_request'/);
  assert.match(pr, /runs-on: windows-latest/);
  assert.doesNotMatch(pr, /self-hosted/);
  assert.doesNotMatch(pr, /secrets\./);
  // PR #18 follow-up (run 34786186394): the hosted pr-check hung 2h+ on the
  // bare `cargo test --locked` step (GPU-less windows-latest, no skip, no
  // timeout). The hosted job must fail fast with the skip set instead: a job
  // ceiling plus step ceilings plus LOCALMOTIVE_SKIP_HARDWARE_PROBE on the
  // Rust steps. Self-hosted push jobs keep real hardware probing (no skip).
  assert.match(pr, /timeout-minutes: (4[0-5]|50|60)/);
  for (const step of ["Rust linting", "Rust tests"]) {
    const body = pr.split(`- name: ${step}`)[1].split("- name:")[0];
    assert.match(body, /timeout-minutes: \d+/);
  }
  const rustTests = pr.split("- name: Rust tests")[1];
  assert.match(rustTests, /LOCALMOTIVE_SKIP_HARDWARE_PROBE/);
  assert.match(pr, /--nocapture/);
  // Trusted self-hosted jobs are unreachable from a pull request.
  const check = ci.split("\n  check:")[1].split("\n  rust-audit:")[0];
  const audit = ci.split("\n  rust-audit:")[1].split("\n  package-smoke:")[0];
  const smoke = ci.split("\n  package-smoke:")[1].split("\n  pr-check:")[0];
  for (const block of [check, audit, smoke]) {
    assert.match(block, /if: github\.event_name == 'push'/);
    assert.match(block, /self-hosted/);
  }
});

test("GH-03 the lifecycle consumes candidates instead of waiting for publication", async () => {
  const release = (await loadWorkflows(process.cwd()))["release.yml"];
  const hardware = await readFile(join(process.cwd(), ".github", "workflows", "hardware-qualify.yml"), "utf8");
  const steps = release.jobs.verify.steps;
  const lifecycle = steps.find((step) => step.run?.includes("host-run-lifecycle.ps1"));
  const assembly = steps.find((step) => step.run?.includes("build_qualification_manifest.mjs"));
  assert.match(lifecycle.run, /-CandidateDir "artifacts"/);
  assert.doesNotMatch(lifecycle.run, /ReleaseWaitMinutes/);
  assert.equal(lifecycle["timeout-minutes"], 120);
  assert.ok(release.jobs.verify["timeout-minutes"] > lifecycle["timeout-minutes"]);
  assert.ok(steps.indexOf(assembly) > steps.indexOf(lifecycle));
  assert.equal(assembly.if, undefined, "a failed lifecycle must stop qualification");
  const promote = await readFile(join(process.cwd(), ".github", "workflows", "release-promote.yml"), "utf8");
  assert.match(promote, /verify_release_promotion\.mjs/);
  assert.doesNotMatch(hardware, /clean-account-lifecycle/, "the lifecycle job belongs to release.yml");
});

test("GH-04 installer verdicts fail on leftovers and verify installed versions", async () => {
  const sandbox = await readFile(join(process.cwd(), "scripts", "sandbox", "run-lifecycle-in-sandbox.ps1"), "utf8");
  assert.doesNotMatch(sandbox, /WARNING: exe still present after MSI uninstall/);
  assert.match(sandbox, /Fail "Localmotive\.exe still present after MSI uninstall/);
  assert.match(sandbox, /Test-MsiProductInstalled/);
  assert.match(sandbox, /Assert-AppVersion \$exe \$meta\.version "MSI fresh install"/);
  assert.match(sandbox, /Assert-AppVersion \$exe \$meta\.version "Post-update install"/);
  const release = await readFile(join(process.cwd(), ".github", "workflows", "release.yml"), "utf8");
  // R07 (follow-up review db548c8): the single baseline variable became the
  // explicit qualification matrix - every supported baseline runs its update
  // path and its preservation step with the baseline's real persistence
  // flavor.
  for (const leg of ["v0.4.0", "v0.4.1", "v0.5.0"]) {
    assert.ok(release.includes(`Previous = "${leg}"`), `baseline ${leg} runs in the matrix`);
  }
  assert.match(release, /Flavor = "cache"/, "the v0.4.x legs use the cache-record flavor");
  assert.match(release, /Flavor = "mirror"/, "the v0.5.0 legs use the SQLite mirror flavor");
  assert.match(release, /PreservationFlavor \$leg\.Flavor/);
  assert.doesNotMatch(release, /-PreviousTag "v0\.4\.0"/, "the baseline flows through the explicit matrix entries");
});

test("GH-06 lifecycle evidence survives every terminal outcome", async () => {
  const host = await readFile(join(process.cwd(), "scripts", "sandbox", "host-run-lifecycle.ps1"), "utf8");
  assert.match(host, /function Write-FailureEvidence/);
  assert.match(host, /Write-FailureEvidence "TIMEOUT"/);
  assert.match(host, /Write-FailureEvidence "FAIL" \$_\.Exception\.Message/);
  // The FAIL branch must retain the sandbox's exact result JSON enriched
  // with host-side identity, not a bare copy: a failed run has to be
  // attributable (its source revision and candidate digests), not merely
  // retrievable. The plain copy was replaced after the wrong-candidate
  // control showed the retained FAIL document carried no host identity.
  assert.match(host, /\$failDoc \| Add-Member -NotePropertyName sourceRevision/);
  assert.match(host, /\$failDoc \| Add-Member -NotePropertyName candidateDigests/);
  // GH-06.V2: every terminal-outcome witness leg is driven through the
  // default-off fault simulations and asserted by the witness runner:
  // timeout, malformed result, early installer failure, and cancellation
  // (a killed run leaves no PASS artifact).
  for (const mode of ["timeout", "malformed-result", "missing-assets", "stall"]) {
    assert.ok(host.includes(`"${mode}"`), `host harness is missing the ${mode} fault mode`);
  }
  const witness = await readFile(
    join(process.cwd(), "scripts", "sandbox", "test-fault-evidence.ps1"),
    "utf8",
  );
  assert.match(witness, /Assert-Witness "witness-missing-assets" "FAIL" "resolve-installers"/);
  assert.match(witness, /Assert-Witness "witness-timeout" "TIMEOUT" "sandbox-timeout"/);
  assert.match(witness, /Assert-Witness "witness-malformed-result" "FAIL" "sandbox-run"/);
  assert.match(witness, /a killed run must not leave PASS evidence/);
  const steps = (await loadWorkflows(process.cwd()))["release.yml"].jobs.verify.steps;
  const diagnostics = steps.find((step) => step.with?.name?.endsWith("-verify-diagnostics"));
  const qualified = steps.find((step) => step.with?.name?.endsWith("-qualified"));
  assert.equal(diagnostics.if, "failure() || cancelled()");
  assert.equal(qualified.if, undefined);
  for (const upload of [diagnostics, qualified]) {
    assert.match(upload.with.path, /release-evidence.*attestations/);
    assert.equal(upload.with["retention-days"], 90);
  }
  assert.equal(qualified.with["if-no-files-found"], "error");
});

test("GH-10 host attestation statuses derive from detected hardware", async () => {
  const { deriveHostRows } = await import("../qualification/build_host_attestation.mjs");
  const match = deriveHostRows({ cpu: "AMD Ryzen 9 9950X3D 16-Core Processor", gpu: "NVIDIA GeForce RTX 5090" });
  assert.equal(match.verdict, "MATCH");
  assert.ok(match.rows.every((row) => row.status === "HOST_MATCH"));
  assert.equal(match.rows[0].observation, "AMD Ryzen 9 9950X3D 16-Core Processor");
  const cpuMismatch = deriveHostRows({ cpu: "Intel Core i9-13900K", gpu: "NVIDIA GeForce RTX 5090" });
  assert.equal(cpuMismatch.verdict, "NO_MATCH");
  assert.equal(cpuMismatch.rows[0].status, "HOST_NO_MATCH");
  const gpuMismatch = deriveHostRows({ cpu: "AMD Ryzen 9 9950X3D", gpu: "NVIDIA GeForce RTX 4080" });
  assert.equal(gpuMismatch.verdict, "NO_MATCH");
  assert.equal(gpuMismatch.rows[1].status, "HOST_NO_MATCH");
  const unknown = deriveHostRows({ cpu: "AMD Ryzen 9 9950X3D", gpu: "" });
  assert.equal(unknown.verdict, "UNKNOWN");
  assert.equal(unknown.rows[1].status, "HOST_UNKNOWN");
  const hardware = await readFile(join(process.cwd(), ".github", "workflows", "hardware-qualify.yml"), "utf8");
  assert.doesNotMatch(hardware, /status = "HOST_MATCH"/, "no static match rows may remain");
  assert.match(hardware, /build_host_attestation\.mjs/);
});

test("GH-02 release jobs share one resolved immutable revision", async () => {
  const release = await readFile(join(process.cwd(), ".github", "workflows", "release.yml"), "utf8");
  // One resolver pins the tag to a full SHA once; every later job checks
  // out exactly that revision (audit GH-02 I1).
  assert.match(release, /\n  resolve:\n/);
  const workflow = (await loadWorkflows(process.cwd()))["release.yml"];
  const resolveSteps = workflow.jobs.resolve.steps;
  const ancestry = resolveSteps.findIndex((step) => step.run?.includes("git merge-base --is-ancestor"));
  const repositoryCode = resolveSteps.findIndex((step) => step.run?.includes("node scripts/"));
  assert.ok(ancestry >= 0 && ancestry < repositoryCode, "main ancestry must pass before repository code executes");
  for (const name of ["rust-audit", "verify"]) {
    const checkouts = workflow.jobs[name].steps.filter((step) => step.uses?.startsWith("actions/checkout@"));
    assert.equal(checkouts.length, 1);
    assert.equal(checkouts[0].with.ref, "${{ needs.resolve.outputs.sha }}", `${name} must use the frozen source`);
  }
  assert.equal(
    (release.match(/github\.event\.inputs\.tag \|\| github\.ref \}\}/gu) ?? []).length,
    1,
    "only the resolver may check out the requested tag ref",
  );
  // Publication verifies the producer inventory instead of rewriting it, and
  // it re-proves at promotion time that the verify run built the same commit.
  const promote = await readFile(join(process.cwd(), ".github", "workflows", "release-promote.yml"), "utf8");
  const publish = promote.split("\n  publish:")[1];
  assert.match(publish, /verify_candidate_inventory\.mjs --verify/);
  assert.match(publish, /"qualified\/artifacts\/candidate-inventory-\$\{VERSION\}\.json"/);
  assert.doesNotMatch(publish, /verify_candidate_inventory\.mjs artifacts "\$VERSION"/);
  assert.match(promote, /assert\.equal\(run\.head_sha, process\.env\.EXPECTED_SHA/, "the verify run must have built the resolved commit");
  assert.match(promote, /sha="\$\(git rev-parse HEAD\)"/, "promotion resolves the tag itself");
  assert.doesNotMatch(promote, /verify_candidate_inventory\.mjs artifacts "\$VERSION"/);
  // The verifier CLI must resolve the artifact directory from the inventory's
  // own directory: argv[2] is the --verify flag itself in the workflow form,
  // and defaulting to it breaks the consumer boundary (ENOENT on the sums
  // file) in exactly the invocation publication uses.
  const inventoryCli = await readFile(join(process.cwd(), "scripts", "verify_candidate_inventory.mjs"), "utf8");
  assert.match(inventoryCli, /artifactDirectory: dirname\(inventoryPath\)/);
  assert.doesNotMatch(inventoryCli, /process\.argv\[4\] = process\.argv\[verifyIndex \+ 1\]/);
  assert.match(publish, /LOCALMOTIVE_SOURCE_REVISION="\$RESOLVED_SHA"/);
});

test("FE-04 previews compose provisionally and launch trust stays authoritative", async () => {
  const lib = await readFile(join(process.cwd(), "src-tauri", "src", "lib.rs"), "utf8");
  const app = await frontendSources();
  // The preview command is cheap composition only: no probing or trust work
  // on the profile-edit path (audit FE-04).
  const preview = lib.split("fn preview_command(")[1].split("#[tauri::command]")[0];
  // The preview names its shell and offers a lossless argv form (S-14) while
  // staying cheap composition only.
  assert.match(preview, /escaped_command_with_args/);
  assert.match(preview, /CommandShell::PowerShell/);
  assert.match(preview, /argv_json_with_args/);
  assert.doesNotMatch(preview, /prepare_launch/);
  // Validation and launch keep the authoritative checks.
  const validate = lib.split("fn validate_launch_profile(")[1].split("#[tauri::command]")[0];
  assert.match(validate, /prepare_launch/);
  // The server lifecycle commands moved to server_service.rs (S-27 slice 3a).
  const serverSource = await readFile(
    join(process.cwd(), "src-tauri", "src", "server_service.rs"),
    "utf8",
  );
  const start = serverSource
    .split("async fn start_server(")[1]
    .split("fn start_server_worker(")[0];
  assert.match(start, /start_server_worker/);
  const worker = serverSource
    .split("fn start_server_worker(")[1]
    .split("#[tauri::command]")[0];
  assert.match(worker, /spawn_server/);
  // The UI describes the provisional state honestly.
  assert.match(app, /Provisional command/);
  assert.match(app, /capability filtering, artifact checks, and managed-runtime trust are enforced/);
});

test("FE-16 status polling is single-flight with sequence guards", async () => {
  const app = await frontendSources();
  // Slow native polls cannot pile up, and a poll that started before a
  // start/stop transition can never overwrite the newer snapshot; the
  // running strategy renders from that snapshot, not the editable draft
  // (audit FE-16).
  assert.match(app, /if \(inFlight\) return; \/\/ single-flight/);
  assert.match(app, /requested !== statusPollSeq\.current/);
  assert.match(app, /const requested = \+\+statusPollSeq\.current;/);
  const bumps = (app.match(/statusPollSeq\.current \+= 1;/g) ?? []).length;
  assert.ok(bumps >= 2, `expected start and stop bumps, saw ${bumps}`);
  assert.match(app, /(?:props\.)?status\.running \? (?:props\.)?status\.specType : (?:props\.)?profile\?\.specType/);
  // FE-16.V3: the log well retains the last bounded output after a stop or an
  // unexpected exit, and no refactor placeholder may leak into user copy.
  const dashboard = await readFile(join(process.cwd(), "src", "screens", "DashboardScreen.tsx"), "utf8");
  assert.match(dashboard, /className="log-retained"/);
  assert.match(dashboard, /The last bounded output remains visible until the next start\./);
  assert.match(dashboard, /Start this profile to stream llama-server output here\./);
  assert.doesNotMatch(dashboard, /Start this props\./);
});

test("the cancellable local client never re-issues a slow-but-healthy response (MT-06)", async () => {
  const source = await readFile(join(process.cwd(), "src-tauri", "src", "local_client.rs"), "utf8");
  // Regression pinned after the 0.6.0 re-bind probes: the cancellable path
  // once bounded every attempt to CANCEL_ATTEMPT_SLICE and re-issued it,
  // which livelocked the v2 benchmark on the managed runtime (~560 ms per
  // completion). The request must run on a worker with the full deadline
  // while the caller observes the cancel flag in slices.
  assert.doesNotMatch(source, /remaining\.min\(CANCEL_ATTEMPT_SLICE\)/);
  assert.doesNotMatch(source, /is_timeout\(\) && cancelled\.is_some\(\)/);
  assert.match(source, /recv_timeout\(CANCEL_ATTEMPT_SLICE\)/);
  assert.match(source, /a_cancellable_response_that_outlives_the_cancel_slice_still_completes/);
  assert.match(source, /fn run_local_request\(/);
});

test("FE-16 and FE-05.V3 packaged walks drive the real routes", async () => {
  const fe16 = await readFile(join(process.cwd(), "scripts", "g05_fe16.mjs"), "utf8");
  assert.match(fe16, /fe16\.v1\.v2-survives-overlap/);
  assert.match(fe16, /fe16\.v1\.legacy-guarded-during-v2/);
  assert.match(fe16, /fe16\.v3\.running-identity-unchanged-by-edit/);
  assert.match(fe16, /fe16\.v3\.final-log-visible/);
  const fe05 = await readFile(join(process.cwd(), "scripts", "g05_fe05v3.mjs"), "utf8");
  assert.match(fe05, /Replay manifest/);
  assert.match(fe05, /fe05v3\.records-distinct-provenance/);
  assert.match(fe05, /fe05v3\.records-distinct-paths/);
});

test("FE-05 benchmark evidence and active runs survive navigation", async () => {
  const app = await frontendSources();
  const panel = await readFile(join(process.cwd(), "src", "V03EvidencePanel.tsx"), "utf8");
  // The evidence panel is always mounted (hidden by style), never gated on
  // the benchmark view, so navigation cannot erase its state (audit FE-05).
  assert.doesNotMatch(app, /view === "benchmark" && \(/);
  assert.match(
    app,
    /style=\{view === "benchmark" \? undefined : \{ display: "none" \}\}/,
  );
  // The always-mounted section renders BenchmarkScreen, which owns the
  // panel; the mount is what guarantees survival, not the literal call site.
  assert.match(app, /<BenchmarkScreen/);
  assert.match(app, /onRunStateChange=\{(?:props\.)?setEvidenceRun\}/);
  // The active run's status and cancel handle are available app-wide.
  assert.match(app, /evidenceRun\.cancel && \(/);
  // Completed benchmark manifests remain available across selection changes.
  assert.doesNotMatch(panel, /setBenchmark\(null\)/);
});

test("FE-03 stale responses are guarded before they can commit", async () => {
  const app = await frontendSources();
  // Audit FE-03: every deferred commit checks its request sequence and the
  // current resource identity, provider switches clear the previous
  // provider's presentation first, GGUF metadata clears with its selection,
  // and the port suggestion passes through the identity-checked helper.
  assert.match(app, /responseIsCurrent\(/);
  assert.match(app, /applySuggestedPort\(/);
  assert.match(app, /profileIdentity\(/);
  assert.match(app, /cloudSeq\.current \+= 1;\n    setCredential\(null\);/);
  assert.match(
    app,
    /async function loadGguf\(model: LogicalModel \| undefined\) \{\n    const sequence = \+\+ggufSeq\.current;\n    if \(!model\) \{/,
  );
  assert.match(app, /const sequence = \+\+previewSeq\.current;/);
});

test("user catalog overrides stay local, marked, and outside network verification", async () => {
  const mirror = await readFile(join(process.cwd(), "src-tauri", "src", "catalog_db.rs"), "utf8");
  const lib = await readFile(join(process.cwd(), "src-tauri", "src", "lib.rs"), "utf8");
  const app = await frontendSources();
  assert.match(mirror, /user_sourced/);
  assert.match(mirror, /validate_user_override/);
  assert.match(lib, /save_user_catalog_override/);
  assert.match(lib, /remove_user_catalog_override/);
  assert.match(lib, /catalog_local_models/);
  assert.match(app, /USER ADDED/);
});

test("IPC-02 production CSP and opener scope are narrow and audited", async () => {
  const configDir = join(process.cwd(), "src-tauri");
  const config = JSON.parse(await readFile(join(configDir, "tauri.conf.json"), "utf8"));
  const security = config.app?.security ?? {};
  assert.ok(
    typeof security.csp === "string" && security.csp.length > 0,
    "a production CSP must be configured",
  );
  assert.ok(!security.csp.includes("unsafe-eval"), "no unsafe-eval workaround in production");
  assert.match(security.csp, /script-src 'self'/);
  assert.match(security.csp, /connect-src [^;]*ipc:/);
  assert.match(security.csp, /connect-src [^;]*http:\/\/ipc\.localhost/);
  assert.ok(
    typeof security.devCsp === "string" && security.devCsp.includes("localhost:1420"),
    "the development-only exception must be explicit and separate",
  );
  assert.ok(!security.devCsp.includes("unsafe-eval"), "no unsafe-eval in the dev policy either");

  const capabilities = JSON.parse(
    await readFile(join(configDir, "capabilities", "default.json"), "utf8"),
  );
  assert.ok(
    !capabilities.permissions.includes("opener:default"),
    "the unscoped opener default permission set must not be granted",
  );
  const opener = capabilities.permissions.find(
    (permission) =>
      typeof permission === "object" && permission.identifier === "opener:allow-open-url",
  );
  assert.ok(opener, "opener must use the scoped allow-open-url permission");
  assert.ok(Array.isArray(opener.allow) && opener.allow.length > 0);
  for (const entry of opener.allow) {
    assert.ok(typeof entry.url === "string" && entry.url.length > 0, "every scope entry names a URL");
  }
  const patterns = opener.allow.map((entry) => entry.url);
  assert.ok(!patterns.includes("https://*") && !patterns.includes("*"));
  assert.ok(patterns.some((pattern) => pattern.startsWith("http://127.0.0.1/")));

  // Positive control: production sources contain no HTML/eval sinks.
  const sources = await readdir(join(process.cwd(), "src"));
  const sink = /(dangerouslySetInnerHTML|new Function\s*\(|document\.write|(^|[^a-zA-Z_.])eval\s*\()/;
  for (const name of sources) {
    if (!/\.(ts|tsx)$/.test(name)) continue;
    if (/\.test\.(ts|tsx)$/.test(name)) continue;
    const content = await readFile(join(process.cwd(), "src", name), "utf8");
    assert.ok(!sink.test(content), `unexpected injection sink in src/${name}`);
  }
});

test("FE-12 path-bar inputs keep a visible keyboard-focus ring", async () => {
  const css = await readFile(join(process.cwd(), "src", "App.css"), "utf8");
  assert.match(
    css,
    /\.path-bar input:focus-visible\s*\{[^}]*outline:/s,
    "the path-bar input outline reset must be paired with a focus-visible ring",
  );
  assert.ok(
    /\.path-bar input\s*\{[^}]*outline:\s*0/s.test(css.split(".path-bar input:focus-visible")[0]),
    "sanity: the outline reset still exists before the focus rule",
  );
});

test("FE-14 small-text colors keep at least 4.5:1 on their panels", async () => {
  const css = await readFile(join(process.cwd(), "src", "App.css"), "utf8");
  for (const old of ["#6f7974", "#77817d", "#7f8885", "#737b78"]) {
    assert.ok(!css.includes(old), `${old} was below 4.5:1 and must not return`);
  }
  const linear = (channel) => {
    const value = channel / 255;
    return value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
  };
  const luminance = (hex) => {
    const value = hex.replace("#", "");
    const [r, g, b] = [0, 2, 4].map((offset) => Number.parseInt(value.slice(offset, offset + 2), 16));
    return 0.2126 * linear(r) + 0.7152 * linear(g) + 0.0722 * linear(b);
  };
  const ratio = (fg, bg) => {
    const [a, b] = [luminance(fg), luminance(bg)].sort((x, y) => y - x);
    return (a + 0.05) / (b + 0.05);
  };
  const muted = "#9ca3a0";
  assert.match(css, /\.hardware-source \{[^}]*#9ca3a0/s, "the hardware-source line uses the muted token");
  for (const panel of ["#202622", "#222627", "#111514"]) {
    assert.ok(ratio(muted, panel) >= 4.5, `${muted} on ${panel} is ${ratio(muted, panel).toFixed(3)}:1`);
  }
});

test("DC-09 quant labels come from the file's own token and stay canonical", async () => {
  const { quantFromFilename, isCanonicalQuant } = await import("../lib/quant_label.mjs");
  const cases = [
    ["Model-IQ2_S-MTP.gguf", "IQ2_S"],
    ["Model-Q4_K_M-imatrix.gguf", "Q4_K_M"],
    ["Model-Q5_K_M-0731.gguf", "Q5_K_M"],
    ["Model-Q4_K_M-it.gguf", "Q4_K_M"],
    ["Model-q8_0.gguf", "Q8_0"],
    ["Model.q8_0.gguf", "Q8_0"],
    ["Model-UD-Q4_K_XL.gguf", "Q4_K_XL"],
    ["base-Q4_K_M-draft-Q8_0.gguf", "Q4_K_M"],
    ["gemma-4-E4B_q4_0-it.gguf", "Q4_0"],
    ["Date-Only-2025-0731.gguf", "UNKNOWN"],
    ["Qwen2.5-Coder-7B-Instruct.gguf", "UNKNOWN"],
  ];
  for (const [name, want] of cases) {
    assert.equal(quantFromFilename(name), want, name);
  }
  // The checked-in catalog keeps the labels its detached signature covers;
  // corrected labels arrive with the next signed publication, which rebuilds
  // through the fixed builder. The gate therefore pins the extractor and the
  // builder, not the signed data file.
  assert.ok(isCanonicalQuant("Q4_K_M") && !isCanonicalQuant("imatrix"));

  // The builder must use the same extractor; the suffix regex is gone.
  const builder = await readFile(join(process.cwd(), "scripts", "build_catalog.mjs"), "utf8");
  assert.ok(
    builder.includes("quantFromFilename(name)"),
    "the builder must label files through the shared extractor",
  );
  assert.ok(
    !builder.includes("match(/-([A-Za-z0-9_]+)\\.gguf$/i)"),
    "the suffix regex must not return",
  );
});

test("DC-10 the builder pins immutable revisions and signed freshness fields", async () => {
  const builder = await readFile(join(process.cwd(), "scripts", "build_catalog.mjs"), "utf8");
  assert.match(builder, /meta\.sha/, "the builder reads the repository commit");
  assert.match(builder, /revision: commitSha/, "files carry the immutable revision");
  assert.match(builder, /\.\.\.\(commitSha \? \{ revision: commitSha \} : \{\}\)/, "the revision is omitted rather than empty when the API reports none");
  assert.match(builder, /sequence: nowMs/, "the catalog carries a signed sequence");
  assert.match(
    builder,
    /expires: Math\.floor\(nowMs \/ 1000\) \+ 14 \* 24 \* 60 \* 60/,
    "the catalog carries a signed expiry deadline",
  );
});

test("QD-01 the catalog cutoff follows the build clock", async () => {
  const { catalogCutoff } = await import("../lib/catalog_window.mjs");
  // The audit's reproduction: identical inputs a year apart must not share
  // a threshold; the old literal kept June 12, 2026 for every build.
  const first = catalogCutoff(new Date("2026-09-10T12:00:00Z"), 90);
  const later = catalogCutoff(new Date("2027-09-10T12:00:00Z"), 90);
  assert.notEqual(first.toISOString(), later.toISOString());
  assert.equal(first.toISOString().slice(0, 10), "2026-06-12");
  assert.equal(later.toISOString().slice(0, 10), "2027-06-12");
  // The threshold is UTC midnight of (now - cutoffDays).
  assert.equal(catalogCutoff(new Date("2026-09-10T23:59:59Z"), 30).toISOString(), "2026-08-11T00:00:00.000Z");

  const builder = await readFile(join(process.cwd(), "scripts", "build_catalog.mjs"), "utf8");
  assert.ok(
    builder.includes("catalogCutoff(new Date(), CUTOFF_DAYS)"),
    "the builder must derive the cutoff from the build clock",
  );
  assert.ok(
    !builder.includes('new Date("2026-09-10T00:00:00Z")'),
    "the frozen literal cutoff must not return",
  );
});

test("QD-04 active docs agree with the shipped unsigned policy and current platform", async () => {
  const runtimeManager = await readFile(join(process.cwd(), "docs", "RUNTIME_MANAGER.md"), "utf8");
  assert.ok(
    runtimeManager.includes("ship **unsigned with an explicit"),
    "the runtime manager notes the deferred-signing release policy",
  );
  const product = await readFile(join(process.cwd(), "docs", "PRODUCT.md"), "utf8");
  assert.ok(
    !/^web$/m.test(product.split("## Stack")[0]),
    "the product schema no longer claims the web platform",
  );
  assert.ok(product.includes("SQLite-backed local catalog mirror"), "the SQLite mirror is described");
  const qualification = await readFile(join(process.cwd(), "docs", "qualification-tests.md"), "utf8");
  assert.ok(qualification.includes("Frozen snapshot"), "the qualification snapshot is labelled");
  assert.ok(!qualification.includes("verify_versions.mjs 0.4.1"), "the stale command is corrected");
});

test("QD-05 the toolchain minimum is declared", async () => {
  const packageJson = JSON.parse(await readFile(join(process.cwd(), "package.json"), "utf8"));
  assert.equal(packageJson.engines?.node, "^20.19.0 || >=22.12.0");
  assert.match(packageJson.packageManager ?? "", /^npm@/);
  const toolchain = await readFile(join(process.cwd(), "rust-toolchain.toml"), "utf8");
  assert.match(toolchain, /channel = "\d+\.\d+\.\d+"/, "the toolchain is pinned");
  const cargo = await readFile(join(process.cwd(), "src-tauri", "Cargo.toml"), "utf8");
  assert.match(cargo, /rust-version = "\d+\.\d+"/, "rust-version mirrors the pin");
  const readme = await readFile(join(process.cwd(), "README.md"), "utf8");
  assert.ok(readme.includes("20.19"), "the README states the real Node minimum");
});

test("QD-06 vendored upstream docs carry provenance and links resolve elsewhere", async () => {
  const vendored = await readFile(join(process.cwd(), "docs", "LLAMA-SERVER-README.md"), "utf8");
  assert.ok(vendored.includes("Provenance"), "the vendored README identifies its source");
  assert.ok(vendored.includes("ggml-org/llama.cpp"), "the upstream repository is named");
  const optionMap = await readFile(join(process.cwd(), "docs", "OPTION_MAP.md"), "utf8");
  assert.ok(optionMap.includes("--help` is authoritative"), "OPTION_MAP records its source policy");
});

test("QD-06 local doc links resolve (the vendored upstream README is excluded)", async () => {
  // The vendored docs/LLAMA-SERVER-README.md intentionally keeps upstream
  // relative targets (see its provenance banner); every other active doc
  // must resolve its relative links inside this repository.
  const files = ["README.md", "docs/OPTION_MAP.md", "docs/PRODUCT.md", "docs/RUNTIME_MANAGER.md"];
  const missing = [];
  for (const file of files) {
    const content = await readFile(join(process.cwd(), file), "utf8");
    for (const match of content.matchAll(/\]\((?!https?:|#|mailto:)([^)]+)\)/g)) {
      const link = match[1].split("#")[0].trim();
      if (!link) continue;
      const target = resolve(dirname(join(process.cwd(), file)), link);
      try {
        await stat(target);
      } catch {
        missing.push(`${file} -> ${link}`);
      }
    }
  }
  assert.deepEqual(missing, [], `unresolved relative links: ${missing.join(", ")}`);
});

test("GH-07 the evidence matrix exists and the README reads it", async () => {
  const matrix = await readFile(join(process.cwd(), "docs", "EVIDENCE-MATRIX.md"), "utf8");
  for (const cell of ["CPU packaged lifecycle", "Accelerator (CUDA) packaged", "Clean-account Sandbox"]) {
    assert.ok(matrix.includes(cell), `the matrix must define ${cell}`);
  }
  assert.ok(matrix.includes("assets"), "evidence assets must be named");
  const readme = await readFile(join(process.cwd(), "README.md"), "utf8");
  assert.ok(readme.includes("docs/EVIDENCE-MATRIX.md"), "the README points at the matrix");
  // The README must state what 0.6.0 actually established and explicitly
  // refuse to generalize it; the accelerator caveat wording moved when the
  // support matrix was introduced, so accept either explicit phrasing.
  assert.ok(
    /not\s+covered by that lifecycle evidence unless/.test(readme) ||
      /Do not generalize/.test(readme),
    "accelerator coverage is not inferred",
  );
  assert.ok(
    !readme.includes("during 01:00-06:00 Asia/Dubai."),
    "the stale night-window-only claim must not return",
  );
  const workflow = await readFile(
    join(process.cwd(), ".github", "workflows", "hardware-qualify.yml"),
    "utf8",
  );
  assert.ok(
    !workflow.includes("Runner online window: **01:00-06:00"),
    "the workflow summary must not claim a night-only window",
  );
});

test("GH-08 supply-chain posture and SBOM step are documented", async () => {
  const supply = await readFile(join(process.cwd(), "docs", "SUPPLY-CHAIN.md"), "utf8");
  assert.ok(supply.includes("not cryptographic"), "attestation limits are stated");
  assert.ok(supply.includes("does not authenticate application installers"), "catalog scope is stated");
  assert.ok(supply.includes("Unsigned installers"), "the unsigned posture is stated");
  const release = await readFile(
    join(process.cwd(), ".github", "workflows", "release.yml"),
    "utf8",
  );
  assert.ok(release.includes("npm sbom --sbom-format cyclonedx"), "the SBOM step exists");
  const bundle = (await loadWorkflows(process.cwd()))["release.yml"].jobs.verify.steps
    .find((step) => step.with?.name?.endsWith("-qualified"));
  assert.match(bundle.with.path, /^sbom\.cdx\.json$/m, "the qualified bundle retains the SBOM");
  assert.equal(bundle.with["retention-days"], 90);
});

test("GH-09 governance files exist and dependency updates are configured", async () => {
  const security = await readFile(join(process.cwd(), "SECURITY.md"), "utf8");
  assert.ok(security.includes("private vulnerability reporting"), "a reporting path is documented");
  assert.ok(security.includes("no bug bounty"), "expectations are stated");
  const contributing = await readFile(join(process.cwd(), "CONTRIBUTING.md"), "utf8");
  assert.ok(contributing.includes("cargo clippy --all-targets -- -D warnings"), "the check suite is listed");
  assert.ok(contributing.includes("Maintenance and recovery"), "backup/recovery guidance exists");
  await stat(join(process.cwd(), ".github", "ISSUE_TEMPLATE", "bug_report.yml"));
  await stat(join(process.cwd(), ".github", "ISSUE_TEMPLATE", "feature_request.yml"));
  const dependabot = await readFile(join(process.cwd(), ".github", "dependabot.yml"), "utf8");
  for (const ecosystem of ["npm", "cargo", "github-actions"]) {
    assert.ok(dependabot.includes(`package-ecosystem: ${ecosystem}`), `dependabot covers ${ecosystem}`);
  }
});

test("adapter invokes wrap Rust commands whose only parameter is `request`", async () => {
  // Regression: `preflight_model(request)` was called with the request fields
  // passed flat, so the packaged panel answered "command preflight_model
  // missing required key `request`" and the v2 evidence flow silently produced
  // no result. Any adapter pass-through (`invoke("x", args)`) to a Rust command
  // whose only non-AppHandle parameter is `request` must wrap it.
  const adapter = await readFile(join(process.cwd(), "src", "evidence-adapter.ts"), "utf8");
  const rustSources = [];
  for (const module of ["lib.rs", "measurement_service.rs", "runtime_service.rs", "server_service.rs", "tune_service.rs"]) {
    try {
      rustSources.push(await readFile(join(process.cwd(), "src-tauri", "src", module), "utf8"));
    } catch {
      // module not present in this layout
    }
  }
  const entries = [...adapter.matchAll(/invoke\("([a-z0-9_]+)",\s*args\)/g)].map((match) => match[1]);
  const offenders = [];
  for (const name of entries) {
    for (const source of rustSources) {
      const signature = source.match(new RegExp(`fn ${name}\\(([^)]*)`));
      if (!signature) continue;
      const params = signature[1]
        .split(",")
        .map((part) => part.trim().split(":")[0].trim())
        .filter((part) => part && part !== "app");
      if (params.length === 1 && params[0] === "request") offenders.push(name);
      break;
    }
  }
  assert.deepEqual(
    offenders,
    [],
    `commands whose only parameter is \`request\` must be invoked as { request: args }: ${offenders.join(", ")}`,
  );
});

test("release verification keeps checks, packaging, lifecycle, and qualification in one workspace", async () => {
  const release = (await loadWorkflows(process.cwd()))["release.yml"];
  assert.deepEqual(Object.keys(release.jobs).sort(), ["resolve", "rust-audit", "verify"]);
  const job = release.jobs.verify;
  assert.deepEqual(job.needs, ["resolve", "rust-audit"]);
  const steps = job.steps;
  assert.equal(steps.filter((step) => step.uses?.startsWith("actions/checkout@")).length, 1);
  assert.ok(!steps.some((step) => step.uses?.startsWith("actions/download-artifact@")),
    "the candidate must not leave this workspace before qualification");
  const stages = ["npm run check", "cargo test --locked", "npm run tauri build",
    "scripts/verify_packaged_matrix.ps1", "scripts/verify_candidate_inventory.mjs",
    "host-run-lifecycle.ps1", "scripts/build_qualification_manifest.mjs", "scripts/verify_release_promotion.mjs"];
  let previous = -1;
  for (const command of stages) {
    const matching = steps.filter((step) => step.run?.includes(command));
    assert.equal(matching.length, 1, `${command} must run once`);
    const step = matching[0];
    const index = steps.indexOf(step);
    assert.ok(index > previous, `${command} must follow the preceding gate`);
    assert.equal(step.if, undefined, `${command} cannot skip a failed predecessor`);
    assert.equal(step["continue-on-error"], undefined, `${command} cannot ignore failure`);
    previous = index;
  }
  const bundle = steps.find((step) => step.with?.name?.endsWith("-qualified"));
  assert.ok(bundle && steps.indexOf(bundle) > previous, "retain the qualified bundle only after every gate passes");
  assert.equal(bundle.if, undefined);
  assert.equal(bundle.with["if-no-files-found"], "error");
});

test("S-26: version gates stay dynamic and deterministic tests run once before packaging", async () => {
  const ci = await readFile(join(process.cwd(), ".github", "workflows", "ci.yml"), "utf8");
  const release = await readFile(
    join(process.cwd(), ".github", "workflows", "release.yml"),
    "utf8",
  );
  // No workflow may pin a literal version number: the non-release jobs use
  // the no-argument manifest-consistency mode, and the release job binds the
  // RESOLVED tag version.
  for (const [name, body] of [["ci.yml", ci], ["release.yml", release]]) {
    assert.doesNotMatch(
      body,
      /verify_versions\.mjs\s+["']?\d+\.\d+\.\d+/,
      `${name} must not pass a literal version to verify_versions.mjs`,
    );
    assert.doesNotMatch(
      body,
      /only v\d/,
      `${name} must not pin a single tag literal`,
    );
  }
  assert.match(
    ci,
    /node scripts\/verify_versions\.mjs\n/,
    "ci.yml uses the no-argument manifest-consistency mode",
  );
  assert.match(
    release,
    /node scripts\/verify_versions\.mjs \$\{\{ needs\.resolve\.outputs\.version \}\}/,
    "release.yml binds the resolved tag version to the manifests",
  );
  // The tag shape is validated by pattern, and the resolved revision must
  // identify as the same version before anything is published.
  assert.match(release, /case "\$raw" in\n\s*v\[0-9\]\*\.\[0-9\]\*\.\[0-9\]\*\)/, "release.yml validates the tag pattern");
  assert.match(
    release,
    /node scripts\/verify_versions\.mjs "\$\{raw#v\}" \\/,
    "the resolve job refuses source whose manifests identify as another version",
  );
  // Run script tests before the frontend suite, without repeating them in CI.
  const pkg = JSON.parse(await readFile(join(process.cwd(), "package.json"), "utf8"));
  assert.match(pkg.scripts.test, /^node --test .*scripts\/tests\/release-gates\.test\.mjs.* && vitest run$/);
  assert.match(pkg.scripts.check, /^npm test &&/);
  const workflows = await loadWorkflows(process.cwd());
  for (const [file, jobs] of [["ci.yml", ["check", "pr-check"]], ["release.yml", ["verify"]]]) {
    for (const job of jobs) {
      const commands = workflows[file].jobs[job].steps.flatMap((step) => String(step.run ?? "").split(/\r?\n/));
      assert.equal(commands.filter((command) => command.trim() === "npm run check").length, 1, `${file}:${job} runs the full check`);
      assert.ok(!commands.some((command) => command.includes("node --test")), `${file}:${job} must not repeat script tests`);
      const rustTests = workflows[file].jobs[job].steps.filter((step) => /^cargo test\b/.test(step.run ?? ""));
      assert.equal(rustTests.length, 1, `${file}:${job} runs unit, integration, and documentation tests together`);
      assert.equal(rustTests[0].env.RUSTDOCFLAGS, "-D warnings");
    }
  }
  // Audit S-26 I2 replaced the resolve-job literal; the publish ship guard
  // must bind the RESOLVED tag the same way - a `== 'v0.5.0'`-style equality
  // silently skips publication for every later version.
  // Baseline tag names in the qualification matrix are data, not
  // comparisons, so the check targets comparison positions (the original
  // defect was a `== 'v0.5.0'`-style equality in a guard).
  assert.doesNotMatch(
    release,
    /(==|!=|-eq|-ne|equals\()\s*['"]v\d+\.\d+\.\d+['"]/,
    "release.yml must not compare against a literal version",
  );
});

test("promotion validates each downloaded bundle once without repeating manifest and checksum checks", async () => {
  const workflow = (await loadWorkflows(process.cwd()))["release-promote.yml"];
  for (const name of ["gate", "publish"]) {
    const steps = workflow.jobs[name].steps;
    const download = steps.findIndex((step) => step.uses?.startsWith("actions/download-artifact@"));
    const validators = steps.filter((step) => step.run?.includes("node scripts/verify_release_promotion.mjs"));
    assert.equal(validators.length, 1, `${name} validates this download once`);
    assert.ok(download >= 0 && steps.indexOf(validators[0]) > download);
    assert.equal(steps[download].with.path, "qualified");
    assert.match(validators[0].run, /--qualified qualified /, "validate the download without overlaying checkout evidence");
    assert.ok(!steps.some((step) => step.run?.includes("cp -r qualified/")));
    assert.match(validators[0].run, /--expect-source "\$RESOLVED_SHA" --verify-run "\$VERIFY_RUN_ID"/);
    assert.equal(validators[0].if, undefined);
    assert.equal(validators[0]["continue-on-error"], undefined);
    assert.ok(!steps.some((step) => step.run?.includes("node scripts/verify_qualification_manifest.mjs")),
      `${name} already checks the manifest through the promotion validator`);
    assert.ok(!validators[0].run.includes("sha256sum -c"), `${name} already checks all binary digests`);
  }
  const checkout = workflow.jobs.publish.steps.find((step) => step.uses?.startsWith("actions/checkout@"));
  assert.equal(checkout.with.ref, "${{ needs.gate.outputs.sha }}", "publish uses the validated revision, not a moving tag");
});

test("publication consumes the retained candidate inventory and validates it (2026-09-12 review)", async () => {
  const promote = await readFile(join(process.cwd(), ".github", "workflows", "release-promote.yml"), "utf8");
  const gate = promote.split("\n  gate:")[1].split("\n  publish:")[0];
  // Promotion consumes the qualified bundle the verify run uploaded - the
  // bundle carries the producer inventory, so the inventory is validated
  // rather than rewritten and the candidate is never re-cut.
  assert.match(gate, /localmotive-\$\{\{ steps\.resolve\.outputs\.version \}\}-qualified/);
  assert.match(gate, /run-id: \$\{\{ inputs\.verify_run_id \}\}/, "the bundle comes from the named verify run");
  assert.match(
    gate,
    /verify_release_promotion\.mjs --qualified qualified --tag "v\$\{VERSION\}" --expect-source "\$RESOLVED_SHA"/,
    "the promotion validator binds inventory, artifacts, checksums and records",
  );
  assert.doesNotMatch(promote, /tauri build|npm run build/, "publication never rebuilds; a rebuild would be a new candidate");
});

test("the RT-04.V2 health-model delay seam is loopback-only and verifier-gated", async () => {
  const source = await readFile(join(process.cwd(), "src-tauri", "src", "download.rs"), "utf8");
  assert.match(source, /rebase_download_url_with/);
  assert.match(source, /rebase_download_url_rewrites_the_health_model_path_onto_the_loopback_fixture/);
  assert.match(source, /rebase_download_url_preserves_the_canonical_url_without_the_profile/);
  const runtime = await readFile(join(process.cwd(), "src-tauri", "src", "runtime.rs"), "utf8");
  assert.match(
    runtime,
    /rebase_download_url\(&pin\.url\)/,
    "the pinned health-model fetch is the rebased call",
  );
});

test("lifecycle evidence binds to the candidate inventory, never a substituted HEAD", async () => {
  const harness = await readFile(join(process.cwd(), "scripts", "sandbox", "host-run-lifecycle.ps1"), "utf8");
  assert.match(harness, /candidate-inventory-\$Version\.json/);
  assert.match(harness, /Never substitute HEAD for the candidate source/);
  assert.match(harness, /harnessRevision/);
  assert.match(harness, /git -C \$PSScriptRoot rev-parse HEAD/);
});

test("MT-06 extension pins worker ownership and duplicate-free cancellation", async () => {
  const source = await readFile(join(process.cwd(), "src-tauri", "src", "local_client.rs"), "utf8");
  for (const name of [
    "a_cancelled_body_read_resolves_worker_ownership_without_duplicate_requests",
    "a_cancelled_call_lets_a_short_body_finish_on_the_owned_connection_once",
    "repeated_cancel_restart_cycles_keep_workers_bounded_and_requests_exact",
  ]) {
    assert.match(source, new RegExp(name));
  }
  assert.match(source, /serve_slow_body/);
  assert.match(source, /active_cancellable_workers/);
});

test("R05/R06: lifecycle pass conditions are strict and candidate-bound", async () => {
  const harness = await readFile(join(process.cwd(), "scripts", "sandbox", "host-run-lifecycle.ps1"), "utf8");
  const witness = await readFile(join(process.cwd(), "scripts", "sandbox", "test-fault-evidence.ps1"), "utf8");
  // R06: an explicitly supplied candidate set is verified against the run's
  // inventory and never silently replaced by a published release.
  assert.match(harness, /refusing to fall back to a published release/);
  assert.match(harness, /does not match the inventory's/);
  assert.match(harness, /candidateInventorySha256/);
  // R05: anything short of a verified preservation PASS fails the run.
  assert.match(harness, /throw "Host preservation verification is not PASS \(\$preservationStatus\)/);
  assert.match(harness, /\$doc\.status = "FAIL"/);
  // The witness leg proves both: the evidence flips to FAIL at
  // preservation-verification AND the run exits nonzero.
  assert.match(witness, /witness-preservation-missing/);
  assert.match(witness, /-FaultSimulation "preservation-missing"/);
  assert.match(witness, /must exit nonzero when preservation is not PASS/);
  // The witnesses themselves must exist and carry the inventory binding.
  // The harness writes UTF-8 with a BOM under Windows PowerShell 5.1.
  const readWitnessDoc = async (name) =>
    JSON.parse(
      (await readFile(join(process.cwd(), "release-evidence", "0.6.0", "attestations", `${name}.json`), "utf8"))
        .replace(/^﻿/, ""),
    );
  for (const name of [
    "witness-missing-assets",
    "witness-timeout",
    "witness-malformed-result",
    "witness-preservation-missing",
  ]) {
    const doc = await readWitnessDoc(name);
    assert.ok("candidateInventorySha256" in doc, `${name} binds the candidate inventory`);
  }
  const preservation = await readWitnessDoc("witness-preservation-missing");
  assert.equal(preservation.status, "FAIL");
  assert.equal(preservation.stage, "preservation-verification");
  assert.equal(preservation.preservation.status, "missing-files");
});

// U06-04: the settings canary must reach the sandbox shared dir. The in-box
// run reads canary-settings.json from the mapped share; the host staged the
// other canaries there but omitted this one, so cache-flavor legs died at
// "settings fixture missing" inside the sandbox instead of exercising
// preservation. The host pins the staged settings fixture alongside the
// other staged canaries.
test("lifecycle host stages the settings canary for cache legs", async () => {
  const host = await readFile(
    join(process.cwd(), "scripts", "sandbox", "host-run-lifecycle.ps1"),
    "utf8",
  );
  assert.match(
    host,
    /Copy-Item.*canary-settings\.json.*\$Shared.*canary-settings\.json/,
    "the host stages canary-settings.json into the sandbox shared dir",
  );
});

// U06-02: the witness stall/cancel legs must spawn a shell that can run the
// harness. Windows PowerShell 5.1 cannot resolve Get-FileHash in the
// constrained spawn context (observed: the child exits 1 before the kill and
// the leg fails with "exited before it could be cancelled"), while pwsh runs
// the same stall leg to a killable wait. The harness pins the child shell
// once so both spawn sites stay on the capable shell.
test("witness stall legs spawn the capable shell", async () => {
  const witness = await readFile(
    join(process.cwd(), "scripts", "sandbox", "test-fault-evidence.ps1"),
    "utf8",
  );
  assert.match(witness, /\$shellExe = \(Get-Command pwsh/);
  assert.doesNotMatch(witness, /Start-Process -FilePath "powershell"/);
});

// U06-04: the settings session must wait for the debugger target. A fixed
// 8 s sleep races WebView2 initialization on the slower sandbox launch path:
// the earlier upg040 leg died at "no CDP page target" 60 s into the evaluate
// even though the binary was alive, because the sleep ended before the port
// opened and the single evaluate call then spent its whole budget polling a
// port nothing had opened yet. The session polls /json/list (up to 90 s)
// before the evaluate runs, the same way the CDP drivers attach.
// U06-04: the settings session pins an explicit WebView2 user-data dir.
// Proven on the host against the real v0.4.0 build: with only
// --remote-debugging-port the process stays alive but exposes no CDP target
// within 55 s; adding --user-data-dir plus WEBVIEW2_USER_DATA_FOLDER exposes
// a page target. Without the dir the session can never attach.
// U06-04: the settings session must split the data root from the profile
// dir. The folder variable doubles as the WebView2 data root (the runtime
// owns EBWebView subdirs directly under it) AND as the Chromium
// --user-data-dir (which must hold Default/ etc. itself). Pointing both at
// one dir produced flaky debugger targets in the sandbox; the split layout
// (data root + webview-profile child) attaches reliably on the host against
// the real v0.4.0 build with a localStorage seed/read round-trip.
test("settings session splits the WebView2 data root from the profile dir", async () => {
  const sandbox = await readFile(
    join(process.cwd(), "scripts", "sandbox", "run-lifecycle-in-sandbox.ps1"),
    "utf8",
  );
  const marker = "function Use-SettingsSession";
  const tail = sandbox.slice(sandbox.indexOf(marker));
  const end = tail.indexOf("function Seed-SettingsV041");
  const session = tail.slice(0, end);
  assert.match(session, /\$script:SettingsDataRoot/);
  assert.match(session, /webview-profile/);
});


// U06-04: the settings session must keep the WebView2 profile OUTSIDE the
// mapped share. The share is a redirected network-backed folder and Chromium
// refuses to open a profile on it: observed live, the v0.4.0 baseline stayed
// alive but exposed no CDP page target in 90 s while the same bytes attach on
// the host with a localStorage seed/read round-trip. The session already
// collects the evaluated JSON, so nothing else needs to cross the share.
test("settings session keeps the WebView2 profile outside the mapped share", async () => {
  const sandbox = await readFile(
    join(process.cwd(), "scripts", "sandbox", "run-lifecycle-in-sandbox.ps1"),
    "utf8",
  );
  const marker = "function Use-SettingsSession";
  const tail = sandbox.slice(sandbox.indexOf(marker));
  const end = tail.indexOf("function Seed-SettingsV041");
  const session = tail.slice(0, end);
  assert.match(session, /\$script:SettingsDataRoot/);
  assert.match(sandbox, /\$script:SettingsDataRoot = Join-Path \$env:TEMP \('lm-settings-session-'/);
  assert.doesNotMatch(session, /Remove-Item -LiteralPath \$dataRoot/);
  assert.doesNotMatch(sandbox, /Remove-Item -LiteralPath \$script:SettingsDataRoot/, "owned Sandbox teardown must clean guest storage without following a guest TEMP junction");
  assert.doesNotMatch(session, /settings-session-data/);
});

test("settings session pins a WebView2 user-data dir", async () => {
  const sandbox = await readFile(
    join(process.cwd(), "scripts", "sandbox", "run-lifecycle-in-sandbox.ps1"),
    "utf8",
  );
  const marker = "function Use-SettingsSession";
  const tail = sandbox.slice(sandbox.indexOf(marker));
  const end = tail.indexOf("function Seed-SettingsV041");
  const session = tail.slice(0, end);
  assert.match(session, /user-data-dir/);
  assert.match(session, /WEBVIEW2_USER_DATA_FOLDER/);
});


test("settings session polls for the debugger target before evaluating", async () => {
  const sandbox = await readFile(
    join(process.cwd(), "scripts", "sandbox", "run-lifecycle-in-sandbox.ps1"),
    "utf8",
  );
  const marker = "function Use-SettingsSession";
  const tail = sandbox.slice(sandbox.indexOf(marker));
  const end = tail.indexOf("function Seed-SettingsV041");
  const session = tail.slice(0, end);
  assert.ok(session.length > 200, "the settings session body is present");
  assert.match(session, /AddSeconds[(]90[)]/);
  assert.match(session, /json\/list/);
  assert.doesNotMatch(session, /Start-Sleep -Seconds 8/);
});

test("settings sessions preserve storage and clean up on a verifier failure", { skip: process.platform !== "win32" }, async () => {
  const { execFileSync } = await import("node:child_process");
  const output = execFileSync("pwsh", ["-NoProfile", "-File", "scripts/tests/verify_settings_session.ps1"], { encoding: "utf8", timeout: 60000 });
  assert.match(output, /PASS: baseline storage survives the upgraded session/);
  assert.match(output, /PASS: success and failure stop owned children/);
  assert.match(output, /PASS: launch smoke joins its owned process/);
  assert.match(output, /PASS: verifier and cleanup failures remain visible/);
});

test("lifecycle collection handles cache-only and mirror-only baselines", { skip: process.platform !== "win32" }, async () => {
  const { execFileSync } = await import("node:child_process");
  const output = execFileSync("pwsh", ["-NoProfile", "-File", "scripts/tests/verify_preservation_collection.ps1"], { encoding: "utf8", timeout: 30000 });
  assert.match(output, /PASS: cache-only baseline collects its actual files/);
  assert.match(output, /PASS: mirror-only baseline collects its actual files/);
  assert.match(output, /PASS: missing required preservation data is rejected/);
});

test("lifecycle cleanup targets only its Sandbox identity and reports stop failures", { skip: process.platform !== "win32" }, async () => {
  const { execFileSync } = await import("node:child_process");
  const output = execFileSync("pwsh", ["-NoProfile", "-File", "scripts/tests/verify_lifecycle_ownership.ps1"], { encoding: "utf8", timeout: 30000 });
  assert.match(output, /PASS: cleanup targets only the owned Sandbox ID/);
  assert.match(output, /PASS: cleanup failure is reported/);
  const source = await readFile("scripts/sandbox/host-run-lifecycle.ps1", "utf8");
  assert.doesNotMatch(source, /Get-Process -Name "WindowsSandbox"/);
});

test("lifecycle retains the actual settings reads under lock ownership", { skip: process.platform !== "win32" }, async () => {
  const { execFileSync } = await import("node:child_process");
  const output = execFileSync("pwsh", ["-NoProfile", "-File", "scripts/tests/verify_settings_retention.ps1"], { encoding: "utf8", timeout: 30000 });
  assert.match(output, /PASS: settings reads are retained byte-for-byte/);
  assert.match(output, /PASS: lost ownership refuses settings evidence writes/);
  const release = (await loadWorkflows(process.cwd()))["release.yml"];
  for (const name of ["Retain the qualified candidate bundle", "Retain diagnostics after failure or cancellation"]) {
    const upload = release.jobs.verify.steps.find((step) => step.name === name);
    assert.match(upload.with.path, /attestations\/\*/);
  }
});

test("lifecycle preflight checks the actual Sandbox CLI before using candidates", { skip: process.platform !== "win32" }, async () => {
  const { spawnSync } = await import("node:child_process");
  const release = (await loadWorkflows(process.cwd()))["release.yml"];
  const step = release.jobs.verify.steps.find((entry) => entry.name === "Ensure Windows Sandbox is available");
  for (const [available, code, expected] of [[false, 0, 1], [true, 1, 1], [true, 0, 0]]) {
    const result = spawnSync("pwsh", ["-NoProfile", "-Command", `
      $ErrorActionPreference = 'Stop'
      function Test-Path { return $true }
      function Get-Command {
        [CmdletBinding()]param([string]$Name)
        if (-not $${available}) { throw 'fixture: wsb.exe unavailable' }
        return [pscustomobject]@{ Source = 'Test-WsbCli' }
      }
      function Test-WsbCli { $global:LASTEXITCODE = ${code}; return '1.0.0-fixture' }
      ${step.run}
    `], { encoding: "utf8", timeout: 30000 });
    assert.equal(result.status, expected, `CLI available=${available} exit=${code}: ${result.stdout}${result.stderr}`);
  }
});

test("elevated guest debugging uses a new application-scoped machine override", { skip: process.platform !== "win32" }, async () => {
  const { execFileSync } = await import("node:child_process");
  const output = execFileSync("pwsh", ["-NoProfile", "-Command", `
    $ErrorActionPreference = 'Stop'
    $ast = [Management.Automation.Language.Parser]::ParseFile((Join-Path $PWD 'scripts/sandbox/run-lifecycle-in-sandbox.ps1'), [ref]$null, [ref]$null)
    $definition = $ast.Find({ param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Initialize-LifecycleBrowserDebugging' }, $true)
    if ($definition) { . ([scriptblock]::Create($definition.Extent.Text)) }
    else { function Initialize-LifecycleBrowserDebugging { param($Elevated) } }
    $script:written = @(); $script:existing = $false; $script:keyPresent = $true; $script:keyCreated = $false
    function Log { param($message) }
    function Test-Path { [CmdletBinding()]param($LiteralPath) return $script:keyPresent }
    function Get-ItemProperty { [CmdletBinding()]param($LiteralPath, $Name) if ($script:existing) { return @{ existing = $true } } }
    function New-Item {
      [CmdletBinding()]param($Path, [switch]$Force)
      if ($script:keyPresent) { throw 'Do not recreate an existing registry key with other application overrides' }
      $script:keyCreated = $true
    }
    function New-ItemProperty {
      [CmdletBinding()]param($Path, $Name, $PropertyType, $Value, [switch]$Force)
      if ($Force) { throw 'A machine override must not overwrite existing configuration' }
      $script:written += @{ path=$Path; name=$Name; value=$Value }
    }
    Initialize-LifecycleBrowserDebugging $false
    if ($script:written.Count) { throw 'Non-elevated launch changed machine configuration' }
    Initialize-LifecycleBrowserDebugging $true
    if ($script:written.Count -ne 1 -or $script:written[0].name -ne 'Localmotive.exe' -or $script:written[0].value -ne '--remote-debugging-port=10093' -or $script:written[0].path -notlike 'HKLM:*AdditionalBrowserArguments') { throw 'Elevated guest did not configure its application-scoped machine override' }
    $script:existing = $true; $refused = $false
    try { Initialize-LifecycleBrowserDebugging $true } catch { $refused = $true }
    if (-not $refused -or $script:written.Count -ne 1) { throw 'Existing machine override was not preserved' }
    $script:existing = $false; $script:keyPresent = $false
    Initialize-LifecycleBrowserDebugging $true
    if (-not $script:keyCreated -or $script:written.Count -ne 2) { throw 'Missing override key was not initialized' }
    Write-Host 'PASS: elevated guest uses an app-scoped machine override without overwriting policy'
  `], { encoding: "utf8", timeout: 30000 });
  assert.match(output, /PASS: elevated guest uses an app-scoped machine override/);
});

test("lifecycle preflight restricts stored authentication to an opted-in local run", { skip: process.platform !== "win32" }, async () => {
  const { execFileSync } = await import("node:child_process");
  // Execute the actual preflight condition. Stub only the external CLI.
  const output = execFileSync("pwsh", ["-NoProfile", "-Command", `
    $ErrorActionPreference = 'Stop'
    $env:GH_TOKEN = $null; $env:GITHUB_TOKEN = $null
    $env:CI = $null; $env:GITHUB_ACTIONS = $null
    $ast = [Management.Automation.Language.Parser]::ParseFile((Join-Path $PWD 'scripts/sandbox/host-run-lifecycle.ps1'), [ref]$null, [ref]$null)
    $guard = $ast.Find({ param($node) $node -is [Management.Automation.Language.IfStatementAst] -and $node.Extent.Text.StartsWith('if (-not $env:GH_TOKEN -and -not $env:GITHUB_TOKEN)') }, $true)
    if (-not $guard) { throw 'Missing auth preflight' }
    $script:authCalls = 0
    function gh { $script:authCalls++; $global:LASTEXITCODE = $script:authCode }
    $script:authCode = 0
    $AllowStoredGitHubLogin = $false
    $refused = $false
    try { & ([scriptblock]::Create($guard.Extent.Text)) } catch { $refused = $true }
    if (-not $refused -or $script:authCalls -ne 0) { throw 'Stored login accessed without local opt-in' }
    $AllowStoredGitHubLogin = $true
    & ([scriptblock]::Create($guard.Extent.Text))
    Write-Host 'PASS: stored login accepted'
    $script:authCode = 1
    $refused = $false
    try { & ([scriptblock]::Create($guard.Extent.Text)) } catch { $refused = $true }
    if (-not $refused) { throw 'Unauthenticated CLI was accepted' }
    Write-Host 'PASS: missing login refused'
    $env:CI = 'true'; $env:GITHUB_ACTIONS = 'true'
    $script:authCode = 0; $script:authCalls = 0
    $refused = $false
    try { & ([scriptblock]::Create($guard.Extent.Text)) } catch { $refused = $true }
    if (-not $refused -or $script:authCalls -ne 0) { throw 'CI accessed the stored login' }
    Write-Host 'PASS: CI cannot use stored login even with local opt-in'
  `], { encoding: "utf8", timeout: 30000 });
  assert.match(output, /PASS: stored login accepted/);
  assert.match(output, /PASS: missing login refused/);
  assert.match(output, /PASS: CI cannot use stored login/);
});

test("lifecycle authentication failure retains a structured failure document", { skip: process.platform !== "win32" }, async () => {
  const { spawnSync } = await import("node:child_process");
  const root = await mkdtemp(join(tmpdir(), "lm-lifecycle-auth-"));
  try {
    const result = spawnSync("pwsh", ["-NoProfile", "-Command", `
      function gh { $global:LASTEXITCODE = 1 }
      & $env:HARNESS_PATH -Tag v0.6.0 -Version 0.6.0 -EvidenceName authentication-fixture -FaultSimulation missing-assets
    `], {
      cwd: root, encoding: "utf8", timeout: 30000,
      env: { ...process.env, HARNESS_PATH: resolve("scripts/sandbox/host-run-lifecycle.ps1"), GH_TOKEN: "", GITHUB_TOKEN: "", CI: "true", GITHUB_ACTIONS: "true", TEMP: root, TMP: root, LOCALMOTIVE_SOURCE_REVISION: "" },
    });
    assert.equal(result.status, 1, `${result.stdout}${result.stderr}`);
    const file = join(root, "release-evidence/0.6.0/attestations/authentication-fixture.json");
    const raw = await readFile(file, "utf8");
    const doc = JSON.parse(raw.replace(/^\uFEFF/, ""));
    assert.equal(doc.status, "FAIL");
    assert.equal(doc.stage, "authentication");
    assert.match(doc.error, /GH_TOKEN|GITHUB_TOKEN/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("R04: the benchmark run owns its cancelled workers until they exit", async () => {
  const service = await readFile(join(process.cwd(), "src-tauri", "src", "measurement_service.rs"), "utf8");
  const client = await readFile(join(process.cwd(), "src-tauri", "src", "local_client.rs"), "utf8");
  // One client per run: every cancellable worker of the benchmark v2 run is
  // observable on the instance the run drains (prompt preparation included).
  const run = service.split("async fn benchmark_v2")[1].split("#[cfg(test)]")[0];
  // F9-02: the single construction happens inside publish_benchmark_slot,
  // which builds the fallible client before the active slot is published.
  const constructions = run.match(/local_client\(&server\.profile\)/g) ?? [];
  assert.equal(constructions.length, 1, "the v2 run constructs exactly one client");
  assert.ok(
    !/&local_client\(/.test(run.slice(run.indexOf("let run_client = client.clone();"))),
    "request sites reuse the run's client instead of constructing a new one",
  );
  // R16 follow-up: the drain bound is DERIVED from the workload's own request
  // deadline plus teardown slack. The old fixed 300 s ceiling sat below the
  // default 600 s deadline, so a cancelled slow request could outlive the
  // ceiling while ownership was already released.
  assert.match(service, /const WORKER_TEARDOWN_SLACK: std::time::Duration/);
  assert.match(service, /pub\(crate\) fn benchmark_drain_ceiling\(workload: &evidence::Workload\) -> Duration/);
  assert.doesNotMatch(service, /WORKER_DRAIN_CEILING/, "the fixed ceiling must not come back");
  // The drain happens before the manifest finalizes, and only a drained
  // client may return a record.
  const snapshot = service.split("pub(crate) fn run_benchmark_snapshot(")[1].split("pub(crate) async fn")[0];
  const drainInSnapshot = snapshot.indexOf("drain_owned_workers(&client, benchmark_drain_ceiling(&workload));");
  const manifestInSnapshot = snapshot.indexOf("let mut manifest = evidence::BenchmarkManifest {");
  assert.ok(drainInSnapshot > 0, "the run drains its workers before returning a record");
  assert.ok(manifestInSnapshot > drainInSnapshot, "the drain happens before the record finalizes");
  // The command-level hold: ownership is released only after the drain
  // returns, so a discarded result cannot release it while work continues.
  const v2 = service.split("pub(crate) async fn benchmark_v2(")[1].split("#[cfg(test)]")[0];
  const v2Drain = v2.indexOf("drain_owned_workers(&client, drain_ceiling);");
  const slotRelease = v2.indexOf("*active = None;");
  const resultRead = v2.indexOf("let result = benchmark_result?;");
  assert.ok(v2Drain > 0, "the command drains its owned workers on every exit path");
  assert.ok(slotRelease > v2Drain, "the benchmark slot is held until the drain returns");
  assert.ok(resultRead > v2Drain, "a discarded result cannot release ownership before the drain");
  // The drain never gives up and releases ownership while work continues: an
  // exceeded bound continues waiting instead of dropping the worker.
  assert.match(
    service,
    /pub\(crate\) fn drain_owned_workers\(client: &LocalHttpClient, ceiling: Duration\) \{[\s\S]*?while !client\.wait_for_worker_drain\(Duration::from_secs\(1\)\) \{\}/,
    "an expired drain bound keeps waiting instead of releasing ownership",
  );
  // The ownership accessor and the drain are production code, not test-only.
  const cfgTest = client.split("#[cfg(test)]");
  assert.match(client, /pub\(crate\) fn wait_for_worker_drain\(&self, ceiling: Duration\) -> bool/);
  assert.ok(
    !cfgTest.some((part) => part.slice(0, 200).includes("fn active_cancellable_workers")),
    "the worker counter is not gated to tests",
  );
  // The R04 regression proves the drain waits for the slow worker, and the
  // R16 regressions pin the derived bound and the every-exit-path hold.
  assert.match(client, /r04_worker_drain_waits_for_the_abandoned_slow_request_to_exit/);
  assert.match(service, /r16_the_drain_bound_follows_the_workload_request_deadline/);
  const lib = await readFile(join(process.cwd(), "src-tauri", "src", "lib.rs"), "utf8");
  assert.match(
    lib,
    /r16_the_benchmark_command_releases_ownership_only_after_its_workers_exit/,
    "the command-level ownership test must exist",
  );
});

test("the stalled-fetch deadline stays injectable and bounded in tests (CI cancellation fix)", async () => {
  const retry = await readFile(join(process.cwd(), "scripts", "lib", "http_retry.mjs"), "utf8");
  assert.match(retry, /deadlineMs = REQUEST_TIMEOUT_MS/, "the deadline must stay injectable");
  assert.match(retry, /AbortSignal\.timeout\(deadlineMs\)/, "the abort must use the injected deadline");
  const test = await readFile(join(process.cwd(), "scripts", "tests", "http_retry.test.mjs"), "utf8");
  assert.match(
    test,
    /fetchWithRetry\("https:\/\/example\.test\/stall", \{ fetchImpl, deadlineMs: 200 \}\)/,
    "the stalled-fetch test must bound its own clock, not rely on the unref'd default timer",
  );
  assert.match(test, /const keeper = setTimeout/, "the test must hold the event loop past the unref'd deadline timer");
  assert.match(test, /clearTimeout\(keeper\)/, "the keeper must be cleared");
});

test("publish promotes the verified bytes only after every material gate (G-06/G-09)", async () => {
  const release = await readFile(join(process.cwd(), ".github", "workflows", "release.yml"), "utf8");
  const promote = await readFile(join(process.cwd(), ".github", "workflows", "release-promote.yml"), "utf8");
  // The verify workflow must not offer a publish switch that does nothing.
  const workflows = await loadWorkflows(process.cwd());
  assert.deepEqual(Object.keys(workflows["release.yml"].on.workflow_dispatch.inputs), ["tag"]);
  // R16: the tag-push workflow has no publish job at all, so no tag push can
  // publish; publication requires the separate authorized dispatch.
  assert.ok(!/^  publish:/m.test(release), "the verify workflow must not carry a publish job");
  const gate = promote.split("\n  gate:")[1].split("\n  publish:")[0];
  const publish = promote.split("\n  publish:")[1];
  // Publication promotes the bundle the verify run qualified - it never
  // rebuilds and never rewrites the checksum inventory.
  assert.match(gate, /localmotive-\$\{\{ steps\.resolve\.outputs\.version \}\}-qualified/);
  assert.match(publish, /verify_release_promotion\.mjs/, "publish verifies the producer checksums and manifest together");
  assert.doesNotMatch(publish, /tauri build|sha256sum Localmotive/, "publish must not rebuild or rewrite the inventory");
  const steps = workflows["release.yml"].jobs.verify.steps;
  const lifecycle = steps.findIndex((step) => step.run?.includes("host-run-lifecycle.ps1"));
  const qualification = steps.findIndex((step) => step.run?.includes("verify_release_promotion.mjs"));
  assert.ok(lifecycle >= 0 && qualification > lifecycle, "qualification follows the native verdict");
  assert.equal(steps[qualification].if, undefined, "qualification cannot ignore a failed native verdict");
  // R02 (follow-up review db548c8) survives structurally: the accident that
  // published from a stray dispatch cannot recur because publication is not
  // reachable from the verify workflow at all, and the promotion workflow
  // demands the owner, an exact confirm phrase, a green verify run for the
  // same commit, and dry_run=false. Every refusal condition is asserted here.
  assert.match(promote, /if: github\.actor == github\.repository_owner/);
  assert.match(promote, /test "\$CONFIRM" = "PUBLISH \$TAG"/);
  assert.match(promote, /if: inputs\.dry_run == false/);
  assert.match(promote, /assert\.equal\(run\.conclusion, 'success'/);
  assert.match(promote, /assert\.equal\(run\.head_sha, process\.env\.EXPECTED_SHA/);
  assert.match(promote, /check-runs/);
  const policy = JSON.parse(await readFile(join(process.cwd(), ".github", "workflow-gates.json"), "utf8"));
  // The workflow-gates policy binds publish to the gate job and forbids any
  // publication mechanism inside the verify workflow.
  assert.deepEqual(policy.workflows["release-promote.yml"].publicationJobs.publish, ["gate"]);
  assert.deepEqual(policy.workflows["release.yml"].publicationJobs, {});
  assert.ok(
    policy.workflows["release.yml"].forbiddenCommands.includes("softprops/action-gh-release"),
    "the verify workflow is forbidden from publishing",
  );
  assert.ok(
    policy.workflows["release.yml"].forbiddenCommands.includes("gh release create"),
    "the verify workflow is forbidden from creating releases",
  );
  const result = validateWorkflowGates(await loadWorkflows(process.cwd()), policy);
  assert.equal(result.ok, true, result.failures.join("\n"));
});

test("the gate policy refuses a verify workflow that can publish", () => {
  const policy = {
    workflows: {
      "release.yml": {
        gates: {},
        packageJobs: {},
        publicationJobs: {},
        forbiddenCommands: ["softprops/action-gh-release", "contents: write"],
      },
    },
  };
  const workflow = {
    "release.yml": {
      jobs: {
        verify: { steps: [{ uses: "softprops/action-gh-release@3bb12739" }] },
      },
    },
  };
  const failure = validateWorkflowGates(workflow, policy);
  assert.equal(failure.ok, false);
  assert.match(failure.failures.join("\n"), /forbidden/);
  const writePermission = {
    "release.yml": {
      jobs: { verify: { permissions: { contents: "write" }, steps: [{ run: "echo hi" }] } },
    },
  };
  const writeFailure = validateWorkflowGates(writePermission, policy);
  assert.equal(writeFailure.ok, false);
  assert.match(writeFailure.failures.join("\n"), /granted contents: write/);
  const clean = {
    "release.yml": { permissions: { contents: "read" }, jobs: { verify: { steps: [{ run: "echo hi" }] } } },
  };
  assert.equal(validateWorkflowGates(clean, policy).ok, true);
});

test("DC-04.V2 the authority distinction stays visible end to end", async () => {
  const lib = await readFile(join(process.cwd(), "src-tauri", "src", "lib.rs"), "utf8");
  // The two completion messages are the user-visible provenance distinction
  // between a signed curated row and a user-approved override record.
  assert.match(lib, /Download complete: checksum verified against your local override digest\./);
  assert.match(lib, /Download complete and checksum verified\./);
  assert.match(lib, /authorized\.authority == "user"/);
  const driver = await readFile(join(process.cwd(), "scripts", "g05_dc04_override.mjs"), "utf8");
  for (const leg of [
    "dc04.override-saved-with-correct-digest",
    "dc04.incorrect-checksum-download-refused",
    "dc04.revoked-download-refused-with-identity",
    "dc04.revoked-refusal-touches-no-network",
    "dc04.curated-row-cannot-be-removed-here",
  ]) {
    assert.match(driver, new RegExp(leg.replace(/[.]/g, "\.")));
  }
});

test("DC-04.V2 the download seam is loopback-only and verifier-gated", async () => {
  const source = await readFile(join(process.cwd(), "src-tauri", "src", "download.rs"), "utf8");
  // The packaged verifier points catalog downloads at a local fixture to run
  // the correct/incorrect-checksum legs against controlled bytes. The seam
  // must stay gated on the verifier profile and restricted to plain-HTTP
  // loopback so an authenticated download can never be redirected remotely.
  assert.match(source, /LOCALMOTIVE_VERIFY_ISOLATED_ROOT/);
  assert.match(source, /LOCALMOTIVE_HF_BASE/);
  assert.match(source, /http:\/\/127\.0\.0\.1:/);
  assert.match(source, /http:\/\/localhost:/);
  assert.match(source, /resolve_url_honors_the_loopback_fixture_inside_the_verifier_profile/);
});

test("S-26: the hardware probe runs only in its explicit qualification job", async () => {
  const hw = await readFile(
    join(process.cwd(), ".github", "workflows", "hardware-qualify.yml"),
    "utf8",
  );
  assert.match(
    hw,
    /inputs\.runtime_install_key != ''/,
    "the probe job is gated on an explicit runtime install key",
  );
  assert.match(
    hw,
    /qualify_managed_runtime_on_current_host/,
    "the probe job runs the ignored hardware probe explicitly",
  );
  assert.match(
    hw,
    /--ignored --nocapture/,
    "the probe is invoked with --ignored from the qualification job only",
  );
  // The diagnostic probe in core.rs carries no acceptance assertions and says so.
  const core = await readFile(join(process.cwd(), "src-tauri", "src", "core.rs"), "utf8");
  assert.match(core, /DIAGNOSTIC, not an acceptance test/, "the local-tree probe is labelled as a diagnostic");
  // No CI or release job silently runs the ignored probes.
  for (const file of ["ci.yml", "release.yml"]) {
    const body = await readFile(join(process.cwd(), ".github", "workflows", file), "utf8");
    assert.doesNotMatch(body, /--ignored/, `${file} must not run ignored probes`);
  }
});

// Regression for the 2026-09-12 incident: a job-level `env:` containing only
// comment lines made GitHub reject the ENTIRE release.yml (placeholder failed
// runs on every push, workflow registered by path, no real jobs ever ran).
// actionlint reports the same class as "[syntax-check] expecting a single
// ${{...}} expression or mapping value". This gate keeps the whole workflow
// set free of comment-only mapping keys.
test("no workflow mapping key is comment-only (GitHub rejects the whole file)", async () => {
  const { findCommentOnlyMappings } = await import("../verify_workflow_syntax.mjs");

  // The exact broken shape must be flagged.
  const broken = [
    "jobs:",
    "  lifecycle:",
    "    env:",
    "      # matrix for the qualification legs",
    "    steps:",
    "      - run: echo ok",
    "",
  ].join("\n");
  const brokenFindings = findCommentOnlyMappings(broken);
  assert.equal(brokenFindings.length, 1, "comment-only env must be flagged");
  assert.equal(brokenFindings[0].key, "env");

  // A mapping with real entries (plus comments) is fine.
  const ok = ["jobs:", "  a:", "    env:", "      # comment", "      A: b", "    steps:", "      - run: x", ""].join("\n");
  assert.deepEqual(findCommentOnlyMappings(ok), []);

  // Every workflow in the repo must pass, release.yml included.
  for (const file of ["release.yml", "ci.yml", "catalog.yml", "hardware-qualify.yml"]) {
    const body = await readFile(join(process.cwd(), ".github", "workflows", file), "utf8");
    assert.deepEqual(
      findCommentOnlyMappings(body),
      [],
      `${file} must not contain comment-only mapping keys`,
    );
  }
});

// Regression for the 2026-09-12 lifecycle evidence incident: a killed chain
// left an orphaned attempt running, and its late TIMEOUT record overwrote a
// newer clean PASS for the same scenario. The harness now holds a per-scenario
// lock (live owners refuse, dead owners are taken over) and re-authorizes
// every evidence write against that lock.
test("lifecycle harness refuses to race evidence for one scenario", async () => {
  const harness = await readFile(join(process.cwd(), "scripts", "sandbox", "host-run-lifecycle.ps1"), "utf8");
  assert.match(harness, /Refusing to race its evidence/, "live owners must make a second run refuse");
  assert.match(harness, /function Assert-LockOwnership/, "the ownership assert must exist");
  const guards = harness.match(/Assert-LockOwnership/g) || [];
  assert.ok(
    guards.length >= 6,
    `expected the ownership assert plus at least five guarded writes; found ${guards.length}`,
  );
  const witnesses = await readFile(join(process.cwd(), "scripts", "sandbox", "test-fault-evidence.ps1"), "utf8");
  assert.match(witnesses, /witness-live-lock/, "the live-lock refusal witness must exist");
  assert.match(witnesses, /witness-stale-lock/, "the stale-lock takeover witness must exist");
});

// Fresh-checkout validation (2026-09-12): the qualification manifest must
// validate from a clean checkout - every referenced record committed, no
// scratch-state references (the pre-fix manifest pointed mt06_cancellation at
// a gitignored .hermes-0.6 path, which cannot validate in a clone).
//
// Live-manifest scope (2026-09-14): the committed manifest binds the
// HISTORICAL freeze-10 campaign (source e9a36b3, workflow digest 091a0d16).
// The qualification JOB of each Release verify run rebuilds the manifest
// from that run's own inventory plus its fresh staged packaged record and
// validates it with --expect-source; that per-run manifest is the release
// evidence, not this historical file. So this test pins the manifest's
// internal consistency (records resolve, digests match, no scratch paths)
// but exempts the workflow-file binding, which legitimately drifts whenever
// release.yml is repaired (runs 34803387581, 34807541476).
test("the qualification manifest validates and references only committed records", async () => {
  const { verifyQualificationManifest } = await import("../verify_qualification_manifest.mjs");
  const manifestPath = "release-evidence/0.6.0/qualification-manifest-0.6.0.json";
  const { failures } = verifyQualificationManifest({ manifestPath });
  const workflowDriftOnly = failures.filter(
    (failure) => !failure.startsWith("workflow file digest drifted:"),
  );
  assert.deepEqual(workflowDriftOnly, [], failures.join("; "));
  const manifest = JSON.parse(await readFile(join(process.cwd(), manifestPath), "utf8"));
  for (const [name, entry] of Object.entries(manifest.records)) {
    assert.ok(
      !/(^|[\/])\.hermes-0\.6([\/]|$)/.test(entry.path),
      `${name} must reference a committed record, not scratch state: ${entry.path}`,
    );
    assert.ok(
      entry.sha256_lf,
      `${name} must carry an EOL-normalized digest so a fresh checkout validates on any platform`,
    );
  }
  assert.equal(manifest.artifacts.length, 3, "the manifest binds exactly the three staged artifacts");
  assert.match(manifest.sourceRevision, /^[0-9a-f]{40}$/);
  assert.ok(manifest.workflowFile?.sha256, "the release workflow revision is recorded separately");
});
