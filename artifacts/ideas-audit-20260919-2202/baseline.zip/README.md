# Localmotive

Localmotive is a Windows desktop control plane for local GGUF inference.

Use Localmotive to manage `llama.cpp` runtimes, organize GGUF models,
build launch profiles, run `llama-server`, and measure generation throughput.

Localmotive is not an inference engine.

The selected `llama-server.exe` performs model loading and inference.
The same executable provides the local API and optional WebUI.

## Download

Download the current release from [GitHub Releases][releases].
The current tip ships as **Latest** on the repository home page.

Each release provides these Windows x64 files:

- `Localmotive_<version>_x64-setup.exe` is the NSIS installer.
- `Localmotive_<version>_x64.msi` is the MSI installer.
- `Localmotive_<version>_x64-portable.exe` runs without installation.
- `SHA256SUMS-<version>.txt` covers the three application files.
- `packaged-verification-<version>.json` is the packaged behavior evidence.
- `candidate-inventory-<version>.json` is the candidate size and digest evidence.

For example, release 0.5.0 ships `Localmotive_0.5.0_x64-setup.exe`,
`Localmotive_0.5.0_x64.msi`, `Localmotive_0.5.0_x64-portable.exe`,
and `SHA256SUMS-0.5.0.txt`.

The application files do not have Authenticode signatures.
Signing is deferred by owner order, so every ship is honestly unsigned:
the release name carries `(unsigned)`, the notes disclose SmartScreen,
and no signature is claimed.

Windows SmartScreen can show a warning when you start an unsigned file.

Verify a downloaded file before use:

```powershell
Get-FileHash .\Localmotive_0.5.0_x64-setup.exe -Algorithm SHA256
Get-Content .\SHA256SUMS-0.5.0.txt
```

Compare the two SHA-256 values.

## Requirements

The current release requires a Windows x64 computer.

Select one of these runtime sources:

- An official Windows `llama.cpp` build installed by Localmotive.
- An existing compatible `llama-server.exe` selected by the user.

Provide an existing GGUF model or use **HF Catalog** to download one.

Runtime downloads, catalog refreshes, and model downloads need network access.

Catalog browsing can use the last valid signed cache or embedded catalog
without network access.

AI Tune also needs credentials and network access for one configured provider.

Check model size and hardware requirements before each download.

The bundled catalog holds 158 models and 1417 single-file GGUF builds
(schemaVersion 2, updated 2026-09-10).
Memory needs and speed depend on the model, quantization, context, backend,
and computer hardware.

## Quick start

1. Start Localmotive.
2. Open **Runtime**.
3. Review the evidence label, then install the recommended `llama.cpp` build or select an existing runtime.
4. Open **Inventory**.
5. Select the folder that contains the GGUF files.
6. Select a complete model.
7. Review the generated profile.
8. Start the server.
9. Select **Open chat** to open the `llama.cpp` WebUI.

You can also select a model folder and download a model from **HF Catalog**.

New profiles use these defaults:

- Host: `127.0.0.1`
- Preferred port: `8080`
- Context: `8192`
- Parallel slots: `1`
- GPU layers: `all`

If the preferred port is unavailable, Localmotive scans a bounded port range.

## Features

### Runtime management

- Detect the Windows architecture and graphics adapters.
- Read the exact approved `ggml-org/llama.cpp` release from GitHub.
- Recommend an accelerator only when an exact L4 compatibility record matches.
- Recommend CPU with an explicit reason when no exact accelerator record matches.
- Show the other release asset choices.
- Pair CUDA runtime archives with the matching `cudart` archive.
- Require each approved asset's exact size and SHA-256.
- Reject traversal, links, junction escapes, duplicate paths, and archive resource-limit violations.
- Verify every extracted file against a compiled exact-content manifest.
- Remove a failed installation's staging directory.
- Install managed runtimes under `%LOCALAPPDATA%\Localmotive\runtimes`.
- Keep runtime versions and backend variants in separate directories.
- Register and inspect an existing `llama-server.exe`.
- Read supported options from the selected runtime's `--help` output.
- Omit generated options that the selected runtime does not advertise.

The approved release contains x64 CPU, CUDA, ROCm, SYCL, OpenVINO, and Vulkan assets.

Localmotive shows only assets that match the running application architecture.

The 0.5.0 ARM64 assets remain dormant and do not create install options.

### Model inventory and profiles

- Scan a selected folder recursively for `.gguf` files.
- Group split GGUF shards into one logical model.
- Block the Start button when a logical model has missing shards.
- Read filenames and file sizes without reading model tensor data.
- Detect `mmproj`, MTP, DSpark, DFlash, and EAGLE-3 files by filename.
- Associate companions in the same top-level model family folder.
- Rank companions by role, quantization proximity, and name.
- Configure model, cache, sampling, network, and placement options.
- Preserve advanced extra arguments as separate process arguments.
- Show the exact filtered command before launch.

### Server control and benchmarking

- Start one `llama-server` child process at a time.
- Redirect server output to a log file.
- Show recent server log lines in the application.
- Report the owned process, endpoint, profile, command, and exit state.
- Stop only the child process stored in the application state.
- Open the built-in `llama.cpp` WebUI when the profile enables it.
- Benchmark `/completion` with a fixed deterministic workload.
- Run one warmup before the measured repetitions.
- Report mean, median, minimum, and maximum generation throughput.

### Curated Hugging Face catalog

- Browse a maintainer-curated list of GGUF files built from the allowlist in `catalog/providers.json`.
- Search by repository, family, publisher, parameters, summary, and tags.
- Filter by tag, quantization, author, licence, pipeline, architecture, gated status, and maximum file size.
- Narrow by recency: every entry carries `lastModified` from Hugging Face, and the allowlist covers repos updated in the last 90 days.
- Sort by downloads, likes, repository name, or smallest file.
- **Hardware fit** is on by default: the app reads detected dedicated VRAM, else shared memory, else system memory, and hides files above half that budget. The toggle explains its budget source, and the user can disable it or widen it to 25, 50, 75, or 100 percent of budget.
- Download selected model bytes from Hugging Face to the model folder.
- Use one connection when the server does not prove range support.
- Use bounded parallel requests after valid range responses.
- Keep partial bytes and per-chunk state after an interruption.
- Reject inconsistent remote identity, size, and range responses.
- Check the exact size and catalog SHA-256 before finalization.
- Delete a partial model when final SHA-256 verification fails.
- Reject symbolic links and Windows reparse points in the download path.
- Accept network catalog changes only after Ed25519 verification.
- Fall back to the signed cache or embedded catalog when necessary.
- Refresh is guarded: one refresh runs at a time, repeats within 1560 min get a remaining-minutes message, and the list shows last success plus any cooldown.

The catalog file is schemaVersion 2. The allowlist ships inside the signed
artifact, so adding a trusted author is a catalog publish, never an app
release. The app binary holds no author list.

The optional Hugging Face token supports authenticated Hub requests.
The token also supports gated repositories accepted by the account.

Localmotive stores the token in Windows Credential Manager.
The service name is `Localmotive HF`.

Localmotive sends the token in an `Authorization` header.
Localmotive does not put the token in a download URL or process argument.

### AI Tune

AI Tune asks a cloud model to propose throughput settings.
Localmotive measures each accepted proposal on the local computer.

The user can replace the saved profile with the best measured profile.

The application includes configurations for these providers:

- OpenRouter
- Anthropic
- OpenAI
- Google Gemini
- DeepSeek
- xAI

OpenRouter supports browser sign-in with OAuth PKCE or a pasted API key.
The other provider interfaces accept pasted API keys.

Localmotive stores cloud credentials in Windows Credential Manager.
The service name is `Localmotive`.

The frontend receives only credential status and a masked suffix.

The cloud advisor can change only fields in the tuning whitelist.
The whitelist excludes identity, network, path, and security fields.

Each trial starts `llama-server` and waits for `/health`.
Each successful launch is measured through `/completion`.
Localmotive then stops the trial process.

## Network and data behavior

### Runtime network access

Localmotive reads release metadata from the GitHub API.
Localmotive downloads selected official runtime archives from GitHub.

### Model catalog

Localmotive reads the catalog and signature from `raw.githubusercontent.com`.
Localmotive downloads selected model bytes from Hugging Face redirects.

If configured, the Hugging Face authorization header starts at the Hub URL.

### AI Tune network access

Localmotive sends a structured tuning brief to the selected cloud provider.

The brief includes these values:

- Hardware facts and system RAM size
- GGUF metadata
- Runtime capabilities
- Companion paths
- The baseline profile
- Trial commands
- Trial results and errors

AI Tune does not upload GGUF model bytes.

AI Tune does send local runtime, model, and companion paths.
AI Tune also sends profile values and measured trial evidence.

Do not use AI Tune if this metadata must remain local.

The selected provider can apply usage fees, quotas, retention policies,
and service terms.

### OpenRouter sign-in

OpenRouter sign-in opens `openrouter.ai` in the browser.
The OAuth PKCE flow returns through a temporary loopback callback.

### Local inference

Localmotive sends health checks and benchmarks to the configured server.
The WebUI communicates with the local `llama-server` endpoint.

## Local storage

Localmotive stores these values in the application WebView's local storage:

- Model folder
- Selected runtime path
- Selected cloud provider and advisor model
- Saved launch profiles
- Saved benchmark results
- Saved tuning reports

Localmotive does not encrypt these local-storage values.

Beyond local storage, Localmotive keeps this state on disk (audit QD-04):

| Store | Location | Lifecycle |
|---|---|---|
| Signed catalog cache and refresh stamp | Application cache directory; falls back to the temporary directory | Rebuilt from the signed catalog on refresh; safe to delete (rows reload from the bundled copy) |
| Catalog SQLite mirror (`catalog-mirror.sqlite`) | Application cache directory | Holds the verified mirror plus your user-added rows; delete only to reset user additions, the app rebuilds the mirror |
| Runtime downloads and installs | `%LOCALAPPDATA%\Localmotive` | Managed versioned installs; remove a version from the Runtime screen |
| Benchmark and tuning evidence | Local storage plus saved benchmark manifests | Preserve these records before clearing application data |
| Server logs and failure records | Operating system temporary directory | Bounded rotation as described below |

Settings can be reset per record by clearing the matching `localmotive:*`
local-storage key; a corrupt record is moved to `localmotive:quarantine:*`
instead of crashing the window.

The reduced application removes quality/ranking, calibration fitting,
external-evidence import, and share export. Existing calibration and exchange
files remain untouched but are no longer supported by the application.
Saved benchmark manifests and replay remain supported.

Server logs use the operating system temporary directory.
The server log subdirectory is `localmotive`.
Each run writes a uniquely named log and is capped at 8 MiB of retained output.
The newest ten runs per prefix and 64 MiB in total are kept.
The three newest failure records beside their logs survive that cleanup.
Delete the `localmotive` subdirectory to clear all logs immediately.
The runtime writes these logs; a runtime can include local paths and model
names in its own output, so review a log before you share it.

Cloud credentials and the Hugging Face token do not use local storage.
They use Windows Credential Manager.

## Security boundaries

- New profiles bind to `127.0.0.1` by default.
- Non-loopback profiles require an API key file.
- Non-loopback profiles require restricted CORS origins.
- API secrets use `--api-key-file` instead of a literal key argument.
- Localmotive passes process arguments without a shell command string.
- Child processes use `CREATE_NO_WINDOW` on Windows.
- Runtime and model paths must identify files before server launch.
- Catalog downloads must match the validated catalog.
- Catalog filter, facet, budget, and launch-profile strings are bounded in Rust at the Tauri boundary. UI limits are hints only.

Advanced extra arguments remain an expert interface.

Localmotive does not provide a permissions workflow for shell, file,
or agent options supplied through extra arguments.

Review the generated command before launch.

## Supported platforms

Read the support matrix by evidence type, not by inference (audit GH-07):

- **The 0.6.0 candidate** passed the packaged lifecycle (MSI and NSIS
  install, launch, uninstall) and the upgrade checks from both v0.4.1 and
  v0.5.0 in Windows Sandbox, bound to candidate digests. CUDA inference on
  the RTX 5090 was measured through the packaged app; tamper refusal, TLS
  serving, catalog fallback and download resume were exercised packaged.
- **Do not generalize**: other hardware classes, Windows 10, screen
  readers, live cloud providers and OS-crash behavior remain untested and
  unclaimed. The full matrix, row by row with its evidence class, is
  `docs/SUPPORT-MATRIX.md`.
- A support claim applies to one version only when release evidence is present
  for that version. See `docs/EVIDENCE-MATRIX.md`.

Night jobs run on the self-hosted runner `DESKTOP-HPTF57N-zen5-blackwell`.
The 01:00–06:00 Asia/Dubai window describes the historical night-only
schedule; current CI, release, and hardware jobs all run on this same
self-hosted host whenever work is queued.

Other Windows hardware may work but remains untested and unsupported until packaged attestations exist.

macOS remains out of scope for this matrix.

Code signing status is DEFERRED_BY_OWNER: Authenticode is postponed until the project is more mature (owner order 2026-09-09). No paid cert. SignPath stays pending or ignored and blocks no gate.

Windows installers remain honestly unsigned with disclosure. Windows SmartScreen can show a warning when you start an unsigned file. Unsigned artifacts ship as full releases, not GitHub Pre-releases, so the current tip stays visible as Latest.

## Current limitations

- The current application release provides Windows x64 artifacts only.
- Windows 10 and most hardware classes do not have L4 product evidence; `docs/SUPPORT-MATRIX.md` lists what is measured, exercised, or untested.
- [Microsoft ended normal Windows 10 support on October 14, 2025](https://support.microsoft.com/en-us/help/3207828); use an applicable supported servicing or ESU policy.
- Missing P0 rows are disclosed and do not receive support claims.
- This repository does not publish an ARM64 Localmotive application or runtime option.
- Localmotive supervises one model server at a time.
- Windows child processes enter a kill-on-close Job Object before execution resumes.
- Stop and cancellation terminate the complete contained process tree.
- Catalog downloads support single-file GGUF entries only.
- Inventory scanning supports split GGUF files already on disk.
- Application updates require a newer manual installation or executable.
- Localmotive 0.6.0 ships unsigned under the deferred-signing exception: no Authenticode signatures exist, so no signature match can be claimed. Verify the published SHA-256 checksums before use. SmartScreen can warn on unsigned files.
- Signing boxes are deferred, not green, and block no gate.

## Troubleshooting

### SmartScreen shows a warning

Localmotive 0.6.0 ships unsigned under the deferred-signing exception: there is no Authenticode signer to verify. Verify the published SHA-256 checksums before use.

SmartScreen can warn on unsigned files.

### A model is incomplete

Place every numbered shard under the selected model folder.
Scan the inventory again.

### A gated model download fails

Accept the repository license on Hugging Face.
Add a Hugging Face read token with access to the repository.

### A download stops

Select **Download** again to reuse valid saved chunks.
Localmotive restarts when the saved remote identity no longer matches.

### The server does not start

Inspect the application notice and server log.
Confirm that the runtime, model, companion, and key-file paths still exist.

## Build from source

Install the [Tauri prerequisites for Windows][tauri-prerequisites].

Use Node.js `^20.19.0 || >=22.12.0` (the locked Vite requires it; `package.json` declares `engines` and pins the npm version) and the Rust toolchain pinned in `rust-toolchain.toml` (1.98.1, mirrored by `rust-version` in `src-tauri/Cargo.toml`). Update both files together and re-run the full check suite when the toolchain changes.

Install the Microsoft C++ Build Tools and WebView2 requirements described
by the linked Tauri prerequisites.

```bash
git clone https://github.com/sato942/localmotive.git
cd localmotive
npm ci
npm run tauri dev
```

Build the application and Windows bundles:

```bash
npm run tauri build
```

The Windows x64 build produces these local artifacts:

- `src-tauri/target/release/localmotive.exe`
- `src-tauri/target/release/bundle/msi/Localmotive_<version>_x64_en-US.msi`
- `src-tauri/target/release/bundle/nsis/Localmotive_<version>_x64-setup.exe`

## Test and verify

Run the frontend, catalog, and production build checks:

```bash
npm run check
```

Run the Rust checks:

```bash
cd src-tauri
cargo fmt --check
cargo clippy --locked --all-targets -- -D warnings
RUSTDOCFLAGS='-D warnings' cargo test --locked
```

GitHub Actions builds the packaged application.
The workflow starts the portable executable for a startup smoke test.

The smoke test does not prove model or GPU compatibility.
The smoke test does not test installer behavior or all Windows versions.

Release verification uses three jobs: resolve the tag on main, audit Rust
dependencies, then check/build/qualify in one workspace. The native lifecycle
matrix retains its 120-minute deadline. The qualified bundle includes the
SBOM and evidence; failed or cancelled runs retain diagnostics.

Publication uses `release-promote.yml`. It requires the repository owner,
the exact `PUBLISH <tag>` confirmation, a successful verification run for the
same source, and `dry_run=false`. Promotion validates downloaded bytes without
rebuilding them, then reads back the published assets. The default dry run
does not publish. Missing qualification records still block publication.

## Architecture

```text
src/                      React and TypeScript interface
src-tauri/src/lib.rs      Tauri commands and application state
src-tauri/src/core.rs     Models, profiles, runtimes, and benchmarks
src-tauri/src/runtime.rs  Hardware and managed runtime installation
src-tauri/src/catalog.rs  Signed catalog and Hugging Face token
src-tauri/src/download.rs Resumable model downloader and path controls
src-tauri/src/gguf.rs     Bounded GGUF metadata reader
src-tauri/src/tune.rs     Tuning whitelist and measured loop
src-tauri/src/cloud.rs    Cloud providers, OAuth, and credentials
src-tauri/src/proc.rs     Windows child-process construction
catalog/                  Curated model catalog and signature
scripts/                  Catalog and packaged-application checks
```

Rust owns filesystem, network, credential, process, and measurement work.
React owns presentation and local interface state.

Tauri commands form the boundary between both parts.

## Contributing

Read [AGENTS.md](AGENTS.md) before changing the repository.

Add a regression test for each behavioral change.
Run the complete check suite before you open a pull request.

Use the [issue tracker][issues] for defects and feature proposals.

Do not include credentials or private model paths in a public issue.
Remove sensitive content from logs before you attach the logs.

See these project records for more detail:

- [CHANGELOG.md](CHANGELOG.md) contains the release history.
- [catalog/README.md](catalog/README.md) contains catalog rules.
- [docs/DESIGN.md](docs/DESIGN.md) contains the interface specification.
- [docs/OPTION_MAP.md](docs/OPTION_MAP.md) explains profile grouping.
- [docs/LLAMA-SERVER-README.md](docs/LLAMA-SERVER-README.md) is imported reference.

## License and affiliation

Localmotive is available under the [MIT License](LICENSE).

Localmotive is not affiliated with or endorsed by these organizations:

- `ggml-org`
- Hugging Face
- The listed cloud providers

`llama.cpp`, downloaded models, and cloud services have separate terms.

Review the applicable license and model card before use or redistribution.

[issues]: https://github.com/sato942/localmotive/issues
[releases]: https://github.com/sato942/localmotive/releases/latest
[tauri-prerequisites]: https://v2.tauri.app/start/prerequisites/
