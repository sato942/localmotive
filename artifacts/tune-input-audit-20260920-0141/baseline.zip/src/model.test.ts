import { describe, expect, it } from "vitest";
import * as modelModule from "./model";
import {
  errorText,
  evidenceTone,
  type DownloadJob,
  type LaunchProfile,
  formatExtraArgs,
  normalizeProfile,
  normalizeTuningReport,
  parseExtraArgs,
  safeJsonParse,
  artifactReadyForLaunch,
  catalogBuildFit,
  describeSamples,
  reconcileDraftCompanion,
  catalogRevision,
  conflictingCapacityMetrics,
  defaultWorkload,
  derivedEvidence,
  activeDownloadJob,
  downloadKey,
  newestDownloadJob,
  downloadPercent,
  downloadReadiness,
  hardwareFitBudget,
  keepLatestRequest,
  evidenceRunLabel,
  selectionAfterRescan,
  displayedSelection,
  tuningRunSummary,
  applySuggestedPort,
  profileIdentity,
  profileNumberError,
  profileNumberLimits,
  type ProfileNumberField,
  responseIsCurrent,
  managedHealthRequest,
  manualGpuOverride,
  modelHiddenByFitRule,
  retainOrDisposeListener,
  etaLabel,
  originLabel,
  rateLabel,
  runtimeIdentityMismatch,
  runtimeInstallRequest,
  runtimeCatalogViewState,
  runtimeOptionState,
  suggestedProfile,
  validateWorkload,
  type ArtifactInspection,
  type DeviceAllocationPlan,
  type Evidence,
  type GpuAdapterInfo,
  type GithubAsset,
  type LogicalModel,
  type ManagedRuntimeRecord,
  type RuntimeIdentity,
  type RuntimeOption,
  type StorageVolumeEvidence,
  type Workload,
} from "./model";

describe("runtime catalog presentation", () => {
  it("preserves typed rate-limit retry metadata from IPC", () => {
    const error = {
      kind: "rateLimited" as const,
      message: "Retry later",
      retryAfterSeconds: 120,
    };

    const parser = (
      modelModule as typeof modelModule & {
        runtimeCatalogErrorFromUnknown?: (value: unknown) => unknown;
      }
    ).runtimeCatalogErrorFromUnknown ?? (() => null);
    expect(parser(error)).toEqual(error);
  });

  it("shows a catalog error after loading stops", () => {
    const error = {
      kind: "rateLimited" as const,
      message: "Catalog request was rate limited",
      retryAfterSeconds: 120,
    };
    expect(
      runtimeCatalogViewState({
        loading: false,
        catalog: null,
        error,
      }),
    ).toEqual({ kind: "error", error });
  });

  it("uses an explicit empty state when an approved catalog has no installable options", () => {
    const catalog = {
      tag: "b10816",
      publishedAt: "2026-09-04T00:00:00Z",
      options: [],
      availability: [],
      origin: "network" as const,
      warning: null,
      recommendationReason: "CPU fallback fixture",
    };

    expect(
      runtimeCatalogViewState({
        loading: false,
        catalog,
        error: null,
      }),
    ).toEqual({ kind: "empty", catalog });
  });

  it("sends only the immutable install key and exact selected adapter", () => {
    const cpu = { backend: "cpu", installKey: "cpu" } as RuntimeOption;
    const cuda = { backend: "cuda", installKey: "cuda-13.3" } as RuntimeOption;

    expect(runtimeInstallRequest(cpu, "ignored-adapter")).toEqual({
      installKey: "cpu",
      adapterId: null,
    });
    expect(runtimeInstallRequest(cuda, "gpu-7")).toEqual({
      installKey: "cuda-13.3",
      adapterId: "gpu-7",
    });
    expect(() => runtimeInstallRequest(cuda, "")).toThrow(/adapter/i);
  });

  it("sends only immutable managed-health authority while the backend owns the model pin", () => {
    const cpu = { backend: "cpu", installKey: "cpu" } as RuntimeOption;
    const cuda = { backend: "cuda", installKey: "cuda-13.3" } as RuntimeOption;

    expect(managedHealthRequest(cpu, "ignored")).toEqual({
      installKey: "cpu",
      adapterId: null,
    });
    expect(managedHealthRequest(cuda, "gpu-7")).toEqual({
      installKey: "cuda-13.3",
      adapterId: "gpu-7",
    });
  });
});

describe("managed health presentation", () => {
  it("presents an interrupted health contract as cancelled rather than failed", () => {
    const classify = (
      modelModule as typeof modelModule & {
        managedHealthOutcome?: (value: modelModule.ManagedHealthResult) => string;
      }
    ).managedHealthOutcome ?? (() => "failed");
    const result = {
      passed: false,
      stages: [
        {
          stage: "device_enumeration" as const,
          status: "FAIL" as const,
          durationMs: 1,
          failureReason: "cancelled" as const,
          detail: "Cancelled by the user",
          completion: null,
        },
      ],
    } as modelModule.ManagedHealthResult;

    expect(classify(result)).toBe("cancelled");
  });
});

describe("launch failure presentation", () => {
  it("shows the message and bounded log tail from structured launch evidence", () => {
    const failure = JSON.stringify({
      schema: 1,
      phase: "health_exit",
      exitCode: 7,
      timedOut: false,
      cancelled: false,
      message: "llama-server exited before becoming healthy",
      logTail: "useful exit detail",
    });

    expect(errorText(failure)).toBe(
      "llama-server exited before becoming healthy\nuseful exit detail",
    );
  });

  it("shows structured server-status failure evidence", () => {
    expect(
      errorText({
        schema: 1,
        phase: "runtime_exit",
        exitCode: 7,
        timedOut: false,
        cancelled: false,
        message: "llama-server exited after health validation",
        logTail: "useful runtime exit detail",
      }),
    ).toBe("llama-server exited after health validation\nuseful runtime exit detail");
  });
});

describe("v0.3 evidence contracts", () => {
  it("preserves device capacity beside the unvalidated allocation estimate", () => {
    const evidence = (value: number): Evidence<number> => ({
      value,
      level: "observed",
      source: { kind: "windowsApi", detail: "fixture" },
      observedAtMs: 42,
      notes: [],
    });
    const plan: DeviceAllocationPlan = {
      adapterId: "gpu-0",
      weightBytes: evidence(100),
      kvCacheBytes: evidence(50),
      totalBytes: evidence(150),
      availableBytes: evidence(200),
      note: "Launch validation remains required",
    };

    expect(plan.availableBytes.value).toBe(200);
    expect(plan.note).toMatch(/validation/i);
  });

  it("keeps resident and available bytes separate for each volume", () => {
    const volume: StorageVolumeEvidence = {
      volumePath: {
        value: "C:\\",
        level: "observed",
        source: { kind: "windowsApi", detail: "GetVolumePathNameW" },
        observedAtMs: 42,
        notes: [],
      },
      residentBytes: {
        value: 100,
        level: "exact",
        source: { kind: "fileSystem", detail: "selected artifact bytes" },
        observedAtMs: 42,
        notes: [],
      },
      availableBytes: {
        value: 2_000,
        level: "observed",
        source: { kind: "windowsApi", detail: "GetDiskFreeSpaceExW" },
        observedAtMs: 42,
        notes: [],
      },
    };

    expect(volume.residentBytes.value).toBe(100);
    expect(volume.availableBytes.value).toBe(2_000);
  });

  it("propagates an unknown required input into derived evidence", () => {
    const result = derivedEvidence(
      4096,
      ["exact", "unknown"],
      { kind: "calculation", detail: "KV bytes" },
      42,
      [],
    );

    expect(result.level).toBe("unknown");
    expect(result.value).toBeNull();
    expect(result.notes.join(" ")).toMatch(/required input/i);
  });

  it("keeps known calculations derived instead of measured", () => {
    const result: Evidence<number> = derivedEvidence(
      4096,
      ["exact", "observed"],
      { kind: "calculation", detail: "KV bytes" },
      42,
      [],
    );

    expect(result.level).toBe("derived");
    expect(result.value).toBe(4096);
  });

  it("validates the default benchmark workload", () => {
    const workload = defaultWorkload();

    expect(validateWorkload(workload)).toEqual([]);
    expect(workload).toMatchObject({ warmups: 1, trials: 5, seed: 42 });
  });

  it("rejects invalid workload limits before IPC", () => {
    const errors = validateWorkload({
      ...defaultWorkload(),
      trials: 0,
      concurrency: 65,
    });

    expect(errors.map((error) => error.code)).toEqual(["invalidRange", "limitExceeded"]);
    expect(errors.map((error) => error.field)).toEqual([
      "workload.trials",
      "workload.concurrency",
    ]);
  });

  it("mirrors the Rust workload defaults exactly (contract fixture)", () => {
    // Literal mirror of evidence.rs Workload::default() with its serde
    // camelCase names (audit FE-17 I4): if either side changes, this fails.
    const rustDefaultWorkload: Workload = {
      id: "technical-explanation-v1",
      promptTokens: 512,
      generationTokens: 256,
      warmups: 1,
      trials: 5,
      seed: 42,
      concurrency: 1,
      stream: false,
      cacheMode: "warm",
      timeoutMs: 600_000,
    };
    expect(defaultWorkload()).toEqual(rustDefaultWorkload);
    expect(validateWorkload(rustDefaultWorkload)).toEqual([]);
  });

  it("requires whole numbers where Rust deserializes integers", () => {
    const fractional = validateWorkload({
      ...defaultWorkload(),
      trials: 2.5,
      promptTokens: 511.5,
    });
    expect(fractional.map((error) => error.field)).toEqual([
      "workload.promptTokens",
      "workload.trials",
    ]);
    expect(fractional.every((error) => error.message === "Value must be a whole number")).toBe(true);

    // Complete maxima and a blank identity surface as field errors.
    const over = validateWorkload({
      ...defaultWorkload(),
      promptTokens: 1_048_577,
      generationTokens: 65_537,
      warmups: 11,
      timeoutMs: 3_600_001,
      id: "   ",
    });
    expect(over.map((error) => error.field)).toEqual([
      "workload.id",
      "workload.promptTokens",
      "workload.generationTokens",
      "workload.warmups",
      "workload.timeoutMs",
    ]);
    expect(over.every((error) => error.code === "limitExceeded" || error.code === "emptyIdentity")).toBe(true);
  });
});

describe("v0.3 artifact contracts", () => {
  it("allows launch only for complete artifacts with consistent headers", () => {
    const artifact: ArtifactInspection = {
      logicalId: "a".repeat(64),
      contentId: "b".repeat(64),
      logicalName: "Fixture-Q4",
      firstShard: "C:/models/Fixture-Q4-00001-of-00002.gguf",
      expectedShards: 2,
      complete: true,
      headerConsistent: true,
      identityLevel: "exact",
      shardBytes: 20,
      companionBytes: 0,
      shards: [],
      companions: [],
      summary: null,
      problems: [],
    };

    expect(artifactReadyForLaunch(artifact)).toBe(true);
    expect(artifactReadyForLaunch({ ...artifact, complete: false })).toBe(false);
    expect(artifactReadyForLaunch({ ...artifact, headerConsistent: false })).toBe(false);
  });
});


describe("manual GPU override decisions", () => {
  it("converts one explicit GiB value without combining shared memory", () => {
    expect(manualGpuOverride("gpu-0", "8", "Firmware reserve")).toEqual({
      adapterId: "gpu-0",
      dedicatedBytes: 8 * 1024 ** 3,
      sharedBytes: null,
      note: "Firmware reserve",
    });
  });

  it("rejects missing adapters and invalid capacities", () => {
    expect(manualGpuOverride("", "8", "")).toBeNull();
    expect(manualGpuOverride("gpu-0", "0", "")).toBeNull();
    expect(manualGpuOverride("gpu-0", "Infinity", "")).toBeNull();
  });
});

describe("hardware evidence", () => {
  it("keeps conflicts visible by metric", () => {
    const observed = (value: number, kind: "windowsApi" | "nvidiaSmi") => ({
      value,
      level: "observed" as const,
      source: { kind, detail: kind },
      observedAtMs: 42,
      notes: [],
    });
    const unknown = {
      value: null,
      level: "unknown" as const,
      source: { kind: "unknown" as const, detail: "fixture" },
      observedAtMs: 42,
      notes: ["unknown"],
    };
    const adapter: GpuAdapterInfo = {
      adapterId: "luid:1",
      compatibilityId: "pci:10de:0001:00000000:00",
      name: "Fixture GPU",
      vendor: "nvidia",
      driver: {
        value: "1",
        level: "observed",
        source: { kind: "nvidiaSmi", detail: "fixture" },
        observedAtMs: 42,
        notes: [],
      },
      backend: {
        value: "cuda",
        level: "heuristic",
        source: { kind: "policy", detail: "fixture" },
        observedAtMs: 42,
        notes: [],
      },
      dedicatedBytes: observed(100, "windowsApi"),
      sharedBytes: observed(50, "windowsApi"),
      budgetBytes: observed(80, "windowsApi"),
      currentUsageBytes: observed(10, "windowsApi"),
      availableBudgetBytes: observed(70, "windowsApi"),
      reservationBytes: unknown,
      availableForReservationBytes: unknown,
      capacityObservations: [
        { metric: "dedicated", evidence: observed(100, "windowsApi") },
        { metric: "dedicated", evidence: observed(99, "nvidiaSmi") },
        { metric: "budget", evidence: observed(80, "windowsApi") },
      ],
    };

    expect(conflictingCapacityMetrics(adapter)).toEqual(["dedicated"]);
  });
});

describe("asynchronous UI race guards", () => {
  it("accepts only the newest request result", () => {
    expect(keepLatestRequest(3, 3)).toBe(true);
    expect(keepLatestRequest(2, 3)).toBe(false);
  });

  it("immediately disposes a listener that resolves after unmount", () => {
    let stopped = 0;
    expect(retainOrDisposeListener(true, () => { stopped += 1; })).toBeNull();
    expect(stopped).toBe(1);
    const stop = () => { stopped += 1; };
    expect(retainOrDisposeListener(false, stop)).toBe(stop);
  });
});

describe("catalog revisions", () => {
  it("preserves a pinned revision and defaults only omitted values", () => {
    const base = { quant: "Q4", filename: "x.gguf", sizeBytes: 1, sha256: "a".repeat(64) };
    expect(catalogRevision({ ...base, revision: "refs/pr/7" })).toBe("refs/pr/7");
    expect(catalogRevision(base)).toBe("main");
  });
});

const model: LogicalModel = {
  id: "target",
  name: "LFM2.5-2.6B-Q8_0",
  directory: "C:\\models\\LFM",
  firstShard: "C:\\models\\LFM\\target.gguf",
  sizeBytes: 2_874_779_648,
  shardCount: 1,
  expectedShards: 1,
  complete: true,
  quant: "Q8_0",
  shards: [],
  companions: [
    {
      path: "C:\\models\\LFM\\draft.gguf",
      name: "LFM2.5-DSpark-F16.gguf",
      role: "dspark",
      sizeBytes: 663_691_776,
    },
  ],
};

describe("profile numeric input", () => {
  const baseline = () => suggestedProfile(model, "C:/llama/llama-server.exe");

  it("covers every numeric field and preserves the suggested profile", () => {
    const profile = baseline();
    const numericFields = Object.keys(profile).filter((key) => typeof profile[key as keyof LaunchProfile] === "number");
    expect(Object.keys(profileNumberLimits).sort()).toEqual(numericFields.sort());
    expect(profileNumberError(profile)).toBeNull();
  });

  it.each(Object.keys(profileNumberLimits) as ProfileNumberField[])("rejects non-finite and out-of-range %s", (field) => {
    const [, min, max, step] = profileNumberLimits[field];
    for (const invalid of [NaN, Infinity, -Infinity, min - 1, max + 1, ...(step === 1 ? [0.5] : [])]) {
      expect(profileNumberError({ ...baseline(), [field]: invalid }), `${field}: ${invalid}`).not.toBeNull();
    }
  });

  it("preserves sentinel and fractional values supported by the existing contract", () => {
    expect(profileNumberError({ ...baseline(), threads: -1, cacheRam: -1, ssePingInterval: -1, seed: -1, topP: 0.975, temperature: 0.123 })).toBeNull();
    for (const overrides of [{ port: 65536 }, { context: 4194305 }, { parallel: 1025 }, { threads: 1025 }, { topP: 1.01 }, { draftPMin: -0.01 }]) {
      expect(profileNumberError({ ...baseline(), ...overrides })).not.toBeNull();
    }
  });

  it("reports a malformed saved method instead of crashing related numeric checks", () => {
    const restored = normalizeProfile(JSON.parse('{"specType":null}'), model, "C:/llama/llama-server.exe");
    expect(profileNumberError(restored)).toBe("Speculative method must be text.");
  });

  it.each([
    [{ batch: 512, ubatch: 513 }, "Physical uBatch"],
    [{ specType: "draft-dspark", draftMin: 6, draftMax: 5 }, "Draft minimum"],
    [{ specType: "ngram-mod", ngramMin: 65, ngramMax: 64 }, "N-gram minimum"],
    [{ imageMinTokens: 10, imageMaxTokens: 9 }, "Minimum image tokens"],
  ] as const)("rejects inconsistent related bounds %j", (overrides, label) => {
    expect(profileNumberError({ ...baseline(), ...overrides })).toContain(label);
  });
});

describe("normalizeProfile", () => {
  it("adopts the current runtime instead of the one saved with the profile", () => {
    // Bug: after installing a runtime update, opening a model whose profile was
    // saved against the old executable silently pinned the app back to it.
    const stored = {
      ...suggestedProfile(model, "C:\\llama\\llama-server.exe"),
      name: "My tuned profile",
      context: 16384,
    };
    const next = normalizeProfile(
      stored,
      model,
      "C:\\Users\\x\\AppData\\Local\\Localmotive\\runtimes\\b10752\\cuda-13.3\\llama-server.exe",
    );
    expect(next.runtime).toBe(
      "C:\\Users\\x\\AppData\\Local\\Localmotive\\runtimes\\b10752\\cuda-13.3\\llama-server.exe",
    );
    // Everything the user actually chose survives.
    expect(next.name).toBe("My tuned profile");
    expect(next.context).toBe(16384);
  });

  it("keeps the stored runtime when no runtime is currently selected", () => {
    const stored = { ...suggestedProfile(model, "C:\\llama\\llama-server.exe") };
    expect(normalizeProfile(stored, model, "").runtime).toBe("C:\\llama\\llama-server.exe");
  });
});

describe("suggestedProfile", () => {
  it("selects an explicit compatible DSpark companion", () => {
    const profile = suggestedProfile(model, "C:\\llama\\llama-server.exe");
    expect(profile.specType).toBe("draft-dspark");
    expect(profile.draftModel).toBe("C:\\models\\LFM\\draft.gguf");
    expect(profile.alias).toBe("lfm2-5-2-6b-q8-0");
    expect(profile.host).toBe("127.0.0.1");
    expect(profile.flashAttention).toBe("auto");
    expect(profile.cacheTypeK).toBe("f16");
    expect(profile.cachePrompt).toBe(true);
    expect(profile.continuousBatching).toBe(true);
    expect(profile.reasoning).toBe("auto");
    expect(profile.corsOrigins).toBe("localhost");
  });
});

const asset = (name: string): GithubAsset => ({ name, browserDownloadUrl: "https://example.invalid/" + name, size: 1, digest: null });
const option = (installKey: string, backend: string): RuntimeOption => ({
  id: `b10752:${installKey}`,
  label: installKey,
  backend,
  installKey,
  description: "",
  compatibility: "",
  asset: asset(`llama-b10752-bin-win-${installKey}-x64.zip`),
  companionAsset: null,
  recommended: false,
});
const cuda13 = option("cuda-13.3", "cuda");
const cuda12 = option("cuda-12.4", "cuda");
const cpu = option("cpu", "cpu");
const managedCuda13 = (tag: string): ManagedRuntimeRecord => ({
  tag,
  backend: "cuda",
  installKey: "cuda-13.3",
  runtimePath: `C:\\managed\\${tag}\\cuda-13.3\\llama-server.exe`,
  installRoot: `C:\\managed\\${tag}\\cuda-13.3`,
  contentVerified: false,
});
const identity = (over: Partial<RuntimeIdentity>): RuntimeIdentity => ({
  path: "C:\\llama\\llama-server.exe",
  backend: "unknown",
  cudaMajor: null,
  tag: null,
  installKey: null,
  source: "none",
  managedVerified: false,
  ...over,
});

describe("runtimeOptionState", () => {
  it("offers install when nothing matching is installed or active", () => {
    expect(runtimeOptionState(cuda13, "b10752", [], null, null)).toEqual({ kind: "install" });
  });

  it("marks the active managed build of the same variant as active", () => {
    const state = runtimeOptionState(cuda13, "b10752", [managedCuda13("b10752")], identity({ source: "manifest", backend: "cuda", cudaMajor: 13, tag: "b10752", installKey: "cuda-13.3" }), "10752");
    expect(state).toEqual({ kind: "active" });
  });

  it("offers an update when the active managed build of the same variant is older", () => {
    const state = runtimeOptionState(cuda13, "b10760", [managedCuda13("b10752")], identity({ source: "manifest", backend: "cuda", cudaMajor: 13, tag: "b10752", installKey: "cuda-13.3" }), "10752");
    expect(state).toEqual({ kind: "update", from: "b10752" });
  });

  it("offers to use an installed-but-inactive managed build of the same release", () => {
    const state = runtimeOptionState(cuda13, "b10752", [managedCuda13("b10752")], identity({ source: "manifest", backend: "cpu", tag: "b10752", installKey: "cpu" }), "10752");
    expect(state).toEqual({ kind: "use", runtimePath: "C:\\managed\\b10752\\cuda-13.3\\llama-server.exe" });
  });

  it("recognises a user-supplied CUDA 13 build by its DLLs and offers an update when the release is newer", () => {
    const state = runtimeOptionState(cuda13, "b10752", [], identity({ source: "dlls", backend: "cuda", cudaMajor: 13 }), "10679");
    expect(state).toEqual({ kind: "update", from: "b10679" });
  });

  it("does not treat a user-supplied CUDA 13 build as matching the CUDA 12 package", () => {
    expect(runtimeOptionState(cuda12, "b10752", [], identity({ source: "dlls", backend: "cuda", cudaMajor: 13 }), "10679")).toEqual({ kind: "install" });
  });

  it("marks a user-supplied build active when its build equals the release", () => {
    expect(runtimeOptionState(cpu, "b10752", [], identity({ source: "dlls", backend: "cpu" }), "10752")).toEqual({ kind: "active" });
  });

  it("still offers install when the active build cannot be identified", () => {
    expect(runtimeOptionState(cpu, "b10752", [], identity({ source: "none" }), "10752")).toEqual({ kind: "install" });
  });

  it("offers reinstall with detail when installed files disagree with the install record", () => {
    // Phase 5 RED: a `manifest-dll-mismatch` identity must surface as
    // `mismatch` with actionable detail, never as `active`, `update`,
    // `use`, or `install`. The frontend already renders this state
    // (MISMATCH · REINSTALL in App.tsx); the decision function must now
    // produce it. Finding A-09 (clean-machine dependency failure)
    // records this gap.
    const active = identity({ source: "manifest-dll-mismatch", backend: "mismatch", cudaMajor: 13, tag: "b10752", installKey: "cuda-13.3" });
    expect(runtimeIdentityMismatch(cuda13, active)).toBe("Installed files disagree with the install record");
    expect(runtimeIdentityMismatch(cuda12, active)).toBeNull();
    expect(runtimeIdentityMismatch(cuda13, null)).toBeNull();
    const state = runtimeOptionState(cuda13, "b10752", [managedCuda13("b10752")], active, "10752");
    expect(state).toEqual({ kind: "mismatch", detail: "Installed files disagree with the install record" });
  });
});

describe("HF catalog download rules", () => {
  const base = {
    destination: "C:/models",
    running: false,
    alreadyOnDisk: false,
    gated: false,
    hasToken: false,
  };

  it("refuses to start without a destination folder and says so", () => {
    const result = downloadReadiness({ ...base, destination: "" });
    expect(result.canStart).toBe(false);
    expect(result.reason).toMatch(/model folder/i);
    expect(downloadReadiness({ ...base, destination: "   " }).canStart).toBe(false);
  });

  it("refuses a second download of a file already in flight", () => {
    const result = downloadReadiness({ ...base, running: true });
    expect(result.canStart).toBe(false);
    expect(result.reason).toMatch(/already downloading/i);
  });

  it("lets the backend verify and reuse a file that is already on disk", () => {
    // A same-named local file may be stale or corrupt. The backend checks size
    // and a Hugging Face SHA-256 ETag instead of trusting the filename alone.
    expect(downloadReadiness({ ...base, alreadyOnDisk: true }).canStart).toBe(true);
  });

  it("blocks a gated repo until a token exists, then allows it", () => {
    // Gated repos return 401/403 without a token; catching it here gives a
    // better message than letting the download fail after it starts.
    const blocked = downloadReadiness({ ...base, gated: true, hasToken: false });
    expect(blocked.canStart).toBe(false);
    expect(blocked.reason).toMatch(/token/i);
    expect(downloadReadiness({ ...base, gated: true, hasToken: true }).canStart).toBe(true);
  });

  it("allows a normal download and gives no reason text", () => {
    const result = downloadReadiness(base);
    expect(result.canStart).toBe(true);
    expect(result.reason).toBe("");
  });

  it("builds a job key from repo, file, revision and destination", () => {
    expect(downloadKey("unsloth/Qwen3.8-27B-GGUF", "a.gguf", "C:/models", "main")).toBe(
      "unsloth/Qwen3.8-27B-GGUF/a.gguf@main#C:/models",
    );
    expect(downloadKey("a/b", "x.gguf", "C:/m", "main")).not.toBe(
      downloadKey("a/b", "y.gguf", "C:/m", "main"),
    );
    // FE-11: the same file elsewhere or at another revision is another job.
    expect(downloadKey("a/b", "x.gguf", "D:/other", "main")).not.toBe(
      downloadKey("a/b", "x.gguf", "C:/m", "main"),
    );
    expect(downloadKey("a/b", "x.gguf", "C:/m", "rev2")).not.toBe(
      downloadKey("a/b", "x.gguf", "C:/m", "main"),
    );
  });

  it("binds cancellation to the running job, not the edited destination", () => {
    const jobs: DownloadJob[] = [
      { key: "k-old", repo: "a/b", filename: "x.gguf", revision: "main", destination: "C:/m", startedAt: 1 },
      { key: "k-new", repo: "a/b", filename: "x.gguf", revision: "main", destination: "D:/other", startedAt: 2 },
    ];
    const states = { "k-old": { state: "done" }, "k-new": { state: "downloading" } };
    expect(newestDownloadJob(jobs, "a/b", "x.gguf")?.key).toBe("k-new");
    const active = activeDownloadJob(jobs, states, "a/b", "x.gguf");
    expect(active?.key).toBe("k-new");
    expect(active?.destination).toBe("D:/other");
    // With no running job, nothing can be cancelled.
    expect(activeDownloadJob(jobs, { "k-old": { state: "done" }, "k-new": { state: "error" } }, "a/b", "x.gguf")).toBeUndefined();
    expect(activeDownloadJob(jobs, states, "a/b", "other.gguf")).toBeUndefined();
  });
});

describe("download progress display", () => {
  it("clamps the percentage instead of overflowing the bar", () => {
    expect(downloadPercent(0, 100)).toBe(0);
    expect(downloadPercent(50, 100)).toBe(50);
    expect(downloadPercent(100, 100)).toBe(100);
    expect(downloadPercent(500, 100)).toBe(100);
    expect(downloadPercent(-5, 100)).toBe(0);
  });

  it("returns zero rather than NaN when the total is unknown", () => {
    // A NaN width silently breaks the progress bar, so guard every bad input.
    expect(downloadPercent(10, 0)).toBe(0);
    expect(downloadPercent(10, Number.NaN)).toBe(0);
    expect(downloadPercent(Number.NaN, 100)).toBe(0);
    expect(downloadPercent(10, Number.POSITIVE_INFINITY)).toBe(0);
  });

  it("formats the remaining time in units a person reads", () => {
    expect(etaLabel(0, 1000, 100)).toBe("10s left");
    expect(etaLabel(0, 100_000, 100)).toBe("16m 40s left");
    expect(etaLabel(0, 10_000_000, 1000)).toBe("2h 46m left");
  });

  it("shows no estimate when there is nothing to estimate from", () => {
    expect(etaLabel(0, 1000, 0)).toBe("");
    expect(etaLabel(1000, 1000, 100)).toBe("");
    expect(etaLabel(0, 0, 100)).toBe("");
  });

  it("labels transfer rate only when it is known", () => {
    expect(rateLabel(0)).toBe("");
    expect(rateLabel(1024 ** 3)).toBe("1.00 GiB/s");
  });
});

describe("catalog origin honesty", () => {
  it("marks a cached list as possibly stale rather than live", () => {
    // Showing an offline cache as live would misrepresent the catalog.
    expect(originLabel("cache").tone).toBe("warn");
    expect(originLabel("cache").label).toMatch(/OFFLINE/);
    expect(originLabel("network").tone).toBe("ok");
    expect(originLabel("not-modified").tone).toBe("ok");
  });

  it("always includes words, never colour alone", () => {
    for (const origin of ["network", "not-modified", "cache", "bundled"] as const) {
      expect(originLabel(origin).label.trim().length).toBeGreaterThan(3);
    }
  });
});

describe("hardware auto-fit budget", () => {
  it("prefers dedicated VRAM and never sums budgets", () => {
    // Mirrors catalog::hardware_fit_budget. Rust owns truth; this pins the
    // same answers on the frontend copy so the UI cannot drift.
    expect(hardwareFitBudget([8_000_000_000], [32_000_000_000], 64_000_000_000)).toEqual({
      budgetBytes: 8_000_000_000,
      source: "dedicated",
    });
    expect(hardwareFitBudget([], [32_000_000_000], 64_000_000_000)).toEqual({
      budgetBytes: 32_000_000_000,
      source: "shared",
    });
    expect(hardwareFitBudget([], [], 64_000_000_000)).toEqual({
      budgetBytes: 64_000_000_000,
      source: "system",
    });
    expect(hardwareFitBudget([null, 0], [null], 0)).toEqual({ budgetBytes: 0, source: "system" });
  });

  it("hides files above half the budget by default and disables on zero", () => {
    // A 20 GB Q8 row hides on a 32 GiB budget at 500 per mille.
    expect(modelHiddenByFitRule(20_000_000_000, 500, 34_359_738_368)).toBe(true);
    expect(modelHiddenByFitRule(20_000_000_000, 0, 34_359_738_368)).toBe(false);
    expect(modelHiddenByFitRule(20_000_000_000, 500, 0)).toBe(false);
    expect(modelHiddenByFitRule(20_000_000_000, 1000, 20_000_000_000)).toBe(false);
    expect(modelHiddenByFitRule(20_000_000_000, undefined, 34_359_738_368)).toBe(false);
  });
});

describe("FE-03 stale response guards", () => {
  const profile = (
    over: Partial<import("./model").LaunchProfile> = {},
  ): import("./model").LaunchProfile =>
    ({
      name: "profile-a",
      runtime: "C:/runtime/llama-server.exe",
      model: "C:/models/a.gguf",
      draftModel: null,
      mmproj: null,
      host: "127.0.0.1",
      port: 8080,
      alias: "a",
      context: 4096,
      gpuLayers: "all",
      batch: 2048,
      ubatch: 512,
      flashAttention: "auto",
      threads: -1,
      threadsBatch: -1,
      cacheTypeK: "f16",
      cacheTypeV: "f16",
      ...over,
    }) as unknown as import("./model").LaunchProfile;

  it("accepts only the latest response for the current resource identity", () => {
    expect(responseIsCurrent(3, 3, "openrouter", "openrouter")).toBe(true);
    // A newer request exists: the stale response is discarded.
    expect(responseIsCurrent(2, 3, "openrouter", "openrouter")).toBe(false);
    // The resource changed: a late response for the old provider is discarded.
    expect(responseIsCurrent(3, 3, "openrouter", "anthropic")).toBe(false);
  });

  it("applies a suggested port only to the unchanged originating profile", () => {
    const original = profile();
    const identity = profileIdentity(original);
    const applied = applySuggestedPort(original, identity, 8080, 8081);
    expect(applied.port).toBe(8081);
    expect(applied.model).toBe(original.model);

    // A later manual edit (different port) is never overwritten.
    const edited = profile({ port: 9000 });
    expect(applySuggestedPort(edited, identity, 8080, 8081).port).toBe(9000);
    // A newly selected profile is never overwritten.
    const other = profile({ model: "C:/models/b.gguf" });
    expect(applySuggestedPort(other, identity, 8080, 8081)).toBe(other);

    // No-op cases return the same reference, so callers can compare identity.
    expect(applySuggestedPort(original, identity, 8080, 8080)).toBe(original);
  });

  it("labels the app-wide evidence run for every screen", () => {
    expect(evidenceRunLabel("benchmark")).toBe("Benchmark running");
  });

  it("derives profile identity from the fields a stale response must match", () => {
    const base = profile();
    expect(profileIdentity(base)).toBe(profileIdentity(profile()));
    expect(profileIdentity(base)).not.toBe(
      profileIdentity(profile({ name: "renamed" })),
    );
    expect(profileIdentity(base)).not.toBe(
      profileIdentity(profile({ model: "C:/models/b.gguf" })),
    );
    expect(profileIdentity(base)).not.toBe(
      profileIdentity(profile({ runtime: "C:/runtime/other.exe" })),
    );
  });
});

describe("FE-01 and FE-02 selection and run identity", () => {
  const modelOf = (id: string): never => ({ id, name: id }) as never;

  it("keeps a surviving selection, replaces a missing one, clears on failure", () => {
    const inventory = [modelOf("a"), modelOf("b")];
    // Same model still present: the selection is preserved, never reset to
    // the first entry (audit FE-01).
    expect(selectionAfterRescan(inventory, "b")).toBe("b");
    // Missing model: the replacement is the first remaining entry.
    expect(selectionAfterRescan(inventory, "gone")).toBe("a");
    // Empty inventory: explicit null clears selection and profile together.
    expect(selectionAfterRescan([], "a")).toBeNull();
    // Failed scan: null models also clears together.
    expect(selectionAfterRescan(null, "a")).toBeNull();
  });

  it("never silently substitutes another model for a missing selection", () => {
    const inventory = [modelOf("a")];
    expect(displayedSelection(inventory as never, "a")).toBe(inventory[0]);
    expect(displayedSelection(inventory as never, "missing")).toBeUndefined();
  });

  it("labels a tuning run or report from its immutable record", () => {
    expect(
      tuningRunSummary({ modelName: "Llama 3", provider: "openrouter", advisor: "claude", context: 8192 }),
    ).toBe("Llama 3 · openrouter · claude · 8,192 ctx");
  });
});

describe("parseExtraArgs (FE-08)", () => {
  it("keeps separate tokens that were typed one character at a time", () => {
    // The raw field used to trim and re-split on every keystroke, so typing
    // "--flash-attn " dropped the separating space and glued the next token.
    expect(parseExtraArgs("--flash-attn --ctx-size 4096")).toEqual([
      "--flash-attn",
      "--ctx-size",
      "4096",
    ]);
  });

  it("supports quoted values that contain spaces", () => {
    expect(parseExtraArgs('--lora "C:/my models/adapters/x.bin" --seed 7')).toEqual([
      "--lora",
      "C:/my models/adapters/x.bin",
      "--seed",
      "7",
    ]);
    expect(parseExtraArgs('--flag "a \\"quoted\\" value"')).toEqual([
      "--flag",
      'a "quoted" value',
    ]);
  });

  it("treats empty and whitespace-only drafts as no arguments", () => {
    expect(parseExtraArgs("")).toEqual([]);
    expect(parseExtraArgs("   \t ")).toEqual([]);
  });

  it("round-trips through formatExtraArgs", () => {
    const tokens = ["--flash-attn", "--lora", "C:/my models/x.bin", "--flag=a b"];
    const formatted = formatExtraArgs(tokens);
    expect(formatExtraArgs(parseExtraArgs(formatted))).toBe(formatted);
    expect(parseExtraArgs(formatted)).toEqual(tokens);
  });
});

describe("persisted record validation (FE-09)", () => {
  it("salvages extraArgs from a corrupt profile record instead of crashing", () => {
    const fromString = normalizeProfile({ extraArgs: "--flash-attn --ctx-size 4096" as never }, model, "C:/llama/llama-server.exe");
    expect(fromString.extraArgs).toEqual(["--flash-attn", "--ctx-size", "4096"]);
    const fromMixed = normalizeProfile({ extraArgs: ["--flash-attn", 42, "--jinja", null] as never }, model, "");
    expect(fromMixed.extraArgs).toEqual(["--flash-attn"]);
    const fromJunk = normalizeProfile({ extraArgs: { nope: true } as never }, model, "");
    expect(fromJunk.extraArgs).toEqual([]);
  });

  it("retains unmeasured quality-change warnings in saved tuning reports", () => {
    const report = normalizeTuningReport({
      bestIndex: null,
      bestProfile: { name: "saved profile" },
      trials: [],
      qualityAffectingChanges: ["cacheTypeK", null, 42],
    });
    expect(report?.qualityAffectingChanges).toEqual(["cacheTypeK"]);
  });

  it("rejects tuning records that do not match the expected shape", () => {
    expect(normalizeTuningReport(null)).toBeUndefined();
    expect(normalizeTuningReport("text")).toBeUndefined();
    expect(normalizeTuningReport({})).toBeUndefined();
    expect(normalizeTuningReport({ trials: "not-an-array" })).toBeUndefined();
    expect(normalizeTuningReport({ trials: [null] })).toBeUndefined();
    // A valid report keeps its numbers and coerces the rest deterministically.
    const report = normalizeTuningReport({
      baselineTps: "fast",
      bestIndex: 1,
      bestTps: 42.5,
      bestProfile: { name: "p" },
      trials: [
        { index: 0, changes: {}, rationale: "r", meanTps: 10, medianTps: 9.5, error: null, command: "cmd" },
        { index: 1, changes: {}, rationale: "r2", meanTps: 20, medianTps: 19, error: "boom", command: "cmd2" },
      ],
      stoppedReason: "done",
    });
    expect(report?.baselineTps).toBeNull();
    expect(report?.bestTps).toBe(42.5);
    expect(report?.trials).toHaveLength(2);
    expect(report?.trials[1].error).toBe("boom");
  });

  it("parses JSON without throwing", () => {
    expect(safeJsonParse("{not json")).toBeUndefined();
    expect(safeJsonParse('{"ok":1}')).toEqual({ ok: 1 });
  });
});

describe("evidence tone (FE-15)", () => {
  it("maps status words to tones instead of painting every result green", () => {
    expect(evidenceTone("Measured")).toBe("ok");
    expect(evidenceTone("Complete")).toBe("ok");
    expect(evidenceTone("Unknown")).toBe("pending");
    expect(evidenceTone(null)).toBe("pending");
    expect(evidenceTone("")).toBe("pending");
    expect(evidenceTone("Blocked")).toBe("bad");
    expect(evidenceTone("Rejected")).toBe("bad");
    expect(evidenceTone("Cancelled")).toBe("bad");
  });
});

describe("catalogBuildFit", () => {
  const budget = 10_000_000_000; // 10 GB
  const small = 2_000_000_000; // 2 GB
  const large = 8_000_000_000; // 8 GB, above the 50% threshold of 5 GB

  it("reports the selected build, never the smallest one, against the threshold", () => {
    const smallFit = catalogBuildFit(small, small, 500, budget);
    expect(smallFit.selectedPasses).toBe(true);
    expect(smallFit.rowKept).toBe(true);
    expect(smallFit.thresholdBytes).toBe(5_000_000_000);

    const largeFit = catalogBuildFit(large, small, 500, budget);
    expect(largeFit.selectedPasses).toBe(false);
    // The row survives because a smaller build fits; the larger selected
    // build must never inherit that pass.
    expect(largeFit.rowKept).toBe(true);
  });

  it("keeps unknown metadata unknown instead of implying a fit", () => {
    expect(catalogBuildFit(large, small, 500, 0)).toEqual({
      thresholdBytes: null,
      selectedPasses: null,
      rowKept: null,
    });
    expect(catalogBuildFit(large, small, 0, budget)).toEqual({
      thresholdBytes: null,
      selectedPasses: null,
      rowKept: null,
    });
    expect(catalogBuildFit(large, small, undefined, undefined).selectedPasses).toBeNull();
  });

  it("clamps the fraction like the Rust rule", () => {
    const fit = catalogBuildFit(large, large, 2000, budget);
    expect(fit.thresholdBytes).toBe(budget);
    expect(fit.selectedPasses).toBe(true);
  });
});

describe("describeSamples", () => {
  it("names the sample base and the nearest-rank caveat", () => {
    expect(describeSamples({ count: 5 })).toBe("n=5 · nearest-rank p95 is the sample maximum");
    expect(describeSamples({ count: 19 })).toContain("sample maximum");
    expect(describeSamples({ count: 20 })).toBe("n=20 · nearest-rank percentiles");
    expect(describeSamples({ count: 100 })).toBe("n=100 · nearest-rank percentiles");
  });

  it("keeps missing sample metadata unknown instead of guessing", () => {
    expect(describeSamples(null)).toBe("sample count unknown");
    expect(describeSamples(undefined)).toBe("sample count unknown");
    expect(describeSamples({ count: 0 })).toBe("sample count unknown");
    expect(describeSamples({ count: Number.NaN })).toBe("sample count unknown");
  });
});

describe("reconcileDraftCompanion", () => {
  it("keeps a retained draft only while the method uses one", () => {
    expect(reconcileDraftCompanion("draft-dspark", "C:/models/dspark.gguf")).toEqual({
      draftModelPath: "C:/models/dspark.gguf",
      cleared: false,
    });
    expect(reconcileDraftCompanion("DRAFT-MTP", "C:/models/mtp.gguf").cleared).toBe(false);
  });

  it("clears a retained draft when the selected method cannot use it", () => {
    expect(reconcileDraftCompanion("none", "C:/models/dspark.gguf")).toEqual({
      draftModelPath: null,
      cleared: true,
    });
    expect(reconcileDraftCompanion("ngram-mod", "C:/models/mtp.gguf").cleared).toBe(true);
    expect(reconcileDraftCompanion("ngram-simple", "C:/models/mtp.gguf").cleared).toBe(true);
  });

  it("reports no change when there was nothing retained", () => {
    expect(reconcileDraftCompanion("none", null)).toEqual({ draftModelPath: null, cleared: false });
    expect(reconcileDraftCompanion("none", "  ")).toEqual({ draftModelPath: "  ", cleared: false });
  });
});

describe("S-19 bounded property campaign (FE persistence boundary)", () => {
  // Deterministic splitmix64 so any failure reproduces from its seed alone.
  const rngFor = (seed: number) => {
    let state = BigInt(seed) & 0xffffffffffffffffn;
    const next = () => {
      state = (state + 0x9e3779b97f4a7c15n) & 0xffffffffffffffffn;
      let z = state;
      z = ((z ^ (z >> 30n)) * 0xbf58476d1ce4e5b9n) & 0xffffffffffffffffn;
      z = ((z ^ (z >> 27n)) * 0x94d049bb133111ebn) & 0xffffffffffffffffn;
      return z ^ (z >> 31n);
    };
    return {
      below: (bound: number) => Number(next() % BigInt(bound)),
      text: (maxLen: number) => {
        const pool = ["a", "{", "}", "\"", "[", "]", ":", ",", "é", "模", "\\n", "9"];
        const len = 1 + Number(next() % BigInt(maxLen));
        return Array.from({ length: len }, () => pool[Number(next() % BigInt(pool.length))]).join("");
      },
    };
  };

  it("safeJsonParse and normalizeProfile tolerate 300 generated garbage inputs", () => {
    // The persistence boundary under test: a garbage STORED profile meets a
    // valid model (models always come from Rust, never from storage).
    const model: LogicalModel = {
      id: "fixture/model",
      name: "Fixture",
      directory: "C:/fixtures",
      firstShard: "C:/fixtures/fixture-00001-of-00001.gguf",
      sizeBytes: 10,
      shardCount: 1,
      expectedShards: 1,
      complete: true,
      quant: "Q4_K_M",
      shards: [],
      companions: [],
    };
    for (let seed = 1; seed <= 300; seed += 1) {
      const rng = rngFor(seed);
      // Mix of raw garbage and structured-but-wrong JSON.
      const raw =
        seed % 3 === 0
          ? rng.text(120)
          : seed % 3 === 1
            ? JSON.stringify({ name: rng.text(20), rawExtraArgs: rng.text(40), threads: rng.below(99999) })
            : JSON.stringify([seed, rng.text(30), null]);
      const parsed = safeJsonParse<unknown>(raw);
      // normalizeProfile takes Partial<LaunchProfile>; feed the parsed value
      // only when it is a non-null object, exactly like the caller does with
      // a persisted record (safeJsonParse returns undefined on garbage).
      const stored = parsed !== null && typeof parsed === "object" ? parsed : {};
      const normalized = normalizeProfile(stored as Partial<LaunchProfile>, model, "fixture-runtime");
      // The contract: never throws; the result is always a usable profile.
      expect(typeof normalized.name, `seed ${seed}`).toBe("string");
      expect(Array.isArray(normalized.extraArgs), `seed ${seed}`).toBe(true);
      expect(["on", "off", "auto"]).toContain(normalized.flashAttention as string);
    }
  });
});

describe("errorText (S-22)", () => {
  it("presents Tauri, plugin and object rejections without raw JSON or [object Object]", () => {
    expect(errorText(new Error("boom"))).toBe("boom");
    expect(errorText("plain failure")).toBe("plain failure");
    // A Tauri-rejected structured string is unwrapped to its message.
    expect(errorText(JSON.stringify({ code: "x", message: "structured failure" }))).not.toContain("{");
    // A raw object rejection prefers its message field.
    expect(errorText({ code: "no-handler", message: "no browser registered" })).toBe(
      "no browser registered",
    );
    // An object without a message serializes instead of stringifying to junk.
    expect(errorText({ code: "c1" })).toBe('{"code":"c1"}');
    expect(errorText(null)).toBe("null");
  });
});
